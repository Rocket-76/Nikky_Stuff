"""Offline verifier regressions; real Chromium tests never skip missing installs.

Run with pytest. Each browser scenario uses asyncio.run and shares one browser
within that scenario, avoiding pytest-asyncio fixture/event-loop dependencies.
Only temporary HTML files are written; no external services are contacted.
"""

import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from ncert_interact.generators.expand_tasks import expand_seeds
from ncert_interact.generators.rollout_worker import synthesize_reference_rollouts
from ncert_interact.schemas import DOMReadoutContract, VerificationReport
from ncert_interact.seeds import load_canonical_seeds
from ncert_interact.verifier import verify_html_applet
from ncert_interact.verifier import playwright_harness as harness


def _tasks():
    tasks = expand_seeds(load_canonical_seeds())
    return list({task.seed_id: task for task in tasks}.values())


def _angle():
    return next(t for t in _tasks() if "angle_classifier" in t.seed_id)


def _append(html, script):
    return html.replace("</body>", "<script>" + script + "</script></body>")


def _write(tmp_path, html, name="candidate"):
    path = tmp_path / (name + ".html")
    path.write_text(html, encoding="utf-8")
    return path


def test_reference_matrix_all_eight_models(tmp_path):
    async def scenario():
        from playwright.async_api import async_playwright

        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True, chromium_sandbox=True)
            try:
                for task in _tasks():
                    for rollout in synthesize_reference_rollouts(task):
                        report = await verify_html_applet(
                            _write(tmp_path, rollout.html, rollout.rollout_id), task,
                            browser=browser, rollout_id=rollout.rollout_id, timeout_ms=15000,
                        )
                        details = report.model_dump_json(indent=2)
                        assert report.exec_valid, details
                        assert report.controls_found_ratio == 1, details
                        assert report.ui_budget_compliance, details
                        assert not report.console_errors, details
                        assert len(report.probe_details) > len(task.verification_oracle.probe_cases) + 2
                        assert report.probe_details[0]["probe_id"] == "initial"
                        assert {detail["control_id"] for detail in report.probe_details if detail.get("control_check")} == {c.id for c in task.controls_contract}
                        if rollout.kind == "gold":
                            assert report.passed_all, details
                            assert report.scientific_oracle_acc == report.interaction_coverage == 1, details
                            assert not report.spoofing_detected, details
                        else:
                            assert not report.passed_all, details
                            if rollout.kind == "telemetry_spoof":
                                assert report.spoofing_detected, details
                                assert report.interaction_coverage == 0, details
                                assert report.scientific_oracle_acc < 1, details
                            elif rollout.kind == "dead_slider":
                                assert report.interaction_coverage == 0, details
                                assert report.scientific_oracle_acc < 1, details
                            else:
                                assert report.scientific_oracle_acc < 1, details
                assert not browser.contexts
            finally:
                await browser.close()

    asyncio.run(scenario())


def test_private_probes_are_full_unique_deterministic_and_oracle_valid():
    for task in _tasks():
        before = task.model_dump_json()
        probes = harness._build_probes(task, 2, 2027)
        assert probes == harness._build_probes(task, 2, 2027)
        public = [(p.probe_id, dict(p.control_inputs)) for p in task.verification_oracle.probe_cases]
        assert probes[:len(public)] == public
        assert len(probes) > len(public) + 2
        signatures = [json.dumps(p[1], sort_keys=True) for p in probes[:-2]]
        if "bio_osmosis" in task.seed_id:
            assert all(name.startswith("private_replay_") for name, _ in probes[-2:])
        else:
            for name, inputs in probes[-2:]:
                assert name.startswith("private_") and not name.startswith("private_replay_")
                signature = json.dumps(inputs, sort_keys=True)
                assert signature not in signatures
                signatures.append(signature)
        defaults = {c.id: c.default_val for c in task.controls_contract}
        default_state = harness.evaluate_oracle(task.verification_oracle.trusted_oracle_id, defaults)
        for control in task.controls_contract:
            index = next(i for i, (name, _) in enumerate(probes) if name == f"control_{control.id}")
            inputs = probes[index][1]
            assert probes[index - 1][1] == probes[index + 1][1] == defaults
            assert [key for key in defaults if inputs[key] != defaults[key]] == [control.id]
            assert harness.evaluate_oracle(task.verification_oracle.trusted_oracle_id, inputs) != default_state
        for _, inputs in probes:
            assert set(inputs) == {c.id for c in task.controls_contract}
            assert all(c.accepts(inputs[c.id]) for c in task.controls_contract)
            assert harness.evaluate_oracle(task.verification_oracle.trusted_oracle_id, inputs)
        assert task.model_dump_json() == before


@pytest.mark.parametrize("actual,expected,unit,match", [
    ("12", 12, None, True), ("-1.2e1 cm", -12, "cm", True),
    ("12cm", 12, "cm", True), ("12 wrong", 12, "cm", False),
    ("12 / 99", 12, None, False), ("expected 12", 12, None, False),
    (True, 1, None, False), ("NaN", 0, None, False),
    (float("inf"), 1, None, False), ("Infinity", "Infinity", None, True),
    ("Infinity cm", "Infinity", "cm", True), ("infinity", "Infinity", None, False),
    ("12.011", 12, None, False), ("12.005", 12, None, True),
])
def test_numeric_parser_is_fullmatch_finite_and_absolute(actual, expected, unit, match):
    readout = DOMReadoutContract(testid="readout-number", state_key="number", dtype="numeric", unit=unit)
    assert harness._matches(actual, expected, readout, visible=isinstance(actual, str)) is match


def test_enum_parser_never_accepts_substring_spoofs():
    contract = DOMReadoutContract(testid="readout-state", state_key="state", dtype="string_enum", allowed_values=["Expected"])
    assert harness._matches("  EXpected\n", "Expected", contract, visible=True)
    assert not harness._matches("Expected / Not Expected", "Expected", contract, visible=True)
    assert not harness._matches(False, "Expected", contract)


@pytest.mark.parametrize("document,prefix", [
    ("<!-- <head>decoy</head> --><html><HEAD data-label='>'>real</HEAD></html>", "<!-- <head>decoy</head> --><html><HEAD data-label='>'>"),
    ("<!doctype html>\n<html>\n<head>real</head></html>", "<!doctype html>\n<html>\n<head>"),
    ("<html><script>const text='<head>';</script><head>real</head></html>", "<html>"),
    ("<!-- <head>only a comment</head> --><body>content</body>", ""),
    ("<html></html>", ""),
])
def test_policy_insertion_ignores_commented_and_script_heads(document, prefix):
    hardened = harness._with_verifier_policy(document)
    assert hardened.startswith(prefix + '<meta http-equiv="Content-Security-Policy"')
    assert hardened.count(harness._CSP) == 1
    assert hardened.replace('<meta http-equiv="Content-Security-Policy" content="' + harness._CSP + '">', "", 1) == document


def test_readout_locator_requires_data_testid_not_a_matching_dom_id():
    from unittest.mock import Mock

    page = SimpleNamespace(locator=Mock())
    harness._readout_locator(page, "readout-angle-deg")
    page.locator.assert_called_once_with('[data-testid="readout-angle-deg"]')


def test_fail_closed_missing_file_and_invalid_parameters(tmp_path):
    task = _angle()
    report = asyncio.run(verify_html_applet(tmp_path / "absent.html", task))
    assert not report.exec_valid and not report.passed_all
    assert report.console_errors
    assert report.verification_latency_sec >= 0
    for kwargs in ({"timeout_ms": 0}, {"random_probe_count": -1}, {"random_seed": True}, {"generation_latency_sec": -1}):
        with pytest.raises((ValueError, TypeError)):
            asyncio.run(verify_html_applet(tmp_path / "absent.html", task, **kwargs))


def test_launch_failure_is_reported_not_silently_skipped(tmp_path):
    async def scenario():
        launch = AsyncMock(side_effect=RuntimeError("Please install Chromium"))
        pw = SimpleNamespace(chromium=SimpleNamespace(launch=launch), stop=AsyncMock())
        manager = SimpleNamespace(start=AsyncMock(return_value=pw))
        with patch.object(harness, "async_playwright", return_value=manager):
            report = await verify_html_applet(_write(tmp_path, "<html></html>"), _angle())
        assert not report.exec_valid and not report.passed_all
        assert any("install Chromium" in error for error in report.console_errors)
        launch.assert_awaited_once_with(headless=True, chromium_sandbox=True)
        pw.stop.assert_awaited_once()

    asyncio.run(scenario())


def test_adversarial_dom_and_visual_mutations(tmp_path):
    async def scenario():
        from playwright.async_api import async_playwright

        task = _angle()
        gold = synthesize_reference_rollouts(task)[0].html
        # These run after normal event handlers: the telemetry remains correct.
        cases = {
            "hidden_badge": ("document.querySelector('[data-testid]').style.display='none';", True),
            "transparent_ancestor": ("document.getElementById('readout-panel').style.opacity='.1';", True),
            "covered_badge": ("const p=document.getElementById('readout-panel');p.style.position='relative';p.insertAdjacentHTML('beforeend','<div style=\"position:absolute;inset:0;background:white;z-index:10\"></div>');", True),
            "extra_control": ("document.body.insertAdjacentHTML('beforeend','<button>Rogue</button>');", False),
            "missing_control": ("document.getElementById('ctrl_angle_deg').remove();", False),
            "duplicate_control": ("document.body.appendChild(document.getElementById('ctrl_angle_deg').cloneNode(true));", False),
            "missing_readout": ("document.querySelector('[data-testid]').remove();", True),
            "duplicate_readout": ("const r=document.querySelector('[data-testid]');r.after(r.cloneNode(true));", True),
            "id_without_testid": ("const r=document.querySelector('[data-testid]');r.id=r.dataset.testid;r.removeAttribute('data-testid');", True),
            "duplicate_id": ("document.body.insertAdjacentHTML('beforeend','<div id=\"sim-viewport\"></div>');", False),
            "wrong_range": ("document.getElementById('ctrl_angle_deg').step='2';", False),
            "small_target": ("document.getElementById('ctrl_angle_deg').style.cssText='min-height:1px;height:1px';", False),
            "hidden_control": ("document.getElementById('ctrl_angle_deg').style.display='none';", False),
            "small_view": ("document.getElementById('sim-viewport').style.cssText='width:199px;height:149px';", False),
            "disabled": ("document.getElementById('ctrl_angle_deg').disabled=true;", False),
            "covered_control": ("const c=document.getElementById('ctrl_angle_deg');c.parentElement.style.position='relative';c.insertAdjacentHTML('afterend','<div style=\"position:absolute;inset:0;background:white;z-index:99\"></div>');", False),
            "js_error": ("throw new Error('test page error');", False),
            "console_error": ("console.error('test console error');", False),
            "numeric_suffix": ("const r=document.querySelector('[data-testid]');const update=()=>r.textContent+=' / 999';document.getElementById('ctrl_angle_deg').addEventListener('change',update);", True),
            "metadata_mutation": ("SimSVG={...SimSVG,draw:()=>{const s=document.getElementById('sim-viewport');s.dataset.tick=String(Math.random());s.querySelector('title').textContent=String(Math.random());}};", True),
            "hidden_geometry_mutation": ("SimSVG={...SimSVG,draw:()=>{const s=document.getElementById('sim-viewport');s.insertAdjacentHTML('beforeend','<circle opacity=\"0\" r=\"'+Math.random()*90+'\"/>');}};", True),
            "text_only_mutation": ("SimSVG={...SimSVG,draw:()=>{const s=document.getElementById('sim-viewport');s.insertAdjacentHTML('beforeend','<text x=\"50\" y=\"50\">'+Math.random()+'</text>');}};", True),
            "clipped_mutation": ("SimSVG={...SimSVG,draw:()=>{document.getElementById('sim-viewport').insertAdjacentHTML('beforeend','<rect x=\"9000\" width=\"'+Math.random()*100+'\" height=\"40\"/>');}};", True),
        }
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True, chromium_sandbox=True)
            try:
                for name, (script, spoof) in cases.items():
                    report = await verify_html_applet(_write(tmp_path, _append(gold, script), name), task, browser=browser, timeout_ms=15000)
                    assert not report.passed_all, (name, report.model_dump())
                    if spoof:
                        assert report.spoofing_detected, (name, report.model_dump())
                    if name in {"hidden_control", "disabled", "covered_control", "small_target"}:
                        assert report.controls_found_ratio == 0, (name, report.model_dump())
                    if name == "small_view":
                        assert not report.ui_budget_compliance, report.model_dump()
            finally:
                await browser.close()

    asyncio.run(scenario())


def test_initialization_and_isolated_partial_listener_regressions(tmp_path):
    async def scenario():
        from playwright.async_api import async_playwright

        task = _angle()
        gold = synthesize_reference_rollouts(task)[0].html
        cases = {
            "correct_initial": ("", True),
            "event_initialized": ("window.__SIM_STATE__=null;document.querySelectorAll('[data-testid]').forEach(r=>r.textContent='Pending');document.getElementById('sim-viewport').innerHTML='';", False),
            "wrong_native_default": ("document.getElementById('ctrl_angle_deg').value='90';", False),
            "wrong_initial_state": ("window.__SIM_STATE__.angle_deg=90;", False),
            "stale_initial_readout": ("document.querySelector('[data-testid]').textContent='999';", False),
        }
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True, chromium_sandbox=True)
            try:
                for name, (script, passed) in cases.items():
                    report = await verify_html_applet(_write(tmp_path, _append(gold, script), name), task, browser=browser, timeout_ms=15000)
                    assert report.passed_all is passed, (name, report.model_dump())
                    initial, *later = report.probe_details
                    assert initial["probe_id"] == "initial" and initial["scientific_correct"] is passed
                    assert not initial["expected_changed"]
                    assert all(probe["scientific_correct"] for probe in later), (name, report.model_dump())
                    assert report.interaction_coverage == 1, (name, report.model_dump())
                    if not passed:
                        assert report.scientific_oracle_acc < 1

                circle = next(t for t in _tasks() if "circle_subtended" in t.seed_id)
                gold = synthesize_reference_rollouts(circle)[0].html
                # Only radius events refresh both inputs. Dispatching unchanged
                # radius events used to conceal the missing angle listener.
                script = """
                const angle=document.getElementById('ctrl_arc_span_deg');
                angle.replaceWith(angle.cloneNode(true));
                const radius=document.getElementById('ctrl_radius_cm');
                for(const event of ['input','change'])radius.addEventListener(event,()=>{
                  window.__UPDATE_SIM__('ctrl_arc_span_deg',document.getElementById('ctrl_arc_span_deg').value);
                });
                """
                report = await verify_html_applet(_write(tmp_path, _append(gold, script), "partial_listener"), circle, browser=browser, timeout_ms=15000)
                assert not report.passed_all and report.scientific_oracle_acc < 1 and report.interaction_coverage < 1, report.model_dump()
                checks = {detail["control_id"]: detail for detail in report.probe_details if detail.get("control_check")}
                angle_check = checks["ctrl_arc_span_deg"]
                assert angle_check["controls_set"] and angle_check["changed_controls"] == ["ctrl_arc_span_deg"]
                assert not angle_check["state_correct"] and not angle_check["interaction_correct"]
                assert checks["ctrl_radius_cm"]["scientific_correct"], report.model_dump()

                # A fake head in a comment must not swallow the frame policy.
                ran = []

                async def inspect_frame(page, *_):
                    ran.append(await page.evaluate("() => globalThis.__FRAME_RAN__ === true"))

                frame = '<iframe srcdoc="&lt;script&gt;parent.__FRAME_RAN__=true&lt;/script&gt;"></iframe>'
                html = '<!-- <head>decoy</head> -->' + gold.replace('</body>', frame + '</body>')
                with patch.object(harness, "_exercise", side_effect=inspect_frame):
                    report = await verify_html_applet(_write(tmp_path, html, "commented_head_frame"), circle, browser=browser, timeout_ms=15000)
                assert ran == [], report.model_dump()
                assert not report.exec_valid and not report.passed_all
                assert any("disallowed embedded execution context" in error for error in report.console_errors)
            finally:
                await browser.close()

    asyncio.run(scenario())


def test_canvas_pixels_and_combined_viewports(tmp_path):
    async def scenario():
        from playwright.async_api import async_playwright

        task = _angle()
        gold = synthesize_reference_rollouts(task)[0].html
        canvas = """
        const svg=document.getElementById('sim-viewport');
        const canvas=document.createElement('canvas');canvas.width=600;canvas.height=360;
        canvas.id='sim-viewport';canvas.style.width='100%';svg.replaceWith(canvas);
        function paint(){const ctx=canvas.getContext('2d');ctx.clearRect(0,0,600,360);
          ctx.fillStyle='white';ctx.fillRect(0,0,600,360);ctx.strokeStyle='teal';ctx.lineWidth=18;
          const a=window.__SIM_STATE__.angle_deg*Math.PI/180;ctx.beginPath();ctx.moveTo(300,250);
          ctx.lineTo(300+210*Math.cos(a),250-210*Math.sin(a));ctx.stroke();}
        paint();SimSVG={...SimSVG,draw:paint};
        """
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True, chromium_sandbox=True)
            try:
                for name, script, passed in [
                    ("canvas", canvas, True),
                    ("standard_canvas_id", canvas + "canvas.id='sim-canvas';", True),
                    ("static_canvas", canvas + "SimSVG={...SimSVG,draw:()=>{}};", False),
                    ("blank_canvas", canvas + "canvas.getContext('2d').clearRect(0,0,600,360);SimSVG={...SimSVG,draw:()=>{}};", False),
                    ("svg_and_canvas", "const s=document.getElementById('sim-viewport');const host=document.createElement('div');s.replaceWith(host);host.id='sim-viewport';s.removeAttribute('id');host.appendChild(s);const c=document.createElement('canvas');c.width=600;c.height=200;host.appendChild(c);function paintCanvas(){const x=c.getContext('2d');x.fillStyle='white';x.fillRect(0,0,600,200);x.fillStyle='teal';x.fillRect(10,10,window.__SIM_STATE__.angle_deg*2,120);}paintCanvas();const old=SimSVG.draw;SimSVG={...SimSVG,draw:(...args)=>{old(...args);paintCanvas();}};", True),
                ]:
                    candidate_task = task.model_copy(deep=True)
                    if name == "standard_canvas_id":
                        candidate_task.ui_complexity_budget.required_views = ["sim-canvas"]
                    report = await verify_html_applet(_write(tmp_path, _append(gold, script), name), candidate_task, browser=browser, timeout_ms=15000)
                    assert report.passed_all is passed, (name, report.model_dump())
                    if not passed:
                        assert report.spoofing_detected
            finally:
                await browser.close()

    asyncio.run(scenario())


def _observed(task, state, *, badges=True, visual=True):
    return {
        "state": state,
        "readouts": {r.state_key: {"visible": badges, "text": str(state[r.state_key])} for r in task.required_dom_readouts},
        "visual_valid": visual, "geometry_signature": "geometry", "svg_signature": "svg",
        "canvas_signature": "canvas", "raster": b"PNG fixture",
    }


@pytest.mark.parametrize("defect", ["none", "native", "state", "readout", "hidden", "blank"])
def test_initial_snapshot_cannot_be_repaired_by_later_events(defect):
    async def scenario():
        task = _angle()
        oracle_id = task.verification_oracle.trusted_oracle_id
        defaults = {c.id: c.default_val for c in task.controls_contract}
        probes = harness._build_probes(task, 0, 2027)
        expected = harness.evaluate_oracle(oracle_id, defaults)
        initial = _observed(task, dict(expected), badges=defect != "hidden", visual=defect != "blank")
        native = dict(defaults)
        if defect == "native":
            native["ctrl_angle_deg"] = 90
        elif defect == "state":
            initial["state"]["angle_deg"] = 90
        elif defect == "readout":
            initial["readouts"][task.required_dom_readouts[0].state_key]["text"] = "999"
        snapshots = [initial, _observed(task, harness.evaluate_oracle(oracle_id, task.verification_oracle.probe_cases[-1].control_inputs))]
        snapshots.extend(_observed(task, harness.evaluate_oracle(oracle_id, inputs)) for _, inputs in probes)
        page = SimpleNamespace(evaluate=AsyncMock(return_value=native))
        report = VerificationReport(task_id=task.task_id, rollout_id="initial")
        observed_before_action = False

        async def apply(*_):
            nonlocal observed_before_action
            observed_before_action = observed_before_action or snapshot.await_count == 1

        with patch.object(harness, "_audit", AsyncMock(return_value=(1, True, []))), patch.object(
            harness, "_apply", side_effect=apply
        ), patch.object(harness, "_snapshot", AsyncMock(side_effect=snapshots)) as snapshot, patch.object(
            harness, "_visual_transition", return_value=(True, .1)
        ):
            await harness._exercise(page, task, probes, report, 100)
        assert observed_before_action
        assert report.probe_details[0]["scientific_correct"] is (defect == "none")
        assert report.probe_details[0]["expected_changed"] is False
        assert report.interaction_coverage == 1
        assert report.scientific_oracle_acc == (len(probes) + int(defect == "none")) / (len(probes) + 1)
        assert all(detail["scientific_correct"] for detail in report.probe_details[1:])
        assert report.spoofing_detected is (defect in {"readout", "hidden", "blank"})

    asyncio.run(scenario())


@pytest.mark.parametrize("badges,changed,coverage,spoof", [
    (True, True, 1, False),
    (False, True, 0, True),
    (True, False, 0, True),
])
def test_exercise_uses_both_channels_and_expected_transitions(badges, changed, coverage, spoof):
    async def scenario():
        for task in _tasks():
            probes = harness._build_probes(task, 2, 2027)
            oracle_id = task.verification_oracle.trusted_oracle_id
            defaults = {c.id: c.default_val for c in task.controls_contract}
            previous = harness.evaluate_oracle(oracle_id, task.verification_oracle.probe_cases[-1].control_inputs)
            snapshots = [_observed(task, harness.evaluate_oracle(oracle_id, defaults)), _observed(task, previous)] + [
                _observed(task, harness.evaluate_oracle(oracle_id, inputs), badges=badges) for _, inputs in probes
            ]
            report = VerificationReport(task_id=task.task_id, rollout_id="mock")
            page = SimpleNamespace(evaluate=AsyncMock(return_value=defaults))
            with patch.object(harness, "_audit", AsyncMock(return_value=(1, True, []))), patch.object(
                harness, "_apply", AsyncMock()
            ), patch.object(harness, "_snapshot", AsyncMock(side_effect=snapshots)), patch.object(
                harness, "_visual_transition", return_value=(changed, .1 if changed else 0)
            ):
                await harness._exercise(page, task, probes, report, 100)
            assert report.interaction_coverage == coverage
            if badges and changed:
                assert report.scientific_oracle_acc == 1
            else:
                assert 0 < report.scientific_oracle_acc < 1
            assert report.spoofing_detected is spoof
            assert report.controls_found_ratio == 1 and report.ui_budget_compliance
            assert report.probe_details[0]["scientific_correct"]

    asyncio.run(scenario())


def test_equal_expected_states_do_not_inflate_transition_denominator():
    async def scenario():
        task = next(t for t in _tasks() if "solubility" in t.seed_id)
        probes = harness._build_probes(task, 0, 2027)
        # Salt and sugar have the same trusted output, despite different controls.
        probes += [("sugar", {"ctrl_substance": "sugar", "ctrl_stir_state": "stirred"}),
                   ("salt", {"ctrl_substance": "salt", "ctrl_stir_state": "stirred"})]
        oracle_id = task.verification_oracle.trusted_oracle_id
        defaults = {c.id: c.default_val for c in task.controls_contract}
        snapshots = [_observed(task, harness.evaluate_oracle(oracle_id, defaults)),
                 _observed(task, harness.evaluate_oracle(oracle_id, task.verification_oracle.probe_cases[-1].control_inputs))]
        snapshots += [_observed(task, harness.evaluate_oracle(oracle_id, values)) for _, values in probes]
        report = VerificationReport(task_id=task.task_id, rollout_id="equal")
        page = SimpleNamespace(evaluate=AsyncMock(return_value=defaults))
        with patch.object(harness, "_audit", AsyncMock(return_value=(1, True, []))), patch.object(
            harness, "_apply", AsyncMock()
        ), patch.object(harness, "_snapshot", AsyncMock(side_effect=snapshots)), patch.object(
            harness, "_visual_transition", side_effect=[(True, .1)] * (len(probes) - 1) + [(False, 0)]
        ):
            await harness._exercise(page, task, probes, report, 100)
        assert report.interaction_coverage == report.scientific_oracle_acc == 1
        assert not report.probe_details[-1]["expected_changed"]
        assert not report.spoofing_detected

    asyncio.run(scenario())


def _fake_browser():
    page = SimpleNamespace(
        set_default_timeout=lambda _: None, set_default_navigation_timeout=lambda _: None,
        on=lambda *_: None, set_content=AsyncMock(),
    )
    context = SimpleNamespace(
        route=AsyncMock(), route_web_socket=AsyncMock(), add_init_script=AsyncMock(),
        new_page=AsyncMock(return_value=page), close=AsyncMock(),
    )
    return SimpleNamespace(new_context=AsyncMock(return_value=context), close=AsyncMock()), context, page


def test_browser_reuse_isolation_security_and_cleanup(tmp_path):
    async def scenario():
        browser, context, page = _fake_browser()
        task = _angle()
        path = _write(tmp_path, "<html><head></head><body></body></html>")

        async def exercise(page, pis, probes, report, timeout):
            report.controls_found_ratio = report.scientific_oracle_acc = report.interaction_coverage = 1
            report.ui_budget_compliance = True

        with patch.object(harness, "_exercise", side_effect=exercise):
            for _ in range(2):
                report = await verify_html_applet(path, task, browser=browser, generation_latency_sec=1.5)
                assert report.passed_all
                assert report.generation_latency_sec == 1.5
        assert browser.new_context.await_count == 2
        assert context.close.await_count == 2
        browser.close.assert_not_awaited()
        kwargs = browser.new_context.call_args.kwargs
        assert kwargs["accept_downloads"] is False
        assert kwargs["service_workers"] == "block"
        assert kwargs["permissions"] == []
        assert kwargs["viewport"]["height"] >= 1000
        assert "worker-src 'none'" in page.set_content.call_args.args[0]
        route = SimpleNamespace(abort=AsyncMock())
        await context.route.call_args.args[1](route)
        route.abort.assert_awaited_once()
        socket = SimpleNamespace(close=AsyncMock())
        await context.route_web_socket.call_args.args[1](socket)
        socket.close.assert_awaited_once()

    asyncio.run(scenario())


def test_page_failure_and_cleanup_failure_fail_closed(tmp_path):
    async def scenario():
        browser, context, page = _fake_browser()
        page.set_content.side_effect = TimeoutError("hung applet")
        context.close.side_effect = RuntimeError("close failed")
        report = await verify_html_applet(_write(tmp_path, "<html></html>"), _angle(), browser=browser)
        assert not report.exec_valid and not report.passed_all
        assert any("hung applet" in error for error in report.console_errors)
        assert any("close failed" in error for error in report.console_errors)
        context.close.assert_awaited_once()
        browser.close.assert_not_awaited()

    asyncio.run(scenario())


def test_bounded_and_visual_transition_are_fail_closed():
    async def never():
        await asyncio.Event().wait()

    with pytest.raises(TimeoutError):
        asyncio.run(harness._bounded(never(), 1))
    before = {"raster": b"a", "visual_valid": True, "geometry_signature": "one"}
    after = {"raster": b"b", "visual_valid": True, "geometry_signature": "two"}
    with patch.object(harness, "_pixel_change", return_value=.001):
        assert harness._visual_transition(before, after) == (True, .001)
        after["geometry_signature"] = "one"
        assert not harness._visual_transition(before, after)[0]
        after["geometry_signature"] = "two"
        after["visual_valid"] = False
        assert not harness._visual_transition(before, after)[0]
    after["visual_valid"] = True
    with patch.object(harness, "_pixel_change", return_value=.0001):
        assert not harness._visual_transition(before, after)[0]


def _locator(*, text="60", count=1, ok=True, disabled=False, width=600, height=360):
    return SimpleNamespace(
        count=AsyncMock(return_value=count), scroll_into_view_if_needed=AsyncMock(),
        evaluate=AsyncMock(return_value={"ok": ok, "disabled": disabled, "width": width, "height": height}),
        fill=AsyncMock(), dispatch_event=AsyncMock(), select_option=AsyncMock(), click=AsyncMock(),
        inner_text=AsyncMock(return_value=text), bounding_box=AsyncMock(return_value={"width": width, "height": height}),
        screenshot=AsyncMock(return_value=b"png"),
    )


def test_native_element_actionability_and_input_equivalence():
    async def scenario():
        element = _locator()
        assert await harness._element_ok(element, 100, touch=48)
        element.scroll_into_view_if_needed.assert_not_awaited()
        for bad in (_locator(count=2), _locator(ok=False), _locator(disabled=True), _locator(width=30)):
            assert not await harness._element_ok(bad, 100, touch=48)
        hidden = _locator()
        hidden.evaluate.return_value = {"ok": False}
        assert not await harness._element_ok(hidden, 100)
        hidden.scroll_into_view_if_needed.assert_not_awaited()
        offscreen = _locator()
        offscreen.evaluate.side_effect = [{"ok": False, "width": 600, "height": 360}, {"ok": True, "width": 600, "height": 360}]
        assert await harness._element_ok(offscreen, 100, touch=48)
        offscreen.scroll_into_view_if_needed.assert_awaited_once_with(timeout=100)
        assert harness._input_equal("60.0", 60)
        assert harness._input_equal("salt", "salt")
        for actual, expected in [(True, 1), (None, 0), ("NaN", 1), ("x", 0), ([], 0)]:
            assert not harness._input_equal(actual, expected)

    asyncio.run(scenario())


def test_native_range_select_and_button_events_use_declared_values():
    async def scenario():
        task = next(t for t in _tasks() if "fraction" in t.seed_id)
        defaults = {c.id: c.default_val for c in task.controls_contract}
        inputs = {"ctrl_numerator": 3, "ctrl_denominator": "8", "ctrl_multiplier": 3}
        elements = {f'[id="{c.id}"]': _locator() for c in task.controls_contract}
        page = SimpleNamespace(locator=lambda selector: elements[selector], evaluate=AsyncMock(side_effect=[defaults, inputs]))
        await harness._apply(page, task, inputs, 100)
        assert page.evaluate.await_count == 2
        for control in task.controls_contract:
            element = elements[f'[id="{control.id}"]']
            if control.tag == "input_range":
                element.evaluate.assert_any_await("(element, value) => { element.value = String(value); }", inputs[control.id], timeout=100)
                assert [call.args[0] for call in element.dispatch_event.call_args_list] == ["input", "change"]
            else:
                element.select_option.assert_awaited_once_with(value=str(inputs[control.id]), timeout=100)
        page.evaluate = AsyncMock(return_value={})
        with pytest.raises(ValueError, match="native control"):
            await harness._apply(page, task, inputs, 100)
        elements[next(iter(elements))].evaluate.return_value["ok"] = False
        with pytest.raises(ValueError, match="actionable"):
            await harness._apply(page, task, inputs, 100)

        # Schema shape is identical for a two-option button and a select.
        button_task = _angle().model_copy(deep=True)
        button_task.controls_contract[0] = task.controls_contract[1].model_copy(update={
            "id": "ctrl_toggle", "tag": "button", "options": ["off", "on"], "default_val": "off",
        })
        button = _locator()
        page = SimpleNamespace(locator=lambda _: button, evaluate=AsyncMock(side_effect=[
            {"ctrl_toggle": "off"}, {"ctrl_toggle": "off"}, {"ctrl_toggle": "on"}, {"ctrl_toggle": "on"},
        ]))
        await harness._apply(page, button_task, {"ctrl_toggle": "on"}, 100)
        button.click.assert_awaited_once()
        page.evaluate = AsyncMock(return_value={"ctrl_toggle": "off"})
        with pytest.raises(ValueError, match="cycle"):
            await harness._apply(page, button_task, {"ctrl_toggle": "on"}, 100)

    asyncio.run(scenario())


def test_ui_audit_all_controls_duplicate_ids_and_required_views():
    async def scenario():
        task = _angle()
        control = task.controls_contract[0]
        data = {
            "duplicates": [], "controls": [{"id": control.id, "tag": "input", "type": "range",
                "min": str(control.min_val), "max": str(control.max_val), "step": str(control.step), "labelled": True}],
            "views": [{"id": "sim-viewport", "count": 1}],
            "readouts": [{"id": r.testid, "count": 1} for r in task.required_dom_readouts],
        }
        page = SimpleNamespace(evaluate=AsyncMock(return_value=data), locator=lambda _: _locator())
        assert await harness._audit(page, task, 100) == (1, True, [])
        data["controls"].append({"id": "rogue"})
        assert not (await harness._audit(page, task, 100))[1]
        data["duplicates"] = [control.id]
        data["controls"].append(data["controls"][0])
        data["views"][0]["count"] = 0
        data["readouts"][0]["count"] = 2
        found, compliant, errors = await harness._audit(page, task, 100)
        assert found == 0 and not compliant and len(errors) >= 4
        data["duplicates"] = []
        data["controls"] = data["controls"][:1]
        data["controls"][0]["type"] = "number"
        found, compliant, errors = await harness._audit(page, task, 100)
        assert found == 0 and not compliant

    asyncio.run(scenario())


@pytest.mark.parametrize("defect", ["hidden", "disabled", "narrow_view", "short_view", "missing_view_bounds"])
def test_ui_audit_requires_actionable_controls_and_minimum_viewport(defect):
    async def scenario():
        task = _angle()
        control = task.controls_contract[0]
        data = {
            "duplicates": [], "controls": [{"id": control.id, "tag": "input", "type": "range",
                "min": str(control.min_val), "max": str(control.max_val), "step": str(control.step), "labelled": True}],
            "views": [{"id": "sim-viewport", "count": 1}],
            "readouts": [{"id": r.testid, "count": 1} for r in task.required_dom_readouts],
        }
        element = _locator(ok=defect != "hidden", disabled=defect == "disabled")
        view = _locator(width=199 if defect == "narrow_view" else 600, height=149 if defect == "short_view" else 360)
        if defect == "missing_view_bounds":
            view.bounding_box.return_value = None
        page = SimpleNamespace(evaluate=AsyncMock(return_value=data), locator=lambda selector: element if control.id in selector else view)
        found, compliant, errors = await harness._audit(page, task, 100)
        assert found == (0 if defect in {"hidden", "disabled"} else 1)
        assert not compliant and errors

    asyncio.run(scenario())


def test_snapshot_requires_visible_nonblank_svg_and_canvas_and_masks_text():
    async def scenario():
        task = _angle()
        state = harness.evaluate_oracle(task.verification_oracle.trusted_oracle_id, {"ctrl_angle_deg": 60})
        view = _locator()
        surfaces = [{"kind": "svg", "width": 600, "height": 360, "serialized": "<path/>", "geometry": [["path", "M0 0L60 60"]], "groups": []},
                    {"kind": "canvas", "width": 600, "height": 360, "data": "data:image/png;base64,cG5n"}]
        view.evaluate.side_effect = lambda code, **_: surfaces if code == harness._VISUAL else {"ok": True, "width": 600, "height": 360}
        labels = {r.testid: _locator(text=str(state[r.state_key])) for r in task.required_dom_readouts}
        page = SimpleNamespace(evaluate=AsyncMock(return_value=state), locator=lambda _: view)
        with patch.object(harness, "_readout_locator", side_effect=lambda _, testid: labels[testid]), patch.object(
            harness, "_nonblank", return_value=True
        ):
            result = await harness._snapshot(page, task, 100)
            assert result["visual_valid"] and all(r["visible"] for r in result["readouts"].values())
            assert result["svg_signature"] and result["canvas_signature"]
            assert "svg text" in view.screenshot.call_args.kwargs["style"]
            labels[next(iter(labels))].count.return_value = 0
            assert not next(iter((await harness._snapshot(page, task, 100))["readouts"].values()))["visible"]
            view.bounding_box.return_value = {"width": 100, "height": 100}
            assert not (await harness._snapshot(page, task, 100))["visual_valid"]
            view.count.return_value = 0
            assert not (await harness._snapshot(page, task, 100))["visual_valid"]

    asyncio.run(scenario())


def test_apply_skips_unchanged_controls_and_checks_every_final_native_value():
    async def scenario():
        task = next(t for t in _tasks() if "circle_subtended" in t.seed_id)
        defaults = {c.id: c.default_val for c in task.controls_contract}
        targets = {**defaults, "ctrl_arc_span_deg": 120}
        elements = {f'[id="{c.id}"]': _locator() for c in task.controls_contract}
        page = SimpleNamespace(locator=lambda selector: elements[selector], evaluate=AsyncMock(side_effect=[defaults, targets]))
        await harness._apply(page, task, targets, 100)
        assert page.evaluate.await_count == 2
        elements['[id="ctrl_radius_cm"]'].evaluate.assert_not_awaited()
        elements['[id="ctrl_radius_cm"]'].dispatch_event.assert_not_awaited()
        assert [call.args[0] for call in elements['[id="ctrl_arc_span_deg"]'].dispatch_event.call_args_list] == ["input", "change"]

        # A listener changing a different native control must fail the full-input check.
        page.evaluate = AsyncMock(side_effect=[defaults, {**targets, "ctrl_radius_cm": 15}])
        with pytest.raises(ValueError, match="native control"):
            await harness._apply(page, task, targets, 100)
        for element in elements.values():
            element.evaluate.reset_mock()
            element.dispatch_event.reset_mock()
        page.evaluate = AsyncMock(side_effect=[defaults, defaults])
        await harness._apply(page, task, defaults, 100)
        for element in elements.values():
            element.evaluate.assert_not_awaited()
            element.dispatch_event.assert_not_awaited()

        select_task = next(t for t in _tasks() if "solubility" in t.seed_id)
        defaults = {c.id: c.default_val for c in select_task.controls_contract}
        select = _locator()
        page = SimpleNamespace(locator=lambda _: select, evaluate=AsyncMock(return_value=defaults))
        await harness._apply(page, select_task, defaults, 100)
        select.select_option.assert_not_awaited()

    asyncio.run(scenario())