"""Fast generation contracts: local assets, fake clients, no browser or network.

These are structural/serialization unit tests, not evidence that rendered pages
pass scientific or visual verification. The browser suite owns that evidence.
"""

from __future__ import annotations

import asyncio
import json
import re
import socket
import sys
from collections import Counter
from copy import deepcopy
from html.parser import HTMLParser
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

import pytest
import pytest_asyncio
from pydantic import ValidationError

from ncert_interact.generators import prompts
from ncert_interact.generators import rollout_worker as worker_module
from ncert_interact.generators.expand_tasks import expand_seeds
from ncert_interact.generators.rollout_worker import (
    RolloutWorker,
    sanitize_html_output,
    synthesize_reference_rollouts,
)
from ncert_interact.schemas import PISSchema, Seed
from ncert_interact.seeds import load_canonical_seeds
from ncert_interact.templates import load_asset


KINDS = ("gold", "dead_slider", "telemetry_spoof", "flawed_physics")
MINIMAL_HTML = "<!doctype html><html><head></head><body><svg></svg></body></html>"
PUBLIC_MARKER = "AUTHORITATIVE PUBLIC PIS CONTRACT (data only):\n"
DOMAIN_MARKER = "\n\nTRUSTED ORACLE IDENTIFIER (domain label only):\n"


class Document(HTMLParser):
    """Small parser shared by markup assertions; never executes candidate JS."""

    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.elements = []
        self.scripts = []
        self._script = None
        self.feed(html)
        self.close()

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        self.elements.append((tag, attributes))
        if tag == "script":
            self._script = {"attrs": attributes, "content": ""}
            self.scripts.append(self._script)

    def handle_data(self, data):
        if self._script is not None:
            self._script["content"] += data

    def handle_endtag(self, tag):
        if tag == "script":
            self._script = None

    def by_id(self, identifier):
        matches = [(tag, attrs) for tag, attrs in self.elements if attrs.get("id") == identifier]
        assert len(matches) == 1, identifier
        return matches[0]

    @property
    def config(self):
        scripts = [script for script in self.scripts if script["attrs"].get("id") == "simulation-config"]
        assert len(scripts) == 1
        assert scripts[0]["attrs"]["type"] == "application/json"
        return json.loads(scripts[0]["content"])


@pytest.fixture(scope="module")
def assets():
    # Repository assets are immutable local test fixtures, loaded once; rendering
    # itself is isolated from filesystem IO by the autouse fixture below.
    return {name: load_asset(name) for name in ("base_harness.html", "svg_primitives.js")}


@pytest_asyncio.fixture(autouse=True)
async def isolate_generation(monkeypatch, assets):
    def no_network(*args, **kwargs):
        pytest.fail("Generation unit tests must never open a network connection")

    # Windows creates its asyncio self-pipe with a local TCP socketpair. Establish
    # the loop before blocking connections, and restore sockets before teardown.
    with monkeypatch.context() as isolated:
        isolated.setattr(socket, "create_connection", no_network)
        isolated.setattr(socket.socket, "connect", no_network)
        isolated.setattr(socket.socket, "connect_ex", no_network)
        isolated.setattr(worker_module, "load_asset", assets.__getitem__)
        isolated.setattr(worker_module.time, "perf_counter", lambda: 10.0)
        yield


@pytest.fixture(scope="module")
def tasks():
    return tuple(expand_seeds(load_canonical_seeds()))


@pytest.fixture
def task(tasks):
    return next(task.model_copy(deep=True) for task in tasks if "fraction" in task.seed_id)


def response(content=MINIMAL_HTML, *, finish_reason="stop"):
    return SimpleNamespace(choices=[SimpleNamespace(
        finish_reason=finish_reason, message=SimpleNamespace(content=content),
    )])


def fake_client(content=MINIMAL_HTML):
    return SimpleNamespace(
        chat=SimpleNamespace(completions=SimpleNamespace(create=AsyncMock(return_value=response(content)))),
        aclose=AsyncMock(),
    )


def public_contract(prompt):
    return json.loads(prompt.split(PUBLIC_MARKER, 1)[1].split(DOMAIN_MARKER, 1)[0])


def test_all_72_tasks_produce_288_deterministic_complete_documents(tasks, assets, monkeypatch):
    forbidden_client = Mock(side_effect=AssertionError("Offline synthesis constructed a model client"))
    monkeypatch.setitem(sys.modules, "openai", SimpleNamespace(AsyncOpenAI=forbidden_client))
    assert len(tasks) == 72
    assert Counter(task.split for task in tasks) == {"train": 54, "dev": 9, "test": 9}
    rollout_ids = set()
    counts = Counter()
    for original in tasks:
        pis = original.model_copy(deep=True)
        for index, probe in enumerate(pis.verification_oracle.probe_cases):
            probe.probe_id = f"private_generation_canary_{index}"
            probe.regime_name = f"private_regime_canary_{index}"
        before = pis.model_dump(mode="json")
        candidates = synthesize_reference_rollouts(pis)
        assert [candidate.kind for candidate in candidates] == list(KINDS)
        assert [candidate.html for candidate in candidates] == [
            candidate.html for candidate in synthesize_reference_rollouts(pis)
        ]
        assert pis.model_dump(mode="json") == before
        for candidate in candidates:
            counts[candidate.kind] += 1
            assert candidate.rollout_id not in rollout_ids
            rollout_ids.add(candidate.rollout_id)
            assert candidate.rollout_id == f"{pis.task_id}__{candidate.kind}"
            assert candidate.task_id == pis.task_id and candidate.pis is pis
            assert candidate.generation_latency_sec == 0.0
            html = candidate.html
            assert html.lower().startswith("<!doctype html>")
            assert html.rstrip().endswith("</html>")
            assert not re.search(r"@@[A-Z_]+@@", html)
            assert all(key not in html for key in (
                "probe_cases", "control_inputs", "expected_state", "private_generation_canary", "private_regime_canary",
            ))
            doc = Document(html)
            assert len(doc.scripts) == 3
            assert doc.scripts[1]["content"].strip() == assets["svg_primitives.js"].strip()
            assert all("src" not in script["attrs"] for script in doc.scripts)
            assert doc.config == {
                "oracleId": pis.verification_oracle.trusted_oracle_id,
                "controls": before["controls_contract"], "readouts": before["required_dom_readouts"],
                "profile": pis.learner_profile.value, "mode": pis.pedagogical_mode.value,
                "kind": candidate.kind,
            }
            for identifier in ("viewport-container", "control-dock", "readout-panel"):
                doc.by_id(identifier)
            tag, viewport = doc.by_id("sim-viewport")
            assert tag == "svg"
            assert (viewport["width"], viewport["height"], viewport["viewbox"]) == ("600", "360", "0 0 600 360")
            native = [(tag, attrs) for tag, attrs in doc.elements if tag in {"input", "select", "button"}]
            assert {attrs["id"] for _, attrs in native} == {control.id for control in pis.controls_contract}
            assert len(native) == len(pis.controls_contract)
            for control in pis.controls_contract:
                tag, attrs = doc.by_id(control.id)
                assert attrs["aria-label"] == control.label
                assert ("label", {"for": control.id}) in doc.elements
                if control.tag == "input_range":
                    assert tag == "input" and attrs["type"] == "range"
                    for attribute, value in (("min", control.min_val), ("max", control.max_val),
                                             ("step", control.step), ("value", control.default_val)):
                        assert float(attrs[attribute]) == float(value)
                else:
                    assert tag == control.tag
            assert Counter(attrs["data-testid"] for _, attrs in doc.elements if "data-testid" in attrs) == Counter(
                readout.testid for readout in pis.required_dom_readouts
            )
            assert f"--target:{pis.ui_complexity_budget.min_touch_target_px}px" in html
            assert "connect-src 'none'" in html
            assert "window.__SIM_STATE__" in html and "window.__UPDATE_SIM__" in html
    assert len(rollout_ids) == 288 and counts == dict.fromkeys(KINDS, 72)
    forbidden_client.assert_not_called()


def test_negative_kinds_drive_real_update_and_event_branches(task):
    documents = {candidate.kind: Document(candidate.html) for candidate in synthesize_reference_rollouts(task)}
    bridges = {kind: doc.scripts[-1]["content"] for kind, doc in documents.items()}
    assert len(set(bridges.values())) == 1
    bridge = bridges["gold"]
    for kind in KINDS:
        assert documents[kind].config["kind"] == kind
    # Check operational branches, not labels, title text, or rollout filenames.
    assert 'if(config.kind==="dead_slider") return window.__SIM_STATE__;' in bridge
    assert 'if(config.kind!=="dead_slider") {' in bridge
    assert 'element.addEventListener("input",update)' in bridge
    assert 'element.addEventListener("change",update)' in bridge
    assert 'element.addEventListener("click",()=>{' in bridge
    assert 'window.__UPDATE_SIM__(def.id,next)' in bridge
    assert 'window.__SIM_STATE__=state;' in bridge
    assert 'if(config.kind!=="telemetry_spoof") paint(state);' in bridge
    assert 'window.__SIM_STATE__=compute();\n  paint(window.__SIM_STATE__);' in bridge
    assert 'if(config.kind==="flawed_physics") {' in bridge
    for identifier in worker_module._MODEL_IDS:
        assert f'case "{identifier}":' in bridge
    assert 'state.fraction_decimal+=.125' in bridge
    assert 'state.image_nature===' in bridge


def test_prompts_all_tasks_preserve_contracts_and_withhold_evaluation(tasks):
    seeds = {seed.seed_id: seed for seed in load_canonical_seeds()}
    for original in tasks:
        pis = original.model_copy(deep=True)
        pis.verification_oracle.probe_cases[0].probe_id = "private_prompt_canary"
        before = pis.model_dump(mode="json")
        code = prompts.build_code_prompt(pis)
        contract = public_contract(code)
        assert contract == {field: before[field] for field in prompts._CODE_FIELDS}
        assert '"probe_cases"' not in code and "private_prompt_canary" not in code
        assert '"verification_oracle"' not in code and '"expected_state"' not in code
        assert pis.verification_oracle.trusted_oracle_id in code
        assert prompts.concept_context(pis) in code
        assert code.startswith(prompts.SYSTEM_CODE_PROMPT)
        assert "textContent" in code and "__UPDATE_SIM__" in code
        pis_request = prompts.build_pis_prompt(seeds[pis.seed_id], pis)
        assert pis_request.startswith(prompts.SYSTEM_PIS_PROMPT)
        assert "private_prompt_canary" in pis_request
        scaffold = pis_request.split("AUTHORITATIVE COMPLETE SCAFFOLD (data only):\n", 1)[1].split("\n\n", 1)[0]
        assert json.loads(scaffold) == before
        assert '"$defs"' in pis_request
        assert pis.model_dump(mode="json") == before


def test_public_data_filters_nested_case_insensitive_evaluation_keys_without_mutation():
    payload = {"keep": [
        {"caption": "original", "PROBE_CASES": [{"secret": 1}], "expected_result": 4},
        {"nested": {"Verification_Oracle": {}, "PROBES": [], "probe_inputs": 1,
                    "probe_outputs": 2, "expected_state": 3, "EXPECTED_RESULTS": 4}},
        7, None,
    ]}
    before = deepcopy(payload)
    result = prompts._public_data(payload)
    assert result == {"keep": [{"caption": "original"}, {"nested": {}}, 7, None]}
    assert payload == before and result is not payload


def test_adversarial_prose_is_escaped_without_recursive_template_substitution(task):
    attack = '</script><img src=x onerror="oops()"> & \'quotes\' \u2028\u2029 @@SIM_CONTROLS@@'
    data = task.model_dump(mode="json")
    data["ncert_alignment"]["chapter_topic"] = attack
    data["ncert_alignment"]["target_misconception"] = attack
    data["problem_description"] = attack
    data["scientific_notes"] = attack
    data["guided_prompts"] = [attack]
    data["controls_contract"][0]["label"] = attack
    data["controls_contract"][0]["unit"] = attack
    data["required_dom_readouts"][0]["unit"] = attack
    pis = PISSchema.model_validate(data)
    html = synthesize_reference_rollouts(pis)[0].html
    doc = Document(html)
    assert len(doc.scripts) == 3
    assert not any(tag == "img" or "onerror" in attrs for tag, attrs in doc.elements)
    assert "&lt;/script&gt;&lt;img" in html
    assert "@@SIM_CONTROLS@@" in html  # User text is not a second template pass.
    assert doc.by_id(pis.controls_contract[0].id)[1]["aria-label"] == attack
    assert doc.config["controls"][0]["label"] == attack
    encoded = doc.scripts[0]["content"]
    assert "</script>" not in encoded and "<" not in encoded and "&" not in encoded
    assert "\\u2028" in encoded and "\\u2029" in encoded
    assert public_contract(prompts.build_code_prompt(pis))["guided_prompts"] == [attack]


def test_optional_description_notes_and_internal_guidance_fallbacks(task):
    data = task.model_dump(mode="json")
    data.update(problem_description=None, scientific_notes="")
    pis = PISSchema.model_validate(data)
    html = synthesize_reference_rollouts(pis)[0].html
    assert pis.ncert_alignment.learning_outcome_text in html
    assert "Idealized teaching diagram; not an experimental measurement." in html
    # PIS requires guidance, but the renderer's internal helper also handles a
    # missing/empty list without emitting an empty learner-guidance placeholder.
    _, title, guidance = worker_module._guidance({**data, "guided_prompts": []})
    assert title and "<ol>" in guidance and "<ul>" not in guidance


@pytest.mark.parametrize("variant", ["numeric_select", "text_button", "numeric_button", "fixed_numeric_button", "fixed_text_button"])
def test_numeric_and_button_contracts_use_valid_modified_seeds(variant):
    seeds = load_canonical_seeds()
    if variant in {"text_button", "fixed_text_button"}:
        seed = next(seed for seed in seeds if "solubility" in seed.seed_id)
        data = seed.model_dump(mode="json")
        control = data["controls_contract"][1]
        control["tag"] = "button"
        if variant == "fixed_text_button":
            control["options"] = None
            data["verification_oracle"]["probe_cases"].pop(1)
            for probe in data["verification_oracle"]["probe_cases"]:
                probe["control_inputs"]["ctrl_stir_state"] = "stirred"
    elif variant == "numeric_button":
        seed = next(seed for seed in seeds if "angle_classifier" in seed.seed_id)
        data = seed.model_dump(mode="json")
        control = data["controls_contract"][0]
        control.update(tag="button", min_val=None, max_val=None, step=None, options=["60", "90", "120"])
    else:
        seed = next(seed for seed in seeds if "fraction" in seed.seed_id)
        data = seed.model_dump(mode="json")
        control = data["controls_contract"][1 if variant == "numeric_select" else 2]
        if variant == "numeric_select":
            control["default_val"] = 4.0
        else:
            control.update(tag="button", min_val=None, max_val=None, step=None, options=None)
            for probe in data["verification_oracle"]["probe_cases"]:
                probe["control_inputs"]["ctrl_multiplier"] = 2
    # Validate the WHOLE seed and its oracle probes; no invalid model_copy shortcut.
    validated = Seed.model_validate(data)
    pis = expand_seeds([validated])[0]
    doc = Document(synthesize_reference_rollouts(pis)[0].html)
    tag, attrs = doc.by_id(control["id"])
    rendered = next(item for item in doc.config["controls"] if item["id"] == control["id"])
    assert rendered == control
    if variant == "numeric_select":
        assert tag == "select" and isinstance(rendered["default_val"], float)
        assert [attrs["value"] for tag, attrs in doc.elements
                if tag == "option" and "selected" in attrs] == ["4"]
        # Numeric defaults are normalized to the declared option by parse(),
        # then syncControl() sets the native selection before the initial paint.
        assert 'options.find(v=>equivalentOption(v,raw))' in doc.scripts[-1]["content"]
        assert 'syncControl(def,controls[def.id]);' in doc.scripts[-1]["content"]
    else:
        assert tag == "button" and attrs["type"] == "button"
        assert attrs["aria-pressed"] == "false" and attrs["data-value"] == str(control["default_val"])
        assert 'if(def.tag==="button")' in doc.scripts[-1]["content"]


@pytest.mark.parametrize("option,value,equivalent", [
    ("4", 4.0, True), ("4", "4.0", True), ("4", " 4e0 ", True),
    ("-3", -3.0, True), ("salt", "salt", True), ("salt", "sugar", False),
    ("4", "", False), ("4", True, False), ("4", None, False),
    ("4", "NaN", False), ("4", float("inf"), False),
    ("Infinity", "inf", False), ("4", "5", False),
])
def test_option_equivalence_matches_finite_numeric_contract(option, value, equivalent):
    assert worker_module._equivalent_option(option, value) is equivalent


@pytest.mark.parametrize("value", [4.0, "4.0", "4e0"])
def test_numeric_select_markup_preserves_declared_strings_and_selects_default(task, value):
    control = task.controls_contract[1].model_dump(mode="json")
    control["default_val"] = value
    doc = Document(worker_module._controls_markup([control]))
    options = [attrs for tag, attrs in doc.elements if tag == "option"]
    assert [attrs["value"] for attrs in options] == control["options"]
    assert [attrs["value"] for attrs in options if "selected" in attrs] == ["4"]


def test_quadratic_geometry_uses_raw_coefficients_and_only_deliberate_discriminant_delta(assets):
    # Structural regressions only: the parent owns numeric/browser execution.
    source = assets["svg_primitives.js"].split("math_c10_quadratic_discriminant_v1:", 1)[1]
    source = source.split("sci_c10_optics_thin_lens_v1:", 1)[0]
    assert "rawD=b*b-4*a*cc" in source
    assert "delta=s.discriminant-round(rawD,2)" in source
    assert "drawD=rawD+delta" in source
    assert "Math.sqrt(drawD)" in source
    assert "vertexY=-rawD/(4*a)+shift" in source
    assert "y=a*x*x+b*x+cc+shift" in source
    assert "Math.sqrt(s.discriminant)" not in source


def test_rounding_uses_binary_rational_not_scaled_float_half_ties(assets):
    source = assets["svg_primitives.js"].split("const round =", 1)[1].split("function arrow", 1)[0]
    assert "DataView" in source and "getUint32" in source
    assert "BigInt(" in source and "remainder" in source
    assert "quotient%two" in source
    assert "n*factor" not in source and "Math.round" not in source
    # Esprima's numeric literal parser does not support BigInt literal syntax.
    assert not re.search(r"\b\d+n\b", source)


def test_reference_bridge_normalizes_finite_numeric_choices_without_changing_option_strings(task):
    bridge = Document(synthesize_reference_rollouts(task)[0].html).scripts[-1]["content"]
    helper = bridge.split("function equivalentOption(option,raw)", 1)[1].split("function parse", 1)[0]
    assert 'typeof raw!=="number"&&typeof raw!=="string"' in helper
    assert "Number(option),right=Number(raw)" in helper
    assert "Number.isFinite(left)&&Number.isFinite(right)&&left===right" in helper
    assert "return option;" in bridge


@pytest.mark.parametrize("path,value,message", [
    (("verification_oracle", "trusted_oracle_id"), "unknown_model_v1", "Unsupported reference oracle"),
    (("ui_complexity_budget", "max_controls"), 0, "Controls exceed"),
    (("ui_complexity_budget", "required_views"), ["another-view"], "only the sim-viewport"),
    *(((("ui_complexity_budget", "min_touch_target_px"), value, "positive finite"))
      for value in (True, "48", 0, -1, float("nan"), float("inf"))),
])
def test_reference_boundary_rejects_corrupted_snapshots(task, path, value, message):
    # Deliberately corrupted snapshots test renderer defenses independently from
    # the schema; valid seed variants are tested separately above.
    data = task.model_dump(mode="json")
    data[path[0]][path[1]] = value
    with pytest.raises(ValueError, match=message):
        worker_module._render_reference(SimpleNamespace(model_dump=lambda **kwargs: data), "gold")


@pytest.mark.parametrize("identifier", ["unsupported_v1", None, 42])
def test_code_prompt_rejects_unsupported_oracle(task, identifier):
    data = task.model_dump(mode="json")
    data["verification_oracle"]["trusted_oracle_id"] = identifier
    with pytest.raises(ValueError, match="unsupported trusted_oracle_id"):
        prompts.build_code_prompt(SimpleNamespace(model_dump=lambda **kwargs: data))


@pytest.mark.parametrize("invalid", [float("nan"), float("inf"), -float("inf")])
def test_json_serializers_reject_nonfinite_numbers(invalid):
    for serializer in (prompts._json, worker_module._json_script):
        with pytest.raises(ValueError):
            serializer({"value": invalid})


def test_invalid_control_tag_and_schema_input_fail_before_synthesis(task):
    control = task.controls_contract[0].model_dump(mode="json")
    control["tag"] = "textarea"
    with pytest.raises(ValueError, match="Unsupported control tag"):
        worker_module._controls_markup([control])
    data = task.model_dump(mode="json")
    data["controls_contract"][0]["default_val"] = 999
    with pytest.raises(ValidationError):
        PISSchema.model_validate(data)


@pytest.mark.parametrize("broken", ["@@UNKNOWN_MARKER@@", "<!doctype html><html></html>"])
def test_bad_template_markers_fail_closed(task, assets, monkeypatch, broken):
    monkeypatch.setattr(worker_module, "load_asset", lambda name: broken if name == "base_harness.html" else assets[name])
    with pytest.raises(ValueError, match="replacement markers"):
        synthesize_reference_rollouts(task)


def test_missing_template_asset_propagates(task, monkeypatch):
    monkeypatch.setattr(worker_module, "load_asset", Mock(side_effect=FileNotFoundError("fixture asset missing")))
    with pytest.raises(FileNotFoundError, match="fixture asset missing"):
        synthesize_reference_rollouts(task)


@pytest.mark.parametrize("name", ["../secrets", "", "svg_primitives.js/..", "https://example.invalid/template"])
def test_asset_loader_rejects_nonallowlisted_paths_without_io(name, monkeypatch):
    reader = Mock(side_effect=AssertionError("Disallowed asset was read"))
    monkeypatch.setattr(Path, "read_text", reader)
    with pytest.raises(ValueError, match="Unsupported template asset"):
        load_asset(name)
    reader.assert_not_called()


@pytest.mark.parametrize("name", ["base_harness.html", "svg_primitives.js"])
def test_asset_loader_uses_explicit_utf8(name, monkeypatch):
    reader = Mock(return_value="isolated local asset")
    monkeypatch.setattr(Path, "read_text", reader)
    assert load_asset(name) == "isolated local asset"
    reader.assert_called_once_with(encoding="utf-8")


@pytest.mark.parametrize("wrapper", ["{}", " \ufeff {} \n", "```html\n{}\n```", "```HTML\r\n{}\r\n```", "```\n{}\n```"])
def test_sanitize_accepts_one_document_and_prepends_offline_csp(wrapper):
    document = MINIMAL_HTML.replace("</head>", '<script>const x=1;</script></head>')
    clean = sanitize_html_output(wrapper.format(document))
    assert clean.startswith("<!doctype html>") and clean.endswith("</html>")
    assert "```" not in clean
    assert clean.index('http-equiv="Content-Security-Policy"') < clean.index("<script>")
    assert "connect-src &#x27;none&#x27;" in clean


@pytest.mark.parametrize("body", [
    '<svg><defs><clipPath id="clip-id"/></defs><g clip-path="url(#clip-id)"></g><use href="#shape"/></svg>',
    '<style>.local{clip-path:url( "#local" );fill:url(\'#paint\')}</style>',
    '<img src="data:image/png;base64,AA=="/>',
    '<a href="#local">Local reference</a>',
])
def test_sanitize_allows_only_local_svg_and_embedded_image_resources(body):
    document = MINIMAL_HTML.replace("<svg></svg>", body)
    assert body in sanitize_html_output(document)


@pytest.mark.parametrize("prefix", ["<!-- <head> -->", "<!--\r\n<head>\r\n-->\r\n"])
@pytest.mark.parametrize("head", ["<head>", '<HEAD data-note="a > b">'])
def test_sanitize_inserts_csp_in_real_head_not_a_comment(prefix, head):
    document = MINIMAL_HTML.replace("<html>", "<html>\r\n" + prefix).replace("<head>", head)
    document = document.replace("</head>", '<script>const ready=true;</script></head>')
    clean = sanitize_html_output(document)
    doc = Document(clean)
    heads = [index for index, (tag, _) in enumerate(doc.elements) if tag == "head"]
    assert len(heads) == 1
    tag, attrs = doc.elements[heads[0] + 1]
    assert tag == "meta" and attrs["http-equiv"] == "Content-Security-Policy"
    assert "connect-src 'none'" in attrs["content"]
    assert clean.count('http-equiv="Content-Security-Policy"') == 1
    assert prefix.replace("<head>", head) in clean


@pytest.mark.parametrize("body", [
    r"<style>@\69mport 'external.css';</style>",
    r"<style>@\000069 mport 'external.css';</style>",
    r"<style>@IM\50ORT 'external.css';</style>",
    r"<style>@\import 'external.css';</style>",
    "<style>@im/* hidden */port 'external.css';</style>",
    r"<style>.x{fill:u\72l(https://example.invalid/a)}</style>",
    r"<style>.x{fill:url(\68ttps://example.invalid/a)}</style>",
    r'<div style="background:u\72l(https://example.invalid/a)"></div>',
    r'<svg><g fill="u\72l(https://example.invalid/a)"></g></svg>',
])
def test_sanitize_rejects_escaped_css_imports_and_resource_urls(body):
    with pytest.raises(ValueError, match="CSS"):
        sanitize_html_output(MINIMAL_HTML.replace("<svg></svg>", body))


def test_sanitize_checks_css_contexts_without_rewriting_script_strings():
    body = (r'<style>.x{clip-path:u\72l(\23 clip-id)}</style>'
            r'<script>const example="url(https://example.invalid/a) @import";'
            r'const escaped="@\\69mport"; /* <head> */</script>')
    assert body in sanitize_html_output(MINIMAL_HTML.replace("<svg></svg>", body))


@pytest.mark.parametrize("css", [r".x{content:'\0'}", r".x{content:'\110000'}", r".x{content:'\d800'}",
                                 ".x{color:re\\\nd}"])
def test_css_escape_validation_handles_invalid_codepoints_and_line_continuations(css):
    assert worker_module._validate_css(css) is None


def test_sanitize_rejects_scripts_before_the_real_head():
    document = MINIMAL_HTML.replace("<head>", "<script>const x=1;</script><head>")
    with pytest.raises(ValueError, match="follow the document head"):
        sanitize_html_output(document)


@pytest.mark.parametrize("content", [
    None, "", "   ", "explanation " + MINIMAL_HTML,
    MINIMAL_HTML.removeprefix("<!doctype html>"),
    MINIMAL_HTML + MINIMAL_HTML,
    MINIMAL_HTML + " trailing commentary",
    MINIMAL_HTML.replace("</html>", ""),
    "```html " + MINIMAL_HTML + "```",
    "```html\n" + MINIMAL_HTML + "\n```\nextra",
    "```json\n" + MINIMAL_HTML + "\n```",
    MINIMAL_HTML.replace("<head></head>", ""),
    MINIMAL_HTML.replace("<head></head>", "<head></head><head></head>"),
    MINIMAL_HTML.replace("<body>", "<body><html>"),
    "<!doctype html><head></head><html><body></body></html>",
    MINIMAL_HTML.replace("</html>", "</html><p>extra</p></html>"),
    MINIMAL_HTML.replace("</html>", "</html></body></html>"),
    MINIMAL_HTML.replace("</html>", "</html>outside</html>"),
    MINIMAL_HTML.replace("<svg></svg>", "<pre>```code```</pre>"),
    MINIMAL_HTML.replace("<svg></svg>", "<style>@import 'external.css';</style>"),
    MINIMAL_HTML.replace("<svg></svg>", '<style>.x{background:url(https://example.invalid/a)}</style>'),
    MINIMAL_HTML.replace("<svg></svg>", '<style>.x{background:url(data:image/png;base64,AA==)}</style>'),
    MINIMAL_HTML.replace("<svg></svg>", '<meta http-equiv="REFRESH" content="0;url=elsewhere">'),
    MINIMAL_HTML.replace("<svg></svg>", '<script src=""></script>'),
])
def test_sanitize_rejects_empty_ambiguous_malformed_or_resource_loading_output(content):
    with pytest.raises(ValueError):
        sanitize_html_output(content)


@pytest.mark.parametrize("tag", ["iframe", "frame", "frameset", "object", "embed", "base", "form", "link"])
def test_sanitize_rejects_active_embedded_or_navigation_elements(tag):
    with pytest.raises(ValueError, match="Disallowed generated HTML element"):
        sanitize_html_output(MINIMAL_HTML.replace("<svg></svg>", f"<{tag}></{tag}>"))


@pytest.mark.parametrize("tag,attribute", [
    ("img", "src"), ("a", "href"), ("use", "xlink:href"), ("img", "srcset"),
    ("button", "formaction"), ("video", "poster"), ("div", "data"),
    ("a", "ping"), ("body", "background"), ("div", "action"),
])
def test_sanitize_rejects_external_resource_attributes(tag, attribute):
    body = f'<{tag} {attribute}="https://example.invalid/resource"></{tag}>'
    with pytest.raises(ValueError, match="external resources"):
        sanitize_html_output(MINIMAL_HTML.replace("<svg></svg>", body))


@pytest.mark.parametrize("kwargs", [
    {"timeout": 0}, {"timeout": -1}, {"timeout": True}, {"timeout": float("inf")}, {"timeout": float("nan")},
    {"max_retries": -1}, {"max_retries": True}, {"max_retries": 1.5},
    {"max_tokens": 0}, {"max_tokens": False}, {"max_tokens": 2.5},
    {"max_concurrency": 0}, {"max_concurrency": -1}, {"max_concurrency": True}, {"max_concurrency": 2.5},
])
def test_worker_rejects_invalid_constructor_limits(kwargs):
    with pytest.raises(ValueError):
        RolloutWorker(**kwargs)


@pytest.mark.asyncio
async def test_worker_lazily_constructs_optional_async_openai_once(task, monkeypatch):
    client = fake_client()
    constructor = Mock(return_value=client)
    monkeypatch.setitem(sys.modules, "openai", SimpleNamespace(AsyncOpenAI=constructor))
    worker = RolloutWorker(base_url="http://offline.invalid/v1", api_key="local", model="test-model",
                           timeout=7, max_retries=0, max_tokens=123, max_concurrency=1)
    constructor.assert_not_called()
    assert worker._get_client() is client and worker._get_client() is client
    constructor.assert_called_once_with(base_url="http://offline.invalid/v1", api_key="local", timeout=7, max_retries=0)
    result = await worker.synthesize(task)
    assert result.kind == "llm" and result.task_id == task.task_id and result.pis is task
    assert result.rollout_id == task.task_id + "__llm"
    assert result.generation_latency_sec == 0
    request = client.chat.completions.create.call_args.kwargs
    assert request == {"model": "test-model", "max_tokens": 123, "temperature": 0,
                       "messages": [{"role": "system", "content": prompts.SYSTEM_CODE_PROMPT},
                                    {"role": "user", "content": prompts.build_code_prompt(task)}]}
    await worker.aclose()
    client.aclose.assert_awaited_once()


@pytest.mark.asyncio
async def test_synthesize_sanitizes_fences_and_records_only_generation_latency(task, monkeypatch):
    ticks = iter([100.0, 100.25])
    monkeypatch.setattr(worker_module.time, "perf_counter", lambda: next(ticks))
    client = fake_client(f"```html\n{MINIMAL_HTML}\n```")
    async with RolloutWorker(client=client) as worker:
        result = await worker.synthesize(task)
    assert result.generation_latency_sec == 0.25
    assert result.html == sanitize_html_output(MINIMAL_HTML)
    assert result.kind == "llm"


@pytest.mark.asyncio
@pytest.mark.parametrize("result,message", [
    (SimpleNamespace(choices=[]), "no choices"),
    (response(finish_reason="length"), "truncated"),
    (response(None), "no textual content"),
    (response("  "), "no textual content"),
    (response([{"text": MINIMAL_HTML}]), "no textual content"),
    (response("not HTML"), "doctype"),
    (response("```html\n" + MINIMAL_HTML + "\n```\nextra"), "fenced document"),
    (response(MINIMAL_HTML.replace("<svg></svg>", '<img src="https://example.invalid/a">')), "external resources"),
])
async def test_synthesize_rejects_bad_response_shapes_and_documents(task, result, message):
    client = fake_client()
    client.chat.completions.create.return_value = result
    async with RolloutWorker(client=client) as worker:
        with pytest.raises(ValueError, match=message):
            await worker.synthesize(task)
    client.aclose.assert_awaited_once()


@pytest.mark.asyncio
async def test_client_error_propagates_and_context_still_closes(task):
    client = fake_client()
    client.chat.completions.create.side_effect = TimeoutError("isolated fake timeout")
    with pytest.raises(TimeoutError, match="isolated fake timeout"):
        async with RolloutWorker(client=client) as worker:
            await worker.synthesize(task)
    client.aclose.assert_awaited_once()


@pytest.mark.asyncio
@pytest.mark.parametrize("fenced", [False, True])
async def test_generate_pis_accepts_complete_valid_json_and_only_editable_prose(task, fenced):
    seed = next(seed for seed in load_canonical_seeds() if seed.seed_id == task.seed_id)
    data = task.model_dump(mode="json")
    data.update(guided_prompts=["Predict, move one control, and explain."],
                problem_description="Original guided activity.", scientific_notes="An authored idealization.")
    content = json.dumps(data)
    if fenced:
        content = "```json\n" + content + "\n```"
    before = task.model_dump(mode="json")
    client = fake_client(content)
    async with RolloutWorker(client=client) as worker:
        result = await worker.generate_pis(seed, task)
    assert result.model_dump(mode="json") == data
    assert task.model_dump(mode="json") == before
    request = client.chat.completions.create.call_args.kwargs
    assert request["messages"] == [{"role": "system", "content": prompts.SYSTEM_PIS_PROMPT},
                                   {"role": "user", "content": prompts.build_pis_prompt(seed, task)}]


@pytest.mark.asyncio
@pytest.mark.parametrize("field", ["guided_prompts", "problem_description", "scientific_notes"])
@pytest.mark.parametrize("payload", ["whole_oracle", "probes", "inputs", "values", "expected",
                                     "bare_expected", "probe_id", "control_id", "oracle_id"])
async def test_generate_pis_rejects_evaluation_payloads_laundered_into_editable_prose(task, field, payload):
    data = task.model_dump(mode="json")
    oracle = data["verification_oracle"]
    probe = oracle["probe_cases"][0]
    attacks = {
        "whole_oracle": json.dumps(oracle),
        "probes": json.dumps(oracle["probe_cases"]),
        "inputs": json.dumps(probe["control_inputs"]),
        "values": json.dumps(list(probe["control_inputs"].values())),
        "expected": 'The expected_state is {"fraction_decimal": 0.5}.',
        "bare_expected": '{"fraction_decimal": 0.5, "equivalent_num": 4, "equivalent_den": 8}',
        "probe_id": "Use " + probe["probe_id"] + " as the teaching example.",
        "control_id": "Set " + data["controls_contract"][0]["id"] + " to its example value.",
        "oracle_id": "Copy " + oracle["trusted_oracle_id"] + " into the implementation.",
    }
    text = "Original teaching guidance. " + attacks[payload]
    data[field] = [text] if field == "guided_prompts" else text
    PISSchema.model_validate(data)
    seed = next(seed for seed in load_canonical_seeds() if seed.seed_id == task.seed_id)
    before = task.model_dump(mode="json")
    async with RolloutWorker(client=fake_client(json.dumps(data))) as worker:
        with pytest.raises(ValueError, match="evaluation data"):
            await worker.generate_pis(seed, task)
    assert task.model_dump(mode="json") == before


@pytest.mark.asyncio
async def test_generate_pis_keeps_regular_numeric_teaching_prose_and_optional_notes_editable(task):
    data = task.model_dump(mode="json")
    data.update(guided_prompts=["Compare 1/2 with 2/4, then try 3 shares out of 4.",
                               "Use [1, 2, 3] to label shares, and explain [your prediction]."],
                problem_description=None, scientific_notes="")
    seed = next(seed for seed in load_canonical_seeds() if seed.seed_id == task.seed_id)
    async with RolloutWorker(client=fake_client(json.dumps(data))) as worker:
        result = await worker.generate_pis(seed, task)
    assert result.model_dump(mode="json") == data


@pytest.mark.asyncio
@pytest.mark.parametrize("path,value", [
    (("task_id",), "task_other"), (("seed_id",), "seed_other"), (("split",), "dev"),
    (("learner_profile",), "Counterfactual_Challenge"), (("pedagogical_mode",), "Exploratory_Sandbox"),
    (("ncert_alignment", "chapter_topic"), "Changed chapter"),
    (("ncert_alignment", "learning_outcome_code"), "LOCAL-OTHER"),
    (("ncert_alignment", "learning_outcome_text"), "Changed outcome"),
    (("ncert_alignment", "target_misconception"), "Changed misconception"),
    (("ui_complexity_budget", "min_touch_target_px"), 64),
    (("ui_complexity_budget", "required_views"), ["sim-viewport", "another-view"]),
    (("controls_contract", 0, "label"), "Changed control"),
    (("controls_contract", 0, "max_val"), 9),
    (("controls_contract", 0, "unit"), "changed-unit"),
    (("required_dom_readouts", 0, "tolerance"), 0.2),
    (("required_dom_readouts", 0, "testid"), "readout-changed"),
    (("verification_oracle", "oracle_type"), "Type2_Discrete_State_Table"),
    (("verification_oracle", "probe_cases", 0, "probe_id"), "changed_probe"),
    (("verification_oracle", "probe_cases", 0, "regime_name"), "Changed regime"),
    (("verification_oracle", "probe_cases", 1, "control_inputs", "ctrl_numerator"), 4),
])
async def test_generate_pis_rejects_schema_valid_protected_field_mutations(tasks, path, value):
    task = next(task for task in tasks if "fraction" in task.seed_id
                and task.learner_profile.value == "Remedial_Concrete"
                and task.pedagogical_mode.value == "Predict_Observe_Explain")
    data = task.model_dump(mode="json")
    node = data
    for key in path[:-1]:
        node = node[key]
    assert node[path[-1]] != value
    node[path[-1]] = value
    PISSchema.model_validate(data)  # Prove rejection is the protected-field check.
    seed = next(seed for seed in load_canonical_seeds() if seed.seed_id == task.seed_id)
    async with RolloutWorker(client=fake_client(json.dumps(data))) as worker:
        with pytest.raises(ValueError, match="authoritative scaffold"):
            await worker.generate_pis(seed, task)


@pytest.mark.asyncio
@pytest.mark.parametrize("field", ["controls_contract", "required_dom_readouts", "guided_prompts"])
async def test_generate_pis_contract_list_order_is_protected_but_guidance_is_editable(task, field):
    seed = next(seed for seed in load_canonical_seeds() if seed.seed_id == task.seed_id)
    data = task.model_dump(mode="json")
    data[field].reverse()
    PISSchema.model_validate(data)
    async with RolloutWorker(client=fake_client(json.dumps(data))) as worker:
        if field == "guided_prompts":
            assert (await worker.generate_pis(seed, task)).guided_prompts == data[field]
        else:
            with pytest.raises(ValueError, match="authoritative scaffold"):
                await worker.generate_pis(seed, task)


@pytest.mark.asyncio
@pytest.mark.parametrize("content", ["{}", "[]", '{"task_id":', "not json", "```json\n{}\n```\nextra"])
async def test_generate_pis_rejects_partial_malformed_or_nonobject_json(task, content):
    seed = next(seed for seed in load_canonical_seeds() if seed.seed_id == task.seed_id)
    async with RolloutWorker(client=fake_client(content)) as worker:
        with pytest.raises(ValueError):
            await worker.generate_pis(seed, task)


@pytest.mark.asyncio
async def test_generate_pis_rejects_unknown_json_fields(task):
    data = task.model_dump(mode="json")
    data["invented_score"] = 1
    seed = next(seed for seed in load_canonical_seeds() if seed.seed_id == task.seed_id)
    async with RolloutWorker(client=fake_client(json.dumps(data))) as worker:
        with pytest.raises(ValidationError, match="Extra inputs"):
            await worker.generate_pis(seed, task)


@pytest.mark.asyncio
@pytest.mark.parametrize("closer_type", ["aclose", "async_close", "sync_close", "absent", "no_client"])
async def test_close_alias_is_idempotent_for_client_variants(closer_type):
    closer = AsyncMock() if closer_type in {"aclose", "async_close"} else Mock()
    client = SimpleNamespace()
    if closer_type == "aclose":
        client.aclose = closer
        client.close = Mock(side_effect=AssertionError("aclose takes precedence"))
    elif closer_type in {"async_close", "sync_close"}:
        client.close = closer
    worker = RolloutWorker(client=None if closer_type == "no_client" else client)
    assert await worker.__aenter__() is worker
    await worker.close()
    await worker.aclose()
    await worker.__aexit__(None, None, None)
    if closer_type in {"aclose", "async_close"}:
        closer.assert_awaited_once()
    elif closer_type == "sync_close":
        closer.assert_called_once_with()
    else:
        closer.assert_not_called()
    with pytest.raises(RuntimeError, match="closed"):
        worker._get_client()
    with pytest.raises(RuntimeError, match="closed"):
        await worker.__aenter__()


@pytest.mark.asyncio
async def test_closed_worker_cannot_generate(task):
    client = fake_client()
    worker = RolloutWorker(client=client)
    await worker.aclose()
    with pytest.raises(RuntimeError, match="closed"):
        await worker.synthesize(task)
    client.chat.completions.create.assert_not_awaited()


@pytest.mark.asyncio
async def test_cleanup_error_propagates_without_duplicate_close():
    client = fake_client()
    client.aclose.side_effect = RuntimeError("fake cleanup failure")
    worker = RolloutWorker(client=client)
    with pytest.raises(RuntimeError, match="fake cleanup failure"):
        await worker.aclose()
    await worker.aclose()
    client.aclose.assert_awaited_once()


@pytest.mark.asyncio
async def test_concurrency_is_bounded_and_all_requests_finish_without_sleeps(task):
    client = fake_client()
    entered, release = asyncio.Event(), asyncio.Event()
    active = maximum = 0

    async def create(**kwargs):
        nonlocal active, maximum
        active += 1
        maximum = max(maximum, active)
        if active == 2:
            entered.set()
        try:
            await release.wait()
            return response()
        finally:
            active -= 1

    client.chat.completions.create.side_effect = create
    pending = []
    async with RolloutWorker(client=client, max_concurrency=2) as worker:
        try:
            pending = [asyncio.create_task(worker.synthesize(task)) for _ in range(7)]
            await asyncio.wait_for(entered.wait(), 2)
            assert active == maximum == 2
            assert client.chat.completions.create.await_count == 2
            release.set()
            results = await asyncio.wait_for(asyncio.gather(*pending), 2)
            assert len(results) == 7 and all(result.kind == "llm" for result in results)
            assert maximum == 2 and active == 0
        finally:
            release.set()
            for request in pending:
                if not request.done():
                    request.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
    client.aclose.assert_awaited_once()


@pytest.mark.asyncio
async def test_cancellation_releases_concurrency_slot(task):
    client = fake_client()
    entered, release = asyncio.Event(), asyncio.Event()

    async def create(**kwargs):
        entered.set()
        await release.wait()
        return response()

    client.chat.completions.create.side_effect = create
    async with RolloutWorker(client=client, max_concurrency=1) as worker:
        request = asyncio.create_task(worker.synthesize(task))
        try:
            await asyncio.wait_for(entered.wait(), 2)
            request.cancel()
            with pytest.raises(asyncio.CancelledError):
                await request
            release.set()
            assert (await asyncio.wait_for(worker.synthesize(task), 2)).kind == "llm"
        finally:
            request.cancel()
            await asyncio.gather(request, return_exceptions=True)


@pytest.mark.asyncio
async def test_client_failure_releases_concurrency_slot(task):
    client = fake_client()
    client.chat.completions.create.side_effect = [RuntimeError("fake model failure"), response()]
    async with RolloutWorker(client=client, max_concurrency=1) as worker:
        with pytest.raises(RuntimeError, match="fake model failure"):
            await worker.synthesize(task)
        assert (await asyncio.wait_for(worker.synthesize(task), 2)).kind == "llm"