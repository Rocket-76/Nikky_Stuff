"""Offline packaging and structural-audit contracts; IO stays in pytest temp dirs."""

from dataclasses import replace
import json
import sys

import pytest

from ncert_interact.generators.expand_tasks import expand_seeds
from ncert_interact.generators.package_dataset import DATASET_SYSTEM_PROMPT, package_dataset
from ncert_interact.generators.prompts import SYSTEM_CODE_PROMPT, concept_context
from ncert_interact.generators.rollout_worker import Rollout
from ncert_interact.schemas.pis_schema import PISSchema, VerificationReport
from ncert_interact.seeds import load_canonical_seeds
from ncert_interact.verifier.diversity_audit import audit_diversity


@pytest.fixture
def tasks():
    expanded = expand_seeds(load_canonical_seeds())
    first = min(expanded, key=lambda task: task.task_id)
    return sorted(
        (task for task in expanded if task.seed_id == first.seed_id
         and task.pedagogical_mode == first.pedagogical_mode),
        key=lambda task: task.learner_profile.value,
    )


def candidate(task, suffix="gold", *, kind=None, html=None, latency=2.0):
    return Rollout(
        task_id=task.task_id, rollout_id=f"{task.task_id}__{suffix}",
        kind=kind or suffix, generation_latency_sec=latency, pis=task,
        html=html or '<!doctype html><html><body><svg><circle/></svg>'
        '<script>function update(x) { return x * 2; }</script></body></html>',
    )


def verification(rollout, **changes):
    values = dict(
        task_id=rollout.task_id, rollout_id=rollout.rollout_id, exec_valid=True,
        controls_found_ratio=1.0, interaction_coverage=1.0,
        scientific_oracle_acc=1.0, ui_budget_compliance=True, passed_all=True,
        generation_latency_sec=rollout.generation_latency_sec,
        verification_latency_sec=4.0,
    )
    values.update(changes)
    return VerificationReport(**values)


def records(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream]


def test_sft_and_dpo_share_exact_prompt_full_completions_and_metadata(tasks, tmp_path):
    gold = candidate(tasks[0])
    model = candidate(tasks[0], "a_model", kind="llm")
    bad = candidate(tasks[0], "flawed_physics")
    stalled = candidate(tasks[0], "dead_slider")
    ui_only = candidate(tasks[0], "ui_only", kind="llm")
    exec_only = candidate(tasks[0], "execution_only", kind="llm")
    no_chosen = candidate(tasks[1], "flawed_physics")
    rollouts = [model, bad, gold, stalled, ui_only, exec_only, no_chosen]
    reports = [
        verification(model), verification(bad, passed_all=False, scientific_oracle_acc=.5),
        verification(gold), verification(stalled, passed_all=False, interaction_coverage=0.0),
        verification(ui_only, passed_all=False, ui_budget_compliance=False),
        verification(exec_only, passed_all=False, exec_valid=False,
                     scientific_oracle_acc=0.0, interaction_coverage=0.0),
        verification(no_chosen, passed_all=False, scientific_oracle_acc=0.0),
    ]
    result = package_dataset(rollouts, list(reversed(reports)), tmp_path)
    assert result["sft_records"] == 2 and result["dpo_pairs"] == 2
    assert result["summary"]["overall"]["tasks_without_passing_candidate"] == 1
    assert SYSTEM_CODE_PROMPT in DATASET_SYSTEM_PROMPT
    assert "<pis_json>" in DATASET_SYSTEM_PROMPT
    sft = records(tmp_path / "ncert_interact_sft.jsonl")
    dpo = records(tmp_path / "ncert_interact_dpo.jsonl")
    by_id = {record["metadata"]["rollout_id"]: record for record in sft}
    gold_record = by_id[gold.rollout_id]
    assert gold_record["messages"][:2] == [
        {"role": "system", "content": DATASET_SYSTEM_PROMPT},
        {"role": "user", "content": concept_context(gold.pis)},
    ]
    completion = '<pis_json>' + gold.pis.model_dump_json() + '</pis_json>\n' + gold.html
    assert gold_record["messages"][2] == {"role": "assistant", "content": completion}
    assert completion.count("<!doctype html>") == 1
    assert gold_record["metadata"]["task_id"] == gold.task_id
    assert gold_record["metadata"]["seed_id"] == gold.pis.seed_id
    assert gold_record["metadata"]["split"] == gold.pis.split
    assert {pair["metadata"]["rejected_rollout_id"] for pair in dpo} == {
        bad.rollout_id, stalled.rollout_id,
    }
    for pair in dpo:
        assert pair["prompt"] == gold_record["messages"][:2]
        assert pair["chosen"] == gold_record["messages"][2:]
        rejected = next(r for r in rollouts if r.rollout_id == pair["metadata"]["rejected_rollout_id"])
        assert pair["rejected"] == [{"role": "assistant", "content":
            '<pis_json>' + rejected.pis.model_dump_json() + '</pis_json>\n' + rejected.html}]
        assert pair["metadata"]["chosen_rollout_id"] == gold.rollout_id
        assert pair["metadata"]["split"] == gold.pis.split
        assert pair["metadata"]["failure_metrics"]["passed_all"] is False
    json.dumps(result, allow_nan=False)
    assert all(isinstance(path, str) for path in result["paths"].values())
    report_text = (tmp_path / "benchmark_report.md").read_text(encoding="utf-8")
    assert "deterministic smoke" in report_text
    assert "not model" in report_text
    assert "Exec%" in report_text and "PedVis%" in report_text
    assert (tmp_path / "diversity_report.json").is_file()
    second = tmp_path / "second"
    other = package_dataset(list(reversed(rollouts)), reports, second)
    assert other["summary"] == result["summary"]
    for name in ("ncert_interact_sft.jsonl", "ncert_interact_dpo.jsonl", "benchmark_report.md", "diversity_report.json"):
        assert (second / name).read_bytes() == (tmp_path / name).read_bytes()


@pytest.mark.parametrize("problem", [
    "duplicate_rollout", "duplicate_report", "missing_report", "orphan_report",
    "report_task", "pis_task", "latency", "negative_latency", "nan_latency",
    "task_split", "seed_split", "task_context",
])
def test_package_rejects_bad_joins_before_writing(tasks, tmp_path, problem):
    first = candidate(tasks[0])
    rollouts, reports = [first], [verification(first)]
    if problem == "duplicate_rollout":
        rollouts.append(first)
    elif problem == "duplicate_report":
        reports.append(reports[0])
    elif problem == "missing_report":
        reports.clear()
    elif problem == "orphan_report":
        reports.append(verification(replace(first, rollout_id="orphan")))
    elif problem == "report_task":
        reports[0] = verification(first, task_id="wrong_task")
    elif problem == "pis_task":
        rollouts[0] = replace(first, task_id="wrong_task")
    elif problem == "latency":
        reports[0] = verification(first, generation_latency_sec=9.0)
    elif problem in {"negative_latency", "nan_latency"}:
        rollouts[0] = replace(first, generation_latency_sec=-1.0 if problem == "negative_latency" else float("nan"))
    else:
        update = {"split": "test" if first.pis.split != "test" else "train"}
        if problem == "task_context":
            update = {"learner_profile": tasks[1].learner_profile}
        task = first.pis.model_copy(update=update)
        if problem == "seed_split":
            task = tasks[1].model_copy(update=update)
        second = candidate(task, "other", kind="llm")
        rollouts.append(second)
        reports.append(verification(second))
    output = tmp_path / "not_created"
    with pytest.raises((TypeError, ValueError)):
        package_dataset(rollouts, reports, output)
    assert not output.exists()


def test_package_rejects_schema_valid_default_metrics_claiming_success(tasks, tmp_path):
    rollout = candidate(tasks[0])
    report = VerificationReport(
        task_id=rollout.task_id, rollout_id=rollout.rollout_id, passed_all=True,
        generation_latency_sec=rollout.generation_latency_sec,
    )
    VerificationReport.model_validate(report.model_dump())
    snapshot = report.model_dump()
    output = tmp_path / "not_created"
    with pytest.raises(ValueError, match="inconsistent passed_all report"):
        package_dataset([rollout], [report], output)
    assert report.model_dump() == snapshot
    assert not output.exists()


@pytest.mark.parametrize("field,value", [
    ("exec_valid", False),
    ("console_errors", ["Uncaught error"]),
    ("controls_found_ratio", 1.0 - 1e-12),
    ("interaction_coverage", 1.0 - 1e-12),
    ("scientific_oracle_acc", 1.0 - 1e-12),
    ("ui_budget_compliance", False),
    ("spoofing_detected", True),
])
@pytest.mark.parametrize("mutation", ["model_copy", "assignment"])
def test_package_rejects_forged_positive_reports(tasks, tmp_path, field, value, mutation):
    rollout = candidate(tasks[0])
    report = verification(rollout)
    if mutation == "model_copy":
        report = report.model_copy(update={field: value})
    else:
        setattr(report, field, value)
    VerificationReport.model_validate(report.model_dump())
    snapshot = report.model_dump()
    output = tmp_path / "not_created"
    with pytest.raises(ValueError, match="inconsistent passed_all report"):
        package_dataset([rollout], [report], output)
    assert report.model_dump() == snapshot
    assert not output.exists()


@pytest.mark.parametrize("field", [
    "required_dom_readouts", "controls_contract", "verification_oracle",
    "ui_complexity_budget", "guided_prompts", "problem_description",
    "scientific_notes", "ncert_alignment",
])
@pytest.mark.parametrize("second_passes", [True, False])
def test_package_rejects_schema_valid_conflicting_full_task_contracts(
    tasks, tmp_path, field, second_passes,
):
    first = candidate(tasks[0])
    changed = first.pis.model_dump(mode="json")
    if field == "required_dom_readouts":
        changed[field][0]["tolerance"] = (changed[field][0]["tolerance"] or 0.0) + 0.25
    elif field == "controls_contract":
        changed[field][0]["label"] += " revised"
    elif field == "verification_oracle":
        changed[field]["probe_cases"][0]["regime_name"] += " revised"
    elif field == "ui_complexity_budget":
        changed[field]["min_touch_target_px"] += 1
    elif field == "guided_prompts":
        changed[field][0] += " Explain your reasoning."
    elif field == "ncert_alignment":
        changed[field]["learning_outcome_text"] += " Explain your reasoning."
    else:
        changed[field] = (changed[field] or "") + " Additional original guidance."
    altered_pis = PISSchema.model_validate(changed)
    assert altered_pis.model_dump(mode="json") != first.pis.model_dump(mode="json")
    assert concept_context(altered_pis) == concept_context(first.pis)
    second = candidate(altered_pis, "other", kind="llm")
    reports = [verification(first), verification(
        second, passed_all=second_passes,
        scientific_oracle_acc=1.0 if second_passes else 0.5,
    )]
    output = tmp_path / "not_created"
    with pytest.raises(ValueError, match="conflicting task contract"):
        package_dataset([first, second], reports, output)
    assert not output.exists()


def test_package_accepts_independent_identical_full_task_contracts(tasks, tmp_path):
    first = candidate(tasks[0])
    equivalent_pis = PISSchema.model_validate(first.pis.model_dump(mode="json"))
    assert equivalent_pis is not first.pis
    second = candidate(equivalent_pis, "flawed_physics")
    result = package_dataset([first, second], [
        verification(first), verification(second, passed_all=False, scientific_oracle_acc=0.5),
    ], tmp_path)
    assert result["sft_records"] == result["dpo_pairs"] == 1


def test_benchmark_keeps_denominators_metrics_splits_and_latencies_separate(tasks, tmp_path):
    gold = candidate(tasks[0], latency=2.0)
    spoof_a = candidate(tasks[0], "spoof_a", kind="telemetry_spoof", latency=6.0)
    spoof_b = candidate(tasks[1], "spoof_b", kind="telemetry_spoof", latency=10.0)
    reports = [
        verification(gold, passed_all=False, spoofing_detected=True),
        verification(spoof_a, passed_all=False, spoofing_detected=True,
                     interaction_coverage=.5, scientific_oracle_acc=.25,
                     ui_budget_compliance=False, verification_latency_sec=8.0),
        verification(spoof_b, passed_all=False, verification_latency_sec=12.0),
    ]
    summary = package_dataset([gold, spoof_a, spoof_b], reports, tmp_path)["summary"]
    kinds = summary["by_kind"]
    assert kinds["telemetry_spoof"]["spoofing_caught_pct"] == 50.0
    assert kinds["telemetry_spoof"]["spoofing_denominator"] == 2
    assert kinds["telemetry_spoof"]["exec_pct"] == 100.0
    assert kinds["telemetry_spoof"]["interact_pct"] == 75.0
    assert kinds["telemetry_spoof"]["sci_acc_pct"] == 62.5
    assert kinds["telemetry_spoof"]["ped_vis_pct"] == 50.0
    assert kinds["gold"]["spoofing_caught_pct"] is None
    assert kinds["gold"]["gold_false_positive_pct"] == 100.0
    assert summary["overall"]["generation_latency_sec_mean"] == 6.0
    assert summary["overall"]["verification_latency_sec_mean"] == 8.0
    assert summary["overall"]["spoofing_caught_pct"] == 50.0
    assert summary["overall"]["tasks"] == 2
    assert summary["by_split"][gold.pis.split]["rollouts"] == 3


def test_empty_package_and_audit_have_no_fabricated_rates(tmp_path):
    result = package_dataset([], [], tmp_path)
    assert result["sft_records"] == result["dpo_pairs"] == 0
    assert result["summary"]["overall"]["exec_pct"] is None
    assert (tmp_path / "ncert_interact_sft.jsonl").read_text() == ""
    diversity = audit_diversity([])
    assert diversity["comparisons"] == 0
    assert diversity["ast_diversity"] is None
    assert diversity["dom_diversity"] is None
    assert diversity["state_graph_diversity"] is None


def test_ast_and_dom_ignore_prose_identifiers_literals_and_data_attributes(tasks):
    pytest.importorskip("esprima")
    first = candidate(tasks[0], html='<!doctype html><html><body class="profile-a" data-profile="one">'
        '<p>Concrete 1</p><svg><circle cx="10"/></svg><script>'
        'const amount=2; function paint(value){ shape.setAttribute("r",value*amount); }'
        '</script><script type="application/json">{"label":"one"}</script></body></html>')
    second = candidate(tasks[1], html='<!doctype html><html><body class="profile-b" data-profile="two">'
        '<p>Challenge 99</p><svg><circle cx="900"/></svg><script>'
        'const scale=99; function render(radius){ node.setAttribute("radius",radius*scale); }'
        '</script><script type="application/json">{"different":true}</script></body></html>')
    result = audit_diversity([first, second])
    assert result["ast_parse_failures"] == 0
    assert result["ast_diversity"] == result["dom_diversity"] == 0.0
    assert result["comparisons"] == 1
    assert result["profiles"] == sorted([first.pis.learner_profile.value, second.pis.learner_profile.value])


def test_ast_branches_and_geometry_api_calls_and_dom_topology_change_signatures(tasks):
    pytest.importorskip("esprima")
    documents = [
        '<html><body><svg><circle/></svg><script>function f(x){return shape.circle(x ** 2);}</script></body></html>',
        '<html><body><svg><g><circle/><path/></g></svg><script>function f(x){if(x>0){return shape.path(x ** 2);}return 0;}</script></body></html>',
    ]
    rollouts = [candidate(task, html=html) for task, html in zip(tasks, documents)]
    result = audit_diversity(rollouts)
    assert 0.0 < result["ast_diversity"] <= 1.0
    assert 0.0 < result["dom_diversity"] <= 1.0
    third = candidate(tasks[1], html=documents[0].replace("shape.circle", "shape.path"))
    assert audit_diversity([rollouts[0], third])["ast_diversity"] > 0.0


def test_ast_parse_failure_is_reported_not_replaced_by_regex(tasks):
    pytest.importorskip("esprima")
    good = candidate(tasks[0])
    broken = candidate(tasks[1], html='<html><script>function ( {</script></html>')
    result = audit_diversity([good, broken])
    assert result["ast_parse_failures"] == 1
    assert result["ast_diversity"] is None
    assert result["ast_comparisons"] == 0
    assert result["dom_comparisons"] == 1
    assert result["ast_errors"][0]["rollout_id"] == broken.rollout_id
    assert result["ast_errors"][0]["script_index"] == 0


def test_missing_parser_is_explicit_and_does_not_break_other_metrics(tasks, monkeypatch):
    monkeypatch.setitem(sys.modules, "esprima", None)
    result = audit_diversity([candidate(task) for task in tasks[:2]])
    assert result["ast_parser_available"] is False
    assert result["ast_unavailable_rollouts"] == 2
    assert result["ast_diversity"] is None
    assert result["ast_parse_failures"] == 0
    assert result["dom_diversity"] == 0.0


def observed_probes(values, *, visual=True):
    return [dict(
        probe_id=f"probe_{index}", regime_name=f"regime_{index}",
        expected_state={"answer": value}, actual_sim_state={"answer": value},
        readouts={"readout-answer": str(value)}, visual_changed=visual, passed=True,
    ) for index, value in enumerate(values)]


def test_state_graph_uses_observations_changed_keys_and_topology_not_raw_values(tasks):
    first, second = [candidate(task) for task in tasks[:2]]
    reports = [verification(first, probe_details=observed_probes([1, 2, 3])),
               verification(second, probe_details=observed_probes([90, 80, 70]))]
    same = audit_diversity([first, second], reports)
    assert same["state_graph_diversity"] == 0.0
    assert same["state_graph_comparisons"] == 1
    assert same["state_graph_label"] == "observed probe transition graph, not inferred semantic equivalence"
    reports[1] = verification(second, probe_details=observed_probes([90, 90, 90], visual=False))
    different = audit_diversity([first, second], reports)
    assert 0.0 < different["state_graph_diversity"] <= 1.0
    for report in reports:
        report.probe_details = [{"expected_state": {"answer": 1}, "passed": True}]
    assert audit_diversity([first, second], reports)["state_graph_diversity"] is None


def test_state_graph_accepts_current_verifier_snapshot_shape_and_preserves_visibility(tasks):
    first, second = [candidate(task) for task in tasks[:2]]
    contract = first.pis.required_dom_readouts[0]

    def snapshots(values, *, by_testid=False, visible=True):
        return [dict(
            probe_id=f"probe_{index}", observed_state={contract.state_key: value},
            expected_state={contract.state_key: 10000 + index},
            readouts={contract.testid if by_testid else contract.state_key:
                      {"text": str(value), "visible": visible}},
            visual_changed=True, scientific_correct=True,
        ) for index, value in enumerate(values)]

    reports = [verification(first, probe_details=snapshots([1, 2, 3])),
               verification(second, probe_details=snapshots([30, 20, 10], by_testid=True))]
    assert audit_diversity([first, second], reports)["state_graph_diversity"] == 0.0
    reports[1].probe_details = snapshots([30, 20, 10], visible=False)
    assert audit_diversity([first, second], reports)["state_graph_diversity"] > 0.0


def test_missing_observation_breaks_transition_instead_of_joining_across_gap(tasks):
    first, second = [candidate(task) for task in tasks[:2]]
    complete = observed_probes([1, 2, 3])
    gap = [complete[0], {"expected_state": {"answer": 2}}, complete[2]]
    reports = [verification(first, probe_details=complete), verification(second, probe_details=gap)]
    assert audit_diversity([first, second], reports)["state_graph_diversity"] > 0.0


def test_dpo_falls_back_to_lexical_passing_model_and_includes_missing_control_failures(tasks, tmp_path):
    a = candidate(tasks[0], "a", kind="llm")
    z = candidate(tasks[0], "z", kind="llm")
    bad = candidate(tasks[0], "missing_controls", kind="llm")
    package_dataset([z, bad, a], [verification(z), verification(bad, passed_all=False,
        controls_found_ratio=.9), verification(a)], tmp_path)
    pairs = records(tmp_path / "ncert_interact_dpo.jsonl")
    assert len(pairs) == 1
    assert pairs[0]["metadata"]["chosen_rollout_id"] == a.rollout_id
    assert pairs[0]["metadata"]["rejected_rollout_id"] == bad.rollout_id


def test_audit_macro_weights_seed_mode_groups_not_their_candidate_counts(tasks):
    a, b = [candidate(task) for task in tasks[:2]]
    b = replace(b, html="<html><body><aside><svg><path/></svg></aside></body></html>")
    group_one = audit_diversity([a, b])["dom_diversity"]
    other_tasks = [task.pis.model_copy(update={
        "seed_id": "seed_second", "task_id": f"second_{index}"})
        for index, task in enumerate((a, b))]
    c, d = [candidate(task) for task in other_tasks]
    repeated = replace(c, rollout_id=c.rollout_id + "_repeat")
    result = audit_diversity([a, b, c, d, repeated])
    assert result["comparisons"] == 3
    assert result["dom_diversity"] == pytest.approx(group_one / 2)


def test_external_scripts_are_counted_as_unavailable_not_fetched(tasks):
    pytest.importorskip("esprima")
    external = candidate(tasks[0], html='<html><script src="https://invalid.example/script.js"></script></html>')
    result = audit_diversity([external])
    assert result["ast_parse_failures"] == 1
    assert "no resource was fetched" in result["ast_errors"][0]["error"]


def test_audit_compares_only_gold_cross_profile_same_seed_and_mode(tasks):
    first, second = [candidate(task) for task in tasks[:2]]
    negative = candidate(tasks[2], "flawed_physics")
    assert audit_diversity([first, negative])["comparisons"] == 0
    assert audit_diversity([first, replace(second, pis=first.pis)])["comparisons"] == 0
    changed = second.pis.model_copy(update={"pedagogical_mode": "Exploratory_Sandbox"
        if first.pis.pedagogical_mode.value != "Exploratory_Sandbox" else "Misconception_Debug"})
    assert audit_diversity([first, replace(second, pis=changed)])["comparisons"] == 0
    changed_seed = second.pis.model_copy(update={"seed_id": "seed_unrelated"})
    assert audit_diversity([first, replace(second, pis=changed_seed)])["comparisons"] == 0


@pytest.mark.parametrize("problem", ["duplicate_rollout", "duplicate_report", "orphan", "task_mismatch"])
def test_audit_rejects_ambiguous_evidence(tasks, problem):
    first = candidate(tasks[0])
    rollouts, reports = [first], [verification(first)]
    if problem == "duplicate_rollout":
        rollouts.append(first)
    elif problem == "duplicate_report":
        reports.append(reports[0])
    elif problem == "orphan":
        reports.append(verification(replace(first, rollout_id="orphan")))
    else:
        reports[0] = verification(first, task_id="wrong_task")
    with pytest.raises(ValueError):
        audit_diversity(rollouts, reports)