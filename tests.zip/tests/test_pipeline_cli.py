"""Hermetic CLI orchestration tests; browser/model metrics below are test doubles.

Only pytest's temporary directories are written. These tests do not establish
scientific/browser acceptance; the full reference pilot in CI owns that evidence.
"""

from __future__ import annotations

import hashlib
import json
import socket
from dataclasses import replace
from itertools import count
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, Mock, call, sentinel

import pytest
import pytest_asyncio
from pydantic import ValidationError

from ncert_interact.generators.expand_tasks import expand_seeds
from ncert_interact.generators.rollout_worker import Rollout
from ncert_interact.schemas import VerificationReport
from ncert_interact.seeds import load_canonical_seeds
from scripts import run_pilot_pipeline as pipeline


KINDS = ("gold", "dead_slider", "telemetry_spoof", "flawed_physics")
ENVIRONMENT_KEYS = ("NCERT_LLM_BASE_URL", "NCERT_LLM_MODEL", "OPENAI_API_KEY")
DUMMY_KEY = "unit-test-only-not-a-real-credential"


def report_for(candidate: Rollout, **changes) -> VerificationReport:
    """Independent fake metrics, not all derived from a single pass/fail flag."""
    interaction, science = {
        "gold": (1.0, 1.0),
        "dead_slider": (0.0, 0.25),
        "telemetry_spoof": (0.0, 0.5),
        "flawed_physics": (1.0, 0.0),
        "llm": (0.4, 0.8),
    }[candidate.kind]
    values = dict(
        task_id=candidate.task_id,
        rollout_id=candidate.rollout_id,
        exec_valid=True,
        console_errors=[],
        controls_found_ratio=1.0,
        interaction_coverage=interaction,
        scientific_oracle_acc=science,
        spoofing_detected=candidate.kind == "telemetry_spoof",
        ui_budget_compliance=True,
        probe_details=[{"source": "unit-test-double", "kind": candidate.kind}],
        generation_latency_sec=candidate.generation_latency_sec,
        verification_latency_sec=0.125,
        passed_all=candidate.kind == "gold",
    )
    values.update(changes)
    return VerificationReport(**values)


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


@pytest.fixture(scope="module")
def source_models():
    seed = load_canonical_seeds()[0]
    return seed, expand_seeds([seed])[:2]


@pytest_asyncio.fixture(autouse=True)
async def isolated_runtime(monkeypatch, tmp_path, source_models):
    """Establish the Windows asyncio self-pipe before forbidding socket IO."""
    seed, originals = source_models
    tasks = [task.model_copy(deep=True) for task in originals]
    generated = []

    def no_network(*args, **kwargs):
        pytest.fail("CLI unit tests must not contact a network service")

    def synthesize(task):
        candidates = [Rollout(
            task_id=task.task_id, rollout_id=f"{task.task_id}__{kind}",
            kind=kind, html=f"<!doctype html><html><body>π {kind}</body></html>",
            generation_latency_sec=0.0, pis=task,
        ) for kind in KINDS]
        generated.extend(candidates)
        return candidates

    async def verify(path, pis, **options):
        kind = path.stem.rsplit("__", 1)[-1]
        candidate = Rollout(
            task_id=pis.task_id, rollout_id=options["rollout_id"], kind=kind,
            html="unused", generation_latency_sec=options["generation_latency_sec"], pis=pis,
        )
        return report_for(candidate)

    browser = SimpleNamespace(close=AsyncMock())
    launch = AsyncMock(return_value=browser)
    playwright = MagicMock()
    playwright.__aenter__.return_value = SimpleNamespace(chromium=SimpleNamespace(launch=launch))
    playwright.__aexit__.return_value = False
    doubles = SimpleNamespace(
        tasks=tasks, seed=seed, generated=generated, browser=browser,
        launch=launch, playwright=playwright,
        playwright_factory=Mock(return_value=playwright),
        canonical=Mock(return_value=[seed]), external=Mock(return_value=[seed]),
        expand=Mock(return_value=tasks), synthesize=Mock(side_effect=synthesize),
        verify=AsyncMock(side_effect=verify),
        worker=Mock(side_effect=AssertionError("Unexpected real model-client construction")),
        package=Mock(return_value={
            "sft_records": 1, "dpo_pairs": 3,
            "paths": {"benchmark": str(tmp_path / "output" / "benchmark_report.md")},
        }),
    )
    # Keep module/env patches on the shared fixture stack: tests may override
    # them again, and all patches must unwind in reverse application order.
    with monkeypatch.context() as network_guard:
        monkeypatch.chdir(tmp_path)
        for key in ENVIRONMENT_KEYS:
            monkeypatch.delenv(key, raising=False)
        for target in ("create_connection", "getaddrinfo"):
            network_guard.setattr(socket, target, no_network)
        for target in ("connect", "connect_ex"):
            network_guard.setattr(socket.socket, target, no_network)
        for name, value in {
            "async_playwright": doubles.playwright_factory,
            "RolloutWorker": doubles.worker,
            "load_canonical_seeds": doubles.canonical,
            "load_seeds_jsonl": doubles.external,
            "expand_seeds": doubles.expand,
            "synthesize_reference_rollouts": doubles.synthesize,
            "verify_html_applet": doubles.verify,
            "package_dataset": doubles.package,
            # Replace only this module's clock, never asyncio/pytest's clock.
            "time": SimpleNamespace(perf_counter=Mock(side_effect=count(10.0, 0.25).__next__)),
        }.items():
            monkeypatch.setattr(pipeline, name, value)
        yield doubles


@pytest.fixture
def config(tmp_path):
    return pipeline.PipelineConfig(
        output_dir=tmp_path / "output", artifacts_dir=tmp_path / "artifacts",
    )


def test_packaged_defaults_do_not_read_model_environment(monkeypatch):
    monkeypatch.setenv("NCERT_LLM_BASE_URL", "https://unused.invalid/v1")
    monkeypatch.setenv("NCERT_LLM_MODEL", "unused-model")
    monkeypatch.setenv("OPENAI_API_KEY", DUMMY_KEY)
    resource = Mock(wraps=pipeline.files)
    monkeypatch.setattr(pipeline, "files", resource)
    loaded = pipeline.load_config()
    resource.assert_called_once_with("configs")
    assert loaded == pipeline.PipelineConfig()
    assert loaded.mode == "reference" and loaded.expected_seed_count == 240
    assert loaded.model_candidates == 2
    assert loaded.output_dir == Path("data/output")
    assert loaded.artifacts_dir == Path("data/rollouts")
    assert DUMMY_KEY not in loaded.model_dump_json()


def test_config_file_overrides_only_non_none_values(tmp_path, monkeypatch):
    path = tmp_path / "config.yaml"
    path.write_text("mode: llm\nworkers: 3\nrandom_seed: 9\nllm:\n  model: fixture-model\n", encoding="utf-8")
    resource = Mock(side_effect=AssertionError("An explicit configuration must not load packaged defaults"))
    monkeypatch.setattr(pipeline, "files", resource)
    loaded = pipeline.load_config(path, {"workers": 4, "mode": None, "output_dir": tmp_path / "custom"})
    assert loaded.workers == 4 and loaded.mode == "llm" and loaded.random_seed == 9
    assert loaded.output_dir == tmp_path / "custom"
    assert loaded.llm.model == "fixture-model" and loaded.llm.max_tokens == 12000
    resource.assert_not_called()


def test_missing_configuration_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        pipeline.load_config(tmp_path / "missing.yaml")


def test_malformed_yaml_raises(tmp_path):
    path = tmp_path / "config.yaml"
    path.write_text("llm: [unterminated\n", encoding="utf-8")
    with pytest.raises(pipeline.yaml.YAMLError):
        pipeline.load_config(path)


@pytest.mark.parametrize("text", ["", "null\n", "- reference\n", "42\n", "mode\n", "true\n"])
def test_configuration_requires_mapping(tmp_path, text):
    path = tmp_path / "config.yaml"
    path.write_text(text, encoding="utf-8")
    with pytest.raises(ValueError, match="YAML mapping"):
        pipeline.load_config(path)


@pytest.mark.parametrize("data", [
    {"unexpected": True}, {"mode": "unknown"}, {"workers": 0}, {"workers": 17},
    {"timeout_ms": 99}, {"timeout_ms": 60001},
    {"random_probe_count": -1}, {"random_probe_count": 101},
    {"expected_seed_count": 0}, {"model_candidates": 0}, {"model_candidates": 17},
    {"llm": {"extra": True}}, {"llm": {"timeout": 0}},
    {"llm": {"timeout": float("inf")}}, {"llm": {"timeout": float("nan")}},
    {"llm": {"max_retries": -1}}, {"llm": {"max_tokens": 0}},
])
def test_invalid_configuration_fields_rejected(tmp_path, data):
    path = tmp_path / "config.yaml"
    path.write_text(pipeline.yaml.safe_dump(data), encoding="utf-8")
    with pytest.raises(ValidationError):
        pipeline.load_config(path)


def test_jsonl_writes_utf8_newlines_and_creates_parent(tmp_path):
    path = tmp_path / "nested" / "evidence.jsonl"
    rows = [{"text": "π → ∞"}, {"count": 2}]
    pipeline._write_jsonl(path, rows)
    assert read_jsonl(path) == rows
    assert "π".encode() in path.read_bytes()
    assert path.read_bytes().endswith(b"\n") and b"\r\n" not in path.read_bytes()
    pipeline._write_jsonl(path, [])
    assert path.read_bytes() == b""
    with pytest.raises(ValueError, match="JSON compliant"):
        pipeline._write_jsonl(path, [{"invalid": float("nan")}])


@pytest.mark.parametrize(("endpoint", "sanitized"), [
    ("http://localhost:8000/v1", "http://localhost:8000/v1"),
    ("https://user:password@mock-only.invalid:8443/v1?token=secret#private",
     "https://mock-only.invalid:8443/v1"),
    ("https://user@mock-only.invalid/v1/?key=secret", "https://mock-only.invalid/v1/"),
    ("http://user:p%40ss@[::1]:8000/v1?token=secret#private", "http://[::1]:8000/v1"),
    ("https://mock-only.invalid?token=secret#private", "https://mock-only.invalid"),
])
def test_sanitized_endpoint_retains_only_server_and_path(endpoint, sanitized):
    assert pipeline._sanitize_endpoint(endpoint) == sanitized


@pytest.mark.asyncio
async def test_reference_pipeline_persists_all_four_candidates(config, isolated_runtime, capsys):
    fake = isolated_runtime
    result = await pipeline.run_pipeline(config, limit=1)
    fake.canonical.assert_called_once_with()
    fake.external.assert_not_called()
    fake.expand.assert_called_once_with([fake.seed], config.random_seed)
    fake.synthesize.assert_called_once_with(fake.tasks[0])
    fake.worker.assert_not_called()
    fake.launch.assert_awaited_once_with(headless=True, chromium_sandbox=True)
    fake.browser.close.assert_awaited_once_with()
    fake.playwright.__aexit__.assert_awaited_once_with(None, None, None)
    assert result["task_count"] == 1 and result["candidate_count"] == 4
    assert result["mode"] == "reference" and result["acceptance_errors"] == []
    assert (result["sft_records"], result["dpo_pairs"]) == (1, 3)
    assert result["pipeline_latency_sec"] > 0
    assert set(result["environment"]) == {"python", "platform", "playwright", "pydantic"}
    assert all(result["environment"].values())
    assert result["config"] == config.model_dump(mode="json")
    assert result["effective_llm"] is None
    assert result["effective_generation"] == {
        "mode": "reference", "renderer_version": pipeline.__version__,
    }
    assert json.loads((config.output_dir / "run_summary.json").read_text(encoding="utf-8")) == result
    assert read_jsonl(config.output_dir / "tasks.jsonl") == [fake.tasks[0].model_dump(mode="json")]
    candidates, reports, output = fake.package.call_args.args
    fake.package.assert_called_once()
    assert output == config.output_dir.resolve()
    assert [candidate.rollout_id for candidate in candidates] == sorted(candidate.rollout_id for candidate in candidates)
    assert {candidate.kind for candidate in candidates} == set(KINDS)
    assert all(candidate.generation_latency_sec > 0 for candidate in candidates)
    assert len({candidate.generation_latency_sec for candidate in candidates}) == 1
    manifest = read_jsonl(config.output_dir / "rollout_manifest.jsonl")
    assert len(manifest) == len(reports) == fake.verify.await_count == 4
    for candidate, record, report in zip(candidates, manifest, reports, strict=True):
        path = config.artifacts_dir / f"{candidate.rollout_id}.html"
        assert path.read_text(encoding="utf-8") == candidate.html
        assert record == {
            "task_id": candidate.task_id, "rollout_id": candidate.rollout_id,
            "kind": candidate.kind, "html_path": str(path.resolve()),
            "sha256": hashlib.sha256(candidate.html.encode()).hexdigest(),
            "generation_latency_sec": candidate.generation_latency_sec,
            "pis": candidate.pis.model_dump(mode="json"),
        }
        evidence = config.artifacts_dir / f"{candidate.rollout_id}.report.json"
        assert VerificationReport.model_validate_json(evidence.read_text(encoding="utf-8")) == report
        assert report.generation_latency_sec == candidate.generation_latency_sec
        fake.verify.assert_any_await(
            path, candidate.pis, rollout_id=candidate.rollout_id,
            generation_latency_sec=candidate.generation_latency_sec, browser=fake.browser,
            timeout_ms=config.timeout_ms, random_probe_count=config.random_probe_count,
            random_seed=config.random_seed,
        )
    assert read_jsonl(config.output_dir / "verification_reports.jsonl") == [r.model_dump(mode="json") for r in reports]
    assert {r.rollout_id.rsplit("__", 1)[1]: (r.interaction_coverage, r.scientific_oracle_acc) for r in reports} == {
        "gold": (1.0, 1.0), "dead_slider": (0.0, 0.25),
        "telemetry_spoof": (0.0, 0.5), "flawed_physics": (1.0, 0.0),
    }
    logs = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert len(logs) == 4
    for row, report in zip(logs, reports, strict=True):
        for metric in ("exec_valid", "interaction_coverage", "scientific_oracle_acc", "ui_budget_compliance",
                       "generation_latency_sec", "verification_latency_sec", "passed_all"):
            assert row[metric] == getattr(report, metric)


@pytest.mark.asyncio
async def test_external_seed_route_and_unlimited_tasks(config, isolated_runtime, tmp_path):
    bank = tmp_path / "mocked-bank.jsonl"
    config.expected_seed_count = 1
    result = await pipeline.run_pipeline(config, seed_jsonl=bank)
    isolated_runtime.external.assert_called_once_with(bank, 1)
    isolated_runtime.canonical.assert_not_called()
    assert result["task_count"] == 2 and result["candidate_count"] == 8
    assert isolated_runtime.synthesize.call_args_list == [call(task) for task in isolated_runtime.tasks]


@pytest.mark.asyncio
@pytest.mark.parametrize("limit", [0, -1, True, 1.5, "1"])
async def test_invalid_limits_fail_before_creating_outputs(config, isolated_runtime, limit):
    with pytest.raises(ValueError, match="limit must be a positive"):
        await pipeline.run_pipeline(config, limit=limit)
    assert not config.output_dir.exists() and not config.artifacts_dir.exists()
    isolated_runtime.synthesize.assert_not_called()
    isolated_runtime.playwright_factory.assert_not_called()


@pytest.mark.asyncio
async def test_resolved_output_directories_must_differ(config, isolated_runtime):
    config.artifacts_dir = config.output_dir / "nested" / ".."
    with pytest.raises(ValueError, match="must be distinct"):
        await pipeline.run_pipeline(config, limit=1)
    assert not config.output_dir.exists()
    isolated_runtime.playwright_factory.assert_not_called()


@pytest.mark.parametrize(("kind", "changes", "message"), [
    ("gold", {"passed_all": False}, "gold rejected"),
    ("dead_slider", {"passed_all": True}, "negative accepted"),
    ("dead_slider", {"interaction_coverage": 1.0}, "dead viewport missed"),
    ("telemetry_spoof", {"interaction_coverage": 1.0}, "dead viewport missed"),
    ("telemetry_spoof", {"spoofing_detected": False}, "telemetry spoof missed"),
    ("telemetry_spoof", {"scientific_oracle_acc": 1.0}, "scientific negative missed"),
    ("flawed_physics", {"scientific_oracle_acc": 1.0}, "scientific negative missed"),
    ("llm", {"exec_valid": False, "console_errors": ["test console failure"]}, "candidate execution failed"),
])
def test_each_acceptance_failure_branch(source_models, kind, changes, message):
    task = source_models[1][0]
    candidate = Rollout(task.task_id, f"{task.task_id}__{kind}", kind, "html", 0.25, task)
    report = report_for(candidate, **changes)
    suffix = ": ['test console failure']" if not report.exec_valid else ""
    assert pipeline._acceptance_errors([candidate], [report]) == [f"{message}: {candidate.rollout_id}{suffix}"]


def test_empty_acceptance_is_vacuous():
    assert pipeline._acceptance_errors([], []) == []


@pytest.mark.asyncio
async def test_acceptance_failure_still_writes_complete_summary(config, isolated_runtime):
    async def broken_report(path, pis, **options):
        candidate = Rollout(pis.task_id, path.stem, path.stem.rsplit("__", 1)[-1], "html",
                            options["generation_latency_sec"], pis)
        return report_for(candidate, passed_all=True, interaction_coverage=1.0,
                          scientific_oracle_acc=1.0, spoofing_detected=False,
                          exec_valid=False, console_errors=["fixture execution failure"])

    isolated_runtime.verify.side_effect = broken_report
    with pytest.raises(RuntimeError, match="Reference acceptance failed") as raised:
        await pipeline.run_pipeline(config, limit=1)
    summary = json.loads((config.output_dir / "run_summary.json").read_text(encoding="utf-8"))
    assert len(summary["acceptance_errors"]) == 12
    assert summary["acceptance_errors"][0] in str(raised.value)
    assert summary["acceptance_errors"][5] not in str(raised.value)
    assert len(read_jsonl(config.output_dir / "verification_reports.jsonl")) == 4
    isolated_runtime.package.assert_called_once()
    isolated_runtime.browser.close.assert_awaited_once()


@pytest.mark.asyncio
async def test_reference_provenance_ignores_model_environment_and_redacts_config(
    config, isolated_runtime, monkeypatch, capsys,
):
    config.llm.base_url = "https://config-user:config-password@config.invalid/v1?config-query#config-fragment"
    monkeypatch.setenv("NCERT_LLM_BASE_URL", "https://env-user:env-password@env.invalid/v1?env-query#env-fragment")
    monkeypatch.setenv("NCERT_LLM_MODEL", "unused-env-model")
    monkeypatch.setenv("OPENAI_API_KEY", DUMMY_KEY)
    result = await pipeline.run_pipeline(config, limit=1)
    assert result["effective_llm"] is None
    assert result["effective_generation"] == {
        "mode": "reference", "renderer_version": pipeline.__version__,
    }
    assert result["config"]["llm"]["base_url"] == "https://config.invalid/v1"
    assert "config-password" in config.llm.base_url
    isolated_runtime.worker.assert_not_called()
    persisted = (config.output_dir / "run_summary.json").read_text(encoding="utf-8")
    captured = capsys.readouterr()
    for secret in ("config-user", "config-password", "config-query", "config-fragment",
                   "env-user", "env-password", "env-query", "env-fragment", "unused-env-model", DUMMY_KEY):
        assert secret not in persisted + captured.out + captured.err


@pytest.mark.asyncio
@pytest.mark.parametrize("stage", ["launch", "verify", "package"])
async def test_failures_close_browser_and_preserve_available_evidence(config, isolated_runtime, stage):
    fake = isolated_runtime
    getattr(fake, stage).side_effect = RuntimeError(f"fixture {stage} failed")
    with pytest.raises(RuntimeError, match=f"fixture {stage} failed"):
        await pipeline.run_pipeline(config, limit=1)
    fake.playwright.__aexit__.assert_awaited_once()
    manifest = read_jsonl(config.output_dir / "rollout_manifest.jsonl")
    assert len(manifest) == 4
    assert all(record["pis"] == fake.tasks[0].model_dump(mode="json") for record in manifest)
    assert not (config.output_dir / "run_summary.json").exists()
    if stage == "launch":
        fake.browser.close.assert_not_awaited()
    else:
        fake.browser.close.assert_awaited_once()
    if stage == "package":
        assert len(read_jsonl(config.output_dir / "verification_reports.jsonl")) == 4
        assert len(list(config.artifacts_dir.glob("*.report.json"))) == 4
    else:
        fake.package.assert_not_called()
        assert not (config.output_dir / "verification_reports.jsonl").exists()


def model_worker(monkeypatch, isolated_runtime):
    templates = {}
    for task in isolated_runtime.tasks:
        templates[task.task_id] = Rollout(task.task_id, f"{task.task_id}__llm", "llm", "<html>mock</html>", 0.25, task)

    def generate_pis(seed, scaffold):
        return scaffold.model_copy(update={
            "guided_prompts": [f"Mock-authored guidance for {scaffold.task_id}"],
            "problem_description": f"Mock-authored description for {scaffold.task_id}",
            "scientific_notes": "Mock-authored scientific notes",
        }, deep=True)

    worker = SimpleNamespace(
        generate_pis=AsyncMock(side_effect=generate_pis),
        # A fresh dataclass is essential: orchestration appends candidate suffixes.
        synthesize=AsyncMock(side_effect=lambda pis: replace(templates[pis.task_id], pis=pis)),
    )
    manager = MagicMock()
    manager.__aenter__.return_value = worker
    manager.__aexit__.return_value = False
    factory = Mock(return_value=manager)
    monkeypatch.setattr(pipeline, "RolloutWorker", factory)

    async def verify(path, pis, **options):
        return report_for(Rollout(pis.task_id, path.stem, "llm", "html",
                                 options["generation_latency_sec"], pis))

    isolated_runtime.verify.side_effect = verify
    isolated_runtime.package.return_value = {"sft_records": 0, "dpo_pairs": 0, "paths": {}}
    return worker, manager, factory, templates


@pytest.mark.asyncio
@pytest.mark.parametrize("override_environment", [False, True])
async def test_llm_mode_uses_mock_worker_and_never_applies_reference_labels(
    config, isolated_runtime, monkeypatch, capsys, override_environment,
):
    config.mode = "llm"
    config.llm.model = "configured-model"
    config.llm.base_url = "https://config-user:config-password@config-only.invalid:8443/v1?config-query#config-fragment"
    environment_url = "https://env-user:env-password@mock-only.invalid:9443/v1?env-query#env-fragment"
    if override_environment:
        monkeypatch.setenv("NCERT_LLM_BASE_URL", environment_url)
        monkeypatch.setenv("NCERT_LLM_MODEL", "mock-only-model")
        monkeypatch.setenv("OPENAI_API_KEY", DUMMY_KEY)
    worker, manager, factory, templates = model_worker(monkeypatch, isolated_runtime)
    acceptance = Mock(side_effect=AssertionError("Reference acceptance must not run in model mode"))
    monkeypatch.setattr(pipeline, "_acceptance_errors", acceptance)
    result = await pipeline.run_pipeline(config, limit=2)
    options = config.llm.model_dump()
    if override_environment:
        options.update(base_url=environment_url, model="mock-only-model")
    factory.assert_called_once_with(**options, api_key=DUMMY_KEY if override_environment else "local",
                                    max_concurrency=config.workers)
    worker.generate_pis.assert_has_awaits([call(isolated_runtime.seed, task) for task in isolated_runtime.tasks])
    assert worker.synthesize.await_count == 4
    manager.__aexit__.assert_awaited_once_with(None, None, None)
    acceptance.assert_not_called()
    isolated_runtime.synthesize.assert_not_called()
    candidates, reports, _ = isolated_runtime.package.call_args.args
    assert len(candidates) == len({id(candidate) for candidate in candidates}) == 4
    assert {candidate.rollout_id for candidate in candidates} == {
        f"{task.task_id}__llm_{index:02d}" for task in isolated_runtime.tasks for index in (1, 2)
    }
    assert all(candidate.generation_latency_sec > 0.25 for candidate in candidates)
    assert all(candidate.pis.guided_prompts == [f"Mock-authored guidance for {candidate.task_id}"]
               for candidate in candidates)
    authored = {candidate.task_id: candidate.pis.model_dump(mode="json") for candidate in candidates}
    persisted_tasks = read_jsonl(config.output_dir / "tasks.jsonl")
    assert persisted_tasks == [authored[task.task_id] for task in isolated_runtime.tasks]
    assert all(task.guided_prompts != authored[task.task_id]["guided_prompts"] for task in isolated_runtime.tasks)
    worker.synthesize.assert_has_awaits([call(candidate.pis) for candidate in candidates], any_order=True)
    manifest = read_jsonl(config.output_dir / "rollout_manifest.jsonl")
    assert len(manifest) == len(candidates)
    for record, candidate in zip(manifest, candidates, strict=True):
        assert record["rollout_id"] == candidate.rollout_id
        assert record["pis"] == authored[candidate.task_id] == candidate.pis.model_dump(mode="json")
    persisted_reports = read_jsonl(config.output_dir / "verification_reports.jsonl")
    assert all(not report["passed_all"] for report in persisted_reports)
    assert {record["rollout_id"] for record in manifest} == {report["rollout_id"] for report in persisted_reports}
    assert all(template.rollout_id.endswith("__llm") and template.generation_latency_sec == 0.25
               for template in templates.values())
    assert all(not report.passed_all and report.exec_valid for report in reports)
    assert result["mode"] == "llm" and result["acceptance_errors"] == []
    assert result["task_count"] == 2 and result["candidate_count"] == 4
    effective_llm = {
        "model": options["model"],
        "base_url": "https://mock-only.invalid:9443/v1" if override_environment else "https://config-only.invalid:8443/v1",
    }
    assert result["effective_llm"] == effective_llm
    assert result["effective_generation"] == {
        "mode": "llm", **options, **effective_llm,
    }
    assert result["config"]["llm"] == {
        **config.llm.model_dump(), "base_url": "https://config-only.invalid:8443/v1",
    }
    assert "config-password" in config.llm.base_url
    assert json.loads((config.output_dir / "run_summary.json").read_text(encoding="utf-8")) == result
    captured = capsys.readouterr()
    secrets = (DUMMY_KEY, "OPENAI_API_KEY", "api_key", "config-user", "config-password", "config-query",
               "config-fragment", "env-user", "env-password", "env-query", "env-fragment")
    assert all(secret not in captured.out + captured.err + json.dumps(result) for secret in secrets)
    for directory in (config.output_dir, config.artifacts_dir):
        for path in directory.iterdir():
            persisted = path.read_text(encoding="utf-8")
            assert all(secret not in persisted for secret in secrets)
    isolated_runtime.browser.close.assert_awaited_once()


@pytest.mark.asyncio
@pytest.mark.parametrize("stage", ["generate_pis", "synthesize"])
async def test_llm_failures_exit_worker_without_starting_browser(config, isolated_runtime, monkeypatch, stage):
    config.mode = "llm"
    worker, manager, _, _ = model_worker(monkeypatch, isolated_runtime)
    getattr(worker, stage).side_effect = ValueError(f"mock {stage} failure")
    with pytest.raises(ValueError, match=f"mock {stage} failure"):
        await pipeline.run_pipeline(config, limit=1)
    manager.__aexit__.assert_awaited_once()
    isolated_runtime.playwright_factory.assert_not_called()
    isolated_runtime.package.assert_not_called()
    assert not (config.output_dir / "rollout_manifest.jsonl").exists()


def mock_cli_runner(monkeypatch, result=None, failure=None):
    # Do not create a second event loop (or an unawaited real coroutine) here.
    run = Mock(return_value=sentinel.pipeline_coroutine)
    runner = Mock(return_value=result, side_effect=failure)
    monkeypatch.setattr(pipeline, "run_pipeline", run)
    monkeypatch.setattr(pipeline, "asyncio", SimpleNamespace(run=runner))
    return run, runner


@pytest.mark.parametrize("explicit", [False, True])
def test_main_forwards_defaults_and_cli_overrides(config, monkeypatch, capsys, tmp_path, explicit):
    summary = dict(mode="reference", task_count=1, candidate_count=4, sft_records=1,
                   dpo_pairs=3, pipeline_latency_sec=0.5, paths={}, private_detail="not printed")
    loader = Mock(return_value=config)
    monkeypatch.setattr(pipeline, "load_config", loader)
    run, runner = mock_cli_runner(monkeypatch, result=summary)
    path, bank = tmp_path / "config.yaml", tmp_path / "bank.jsonl"
    argv = ["--config", str(path), "--mode", "llm", "--seed-jsonl", str(bank),
            "--expected-seed-count", "1", "--workers", "3", "--limit", "1",
            "--output-dir", str(config.output_dir), "--artifacts-dir", str(config.artifacts_dir),
            "--random-seed", "99"] if explicit else []
    assert pipeline.main(argv) == 0
    loader.assert_called_once_with(path if explicit else None, {
        "mode": "llm" if explicit else None, "expected_seed_count": 1 if explicit else None,
        "workers": 3 if explicit else None, "output_dir": config.output_dir if explicit else None,
        "artifacts_dir": config.artifacts_dir if explicit else None, "random_seed": 99 if explicit else None,
    })
    run.assert_called_once_with(config, seed_jsonl=bank if explicit else None, limit=1 if explicit else None)
    runner.assert_called_once_with(sentinel.pipeline_coroutine)
    captured = capsys.readouterr()
    assert captured.err == ""
    assert json.loads(captured.out) == {key: value for key, value in summary.items() if key != "private_detail"}


@pytest.mark.parametrize("failure", [ValueError("invalid fixture"), OSError("fixture IO failure"), RuntimeError("fixture rejection")])
def test_main_reports_pipeline_failures_without_tracebacks(config, monkeypatch, capsys, failure):
    monkeypatch.setattr(pipeline, "load_config", Mock(return_value=config))
    _, runner = mock_cli_runner(monkeypatch, failure=failure)
    assert pipeline.main([]) == 1
    runner.assert_called_once()
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == f"Pipeline failed: {failure}\n"


@pytest.mark.parametrize("content", [None, "[]", "workers: 0", "unknown_property: true"])
def test_main_configuration_errors_do_not_start_pipeline(tmp_path, content, monkeypatch, capsys):
    path = tmp_path / "bad.yaml"
    if content is not None:
        path.write_text(content, encoding="utf-8")
    run, runner = mock_cli_runner(monkeypatch)
    assert pipeline.main(["--config", str(path)]) == 1
    run.assert_not_called()
    runner.assert_not_called()
    captured = capsys.readouterr()
    assert captured.out == "" and captured.err.startswith("Pipeline failed:")
    assert "Traceback" not in captured.err


def test_help_exits_successfully_without_loading_config(monkeypatch, capsys):
    loader = Mock(side_effect=AssertionError("Help must not load configuration"))
    monkeypatch.setattr(pipeline, "load_config", loader)
    with pytest.raises(SystemExit) as raised:
        pipeline.main(["--help"])
    assert raised.value.code == 0
    assert "--seed-jsonl" in capsys.readouterr().out
    loader.assert_not_called()


@pytest.mark.parametrize("argv", [["--mode", "unsupported"], ["--workers", "not-an-integer"]])
def test_argparse_rejects_bad_options(argv, isolated_runtime, capsys):
    with pytest.raises(SystemExit) as raised:
        pipeline.main(argv)
    assert raised.value.code == 2
    assert "error:" in capsys.readouterr().err
    isolated_runtime.playwright_factory.assert_not_called()