"""Hermetic regression tests for the specified public contracts and calculations."""

import io
import json
import math
import random
import re
from collections import Counter
from itertools import product
from pathlib import Path
from unittest.mock import patch

import pytest
from pydantic import ValidationError

from ncert_interact.generators.expand_tasks import expand_seeds, split_seeds
from ncert_interact.oracles import ORACLE_REGISTRY, evaluate_oracle, register_oracle
from ncert_interact.schemas import (
    ControlContract, DOMReadoutContract, DevelopmentalBand, LearnerProfile,
    NCERTAlignment, OracleType, PISSchema, PedagogicalMode, Seed, TestProbeCase,
    UIComplexityBudget, VerificationOracleSpec, VerificationReport,
)
from ncert_interact.seeds import load_canonical_seeds, load_seeds_jsonl


IDS = {
    "math_c04_fraction_equivalence_v1", "evs_c04_solubility_floating_v1",
    "math_c05_angle_classifier_v1", "evs_c05_buoyancy_salinity_v1",
    "math_c09_circle_subtended_angle_v1", "sci_c09_bio_osmosis_v1",
    "math_c10_quadratic_discriminant_v1", "sci_c10_optics_thin_lens_v1",
}
FRACTION = "math_c04_fraction_equivalence_v1"
SOLUBILITY = "evs_c04_solubility_floating_v1"
ANGLE = "math_c05_angle_classifier_v1"
BUOYANCY = "evs_c05_buoyancy_salinity_v1"
CIRCLE = "math_c09_circle_subtended_angle_v1"
OSMOSIS = "sci_c09_bio_osmosis_v1"
QUADRATIC = "math_c10_quadratic_discriminant_v1"
LENS = "sci_c10_optics_thin_lens_v1"


@pytest.fixture
def seeds():
    return load_canonical_seeds()


@pytest.mark.parametrize("enum,names", [
    (DevelopmentalBand, ["Foundational_4_5", "Secondary_9_10"]),
    (LearnerProfile, ["Remedial_Concrete", "Standard_GradeLevel", "Counterfactual_Challenge"]),
    (PedagogicalMode, ["Predict_Observe_Explain", "Exploratory_Sandbox", "Misconception_Debug"]),
    (OracleType, ["Type1_Continuous_Algebraic", "Type2_Discrete_State_Table"]),
])
def test_exact_enum_names_and_values(enum, names):
    assert list(enum.__members__) == names
    assert [member.value for member in enum] == names


@pytest.mark.parametrize("model,fields", [
    (NCERTAlignment, "class_grade subject chapter_topic learning_outcome_code learning_outcome_text target_misconception"),
    (UIComplexityBudget, "developmental_band max_controls min_touch_target_px required_views"),
    (ControlContract, "id label tag min_val max_val step options default_val unit"),
    (DOMReadoutContract, "testid state_key dtype tolerance allowed_values unit"),
    (TestProbeCase, "probe_id regime_name control_inputs"),
    (VerificationOracleSpec, "oracle_type trusted_oracle_id probe_cases"),
    (Seed, "seed_id ncert_alignment problem_description controls_contract required_dom_readouts verification_oracle provenance mapping_status scientific_notes"),
    (PISSchema, "task_id seed_id split learner_profile pedagogical_mode ncert_alignment ui_complexity_budget guided_prompts controls_contract required_dom_readouts verification_oracle problem_description scientific_notes"),
    (VerificationReport, "task_id rollout_id exec_valid console_errors controls_found_ratio interaction_coverage scientific_oracle_acc spoofing_detected ui_budget_compliance probe_details generation_latency_sec verification_latency_sec passed_all"),
])
def test_exact_model_fields(model, fields):
    assert set(model.model_fields) == set(fields.split())
    assert model.model_config["extra"] == "forbid"


def test_canonical_distribution_and_provenance(seeds):
    assert len(seeds) == 8
    assert set(ORACLE_REGISTRY) == IDS
    assert {s.verification_oracle.trusted_oracle_id for s in seeds} == IDS
    assert Counter(s.ncert_alignment.class_grade for s in seeds) == {4: 2, 5: 2, 9: 2, 10: 2}
    assert len({s.seed_id for s in seeds}) == 8
    for seed in seeds:
        alignment = seed.ncert_alignment
        assert seed.provenance == "original" and seed.mapping_status == "unverified"
        assert alignment.learning_outcome_code.startswith(f"LOCAL-C{alignment.class_grade:02d}")
        assert "UNVERIFIED" in alignment.learning_outcome_text
        assert alignment.subject in ({"Mathematics", "Science_EVS"} if alignment.class_grade < 6 else {"Mathematics", "Science"})
        assert Seed.model_validate_json(seed.model_dump_json()) == seed
        assert "ui_complexity_budget" not in seed.model_dump()


def test_probes_are_full_default_first_distinct_and_not_expected_states(seeds):
    for seed in seeds:
        controls = {c.id: c for c in seed.controls_contract}
        probes = seed.verification_oracle.probe_cases
        assert len(probes) >= 3
        assert all(controls[key].accepts(value) for key, value in probes[0].control_inputs.items())
        assert probes[0].control_inputs == {c.id: c.default_val for c in controls.values()}
        states = []
        for probe in probes:
            assert set(probe.control_inputs) == set(controls)
            assert "expected_state" not in probe.model_dump()
            result = evaluate_oracle(seed.verification_oracle.trusted_oracle_id, probe.control_inputs)
            assert set(result) == {r.state_key for r in seed.required_dom_readouts}
            state = json.dumps(result, sort_keys=True)
            assert not states or state != states[-1]
            states.append(state)
        assert len(set(states)) >= 3


def test_expansion_grid_budgets_splits_and_independence(seeds):
    before = random.getstate()
    tasks = expand_seeds(seeds)
    splits = split_seeds(seeds)
    assert random.getstate() == before
    assert tasks == expand_seeds(list(reversed(seeds)))
    assert tasks != expand_seeds(seeds, random_seed=42)
    assert len(tasks) == len({t.task_id for t in tasks}) == 72
    assert {key: len(value) for key, value in splits.items()} == {"train": 6, "dev": 1, "test": 1}
    assert Counter(t.split for t in tasks) == {"train": 54, "dev": 9, "test": 9}
    membership = {s.seed_id: name for name, group in splits.items() for s in group}
    for seed in seeds:
        own = [t for t in tasks if t.seed_id == seed.seed_id]
        assert {(t.learner_profile, t.pedagogical_mode) for t in own} == set(product(LearnerProfile, PedagogicalMode))
        assert len({tuple(t.guided_prompts) for t in own}) == 9
    for task in tasks:
        assert re.fullmatch(r"[a-z][a-z0-9_]*", task.task_id)
        assert task.task_id == f"task_{task.seed_id}_{task.learner_profile.value}_{task.pedagogical_mode.value}".lower()
        assert task.split == membership[task.seed_id]
        budget = task.ui_complexity_budget
        foundational = task.ncert_alignment.class_grade in (4, 5)
        assert budget.max_controls == (3 if foundational else 5)
        assert budget.min_touch_target_px >= (48 if foundational else 36)
        assert budget.required_views == ["sim-viewport"]
        assert PISSchema.model_validate_json(task.model_dump_json()) == task
    tasks[0].controls_contract[0].label = "Only this copy"
    assert all(t.controls_contract[0].label != "Only this copy" for t in tasks[1:])
    assert all(s.controls_contract[0].label != "Only this copy" for s in seeds)


@pytest.mark.parametrize("random_seed", [2027, 42])
def test_expansion_preserves_whole_seed_ids_with_unique_deterministic_tasks(seeds, random_seed):
    seed_ids = ["demo", "seed_demo", "seed_seed_demo", "seed_" + "long_" * 80 + "demo"]
    variants = [seeds[0].model_copy(update={"seed_id": seed_id}, deep=True) for seed_id in seed_ids]
    tasks = expand_seeds(variants, random_seed=random_seed)
    assert tasks == expand_seeds(variants, random_seed=random_seed)
    assert tasks == expand_seeds(list(reversed(variants)), random_seed=random_seed)
    expected_ids = {
        f"task_{seed_id}_{profile.value}_{mode.value}".lower()
        for seed_id, profile, mode in product(seed_ids, LearnerProfile, PedagogicalMode)
    }
    assert len(tasks) == len({task.task_id for task in tasks}) == len(seed_ids) * 9
    assert {task.task_id for task in tasks} == expected_ids
    assert Counter(task.seed_id for task in tasks) == {seed_id: 9 for seed_id in seed_ids}
    assert all(re.fullmatch(r"[a-z][a-z0-9_]*", task.task_id) for task in tasks)
    assert any(len(task.task_id) > 256 for task in tasks)
    assert [seed.seed_id for seed in variants] == seed_ids


def test_split_transitive_chapter_and_oracle_concept_groups(seeds):
    # A shares an oracle with B; B shares a chapter with C. All must stay together.
    a = seeds[0].model_copy(deep=True)
    a.seed_id = "seed_concept_variant"
    a.ncert_alignment.chapter_topic = "An alternative chapter"
    c = seeds[1].model_copy(deep=True)
    c.seed_id = "seed_chapter_bridge"
    c.ncert_alignment.subject = "Mathematics"
    c.ncert_alignment.chapter_topic = "  AN   ALTERNATIVE CHAPTER  "
    partitions = split_seeds([*seeds, a, c])
    assert partitions == split_seeds([c, a, *reversed(seeds)])
    membership = {s.seed_id: name for name, group in partitions.items() for s in group}
    assert len({membership[s.seed_id] for s in (seeds[0], seeds[1], a, c)}) == 1
    assert len(membership) == 10
    assert split_seeds([]) == {"train": [], "dev": [], "test": []}
    assert expand_seeds([]) == []
    for size in (1, 2):
        assert len(split_seeds(seeds[:size])["train"]) == size
    for function in (expand_seeds, split_seeds):
        for invalid in ("invalid", [object()]):
            with pytest.raises(TypeError):
                function(invalid)
        with pytest.raises(ValueError, match="duplicate"):
            function([seeds[0], seeds[0]])
        with pytest.raises(TypeError):
            function(seeds, random_seed=True)


def test_jsonl_loader_uses_isolated_io_and_rejects_bad_banks(seeds):
    def load(text, expected_count=None):
        with patch.object(Path, "open", return_value=io.StringIO(text)):
            return load_seeds_jsonl(Path("bank.jsonl"), expected_count=expected_count)

    text = "\n".join(s.model_dump_json() for s in seeds) + "\n"
    assert load(text, 8) == seeds
    assert load(text) == seeds
    with pytest.raises(ValueError, match="240"):
        load(text, 240)
    for invalid in ("", "\n", "{}", "{bad", seeds[0].model_dump_json() + "\n\n"):
        with pytest.raises(ValueError):
            load(invalid)
    with pytest.raises(ValueError, match="duplicate"):
        load(seeds[0].model_dump_json() + "\n" + seeds[0].model_dump_json())
    for count in (True, -1, 0, 1.5):
        with pytest.raises(ValueError):
            load(text, count)


@pytest.mark.parametrize("n,d,m,comparison", [
    (1, "4", 2, "Less than 1/2"), (2, 4.0, 3, "Equal to 1/2"),
    (8, "2.0", 1, "Greater than 1/2"),
])
def test_fraction_formula_and_html_denominators(n, d, m, comparison):
    assert evaluate_oracle(FRACTION, {"ctrl_numerator": n, "ctrl_denominator": d, "ctrl_multiplier": m}) == {
        "fraction_decimal": round(n / float(d), 4), "equivalent_num": n * m,
        "equivalent_den": float(d) * m, "comparison_to_half": comparison,
    }


@pytest.mark.parametrize("substance,stir", list(product(["salt", "sugar", "sand", "chalk_powder", "cooking_oil"], ["unstirred", "stirred"])))
def test_solubility_equilibrium_and_simplified_snapshot(substance, stir):
    result = evaluate_oracle(SOLUBILITY, {"ctrl_substance": substance, "ctrl_stir_state": stir})
    if substance in {"salt", "sugar"}:
        expected = "Soluble (Clear Solution)"
        light = "Transparent" if stir == "stirred" else "Cloudy/Opaque"
    elif substance == "cooking_oil":
        expected, light = "Insoluble (Floats on Top)", "Transparent"
    else:
        expected, light = "Insoluble (Settles at Bottom)", "Cloudy/Opaque"
    assert result == {"solubility_state": expected, "light_passage": light}


@pytest.mark.parametrize("angle,category", [(10, "Acute (< 90°)"), (89.5, "Acute (< 90°)"), (90, "Right (= 90°)"), (120.25, "Obtuse (> 90°)"), (170, "Obtuse (> 90°)")])
def test_angles_accept_continuous_values(angle, category):
    assert evaluate_oracle(ANGLE, {"ctrl_angle_deg": angle}) == {
        "angle_deg": angle, "complement_deg": max(0, 90 - angle),
        "supplement_deg": 180 - angle, "angle_category": category,
    }


@pytest.mark.parametrize("spoons,obj,state", [
    (0, "raw_egg", "Sinks to Bottom"), (4, "raw_egg", "Suspended"),
    (10, "raw_egg", "Floats at Surface"), (10, "iron_nail", "Sinks to Bottom"),
    (0, "wood_block", "Floats at Surface"),
])
def test_buoyancy_density_thresholds(spoons, obj, state):
    assert evaluate_oracle(BUOYANCY, {"ctrl_salt_spoons": spoons, "ctrl_object": obj}) == {
        "fluid_density": round(1 + .015 * spoons, 3), "buoyancy_state": state,
    }


def test_circle_continuous_formula():
    span, radius = 83.5, 7.25
    assert evaluate_oracle(CIRCLE, {"ctrl_arc_span_deg": span, "ctrl_radius_cm": radius}) == {
        "central_angle_deg": span, "inscribed_angle_deg": .5 * span,
        "chord_length_cm": round(2 * radius * math.sin(math.radians(span / 2)), 2),
        "theorem_ratio": 2,
    }


@pytest.mark.parametrize("solution,flow,plant_state,rbc_state,volume", [
    ("hypotonic", "Endosmosis (Inward)", "Turgid (Wall Pressure Balances)", "Burst (Hemolysis)", 100),
    ("isotonic", "Dynamic Equilibrium (Zero Net)", "Normal / Flaccid", "Normal / Flaccid", 70),
    ("hypertonic", "Exosmosis (Outward)", "Plasmolysed / Shriveled", "Plasmolysed / Shriveled", 35),
])
def test_osmosis_and_absent_rbc_vacuole(solution, flow, plant_state, rbc_state, volume):
    for cell, state, pct in (("plant_onion_cell", plant_state, volume), ("red_blood_cell", rbc_state, 0)):
        assert evaluate_oracle(OSMOSIS, {"ctrl_solution_type": solution, "ctrl_cell_type": cell}) == {
            "net_water_flow": flow, "cell_state": state, "vacuole_volume_pct": pct,
        }


@pytest.mark.parametrize("a,b,c,nature", [
    ("1", 0, -4, "Two Distinct Real Roots (D > 0)"),
    (1, 2, 1, "Two Equal Real Roots (D = 0)"),
    ("1.0", 0, 1, "No Real Roots (D < 0)"),
    (.5, 1.25, -2.5, "Two Distinct Real Roots (D > 0)"),
    (-3, -6, -6, "No Real Roots (D < 0)"),
])
def test_quadratic_formula_allows_floats_independent_of_ui_step(a, b, c, nature):
    numeric_a = float(a)
    d = b * b - 4 * numeric_a * c
    assert evaluate_oracle(QUADRATIC, {"ctrl_a": a, "ctrl_b": b, "ctrl_c": c}) == {
        "discriminant": round(d, 2), "vertex_x": round(-b / (2 * numeric_a), 2),
        "vertex_y": round(-d / (4 * numeric_a), 2), "root_nature": nature,
    }


@pytest.mark.parametrize("u,position,nature", [
    (50, "finite", "Real, Inverted, Diminished"),
    (30, "finite", "Real, Inverted, Same Size"),
    (22, "finite", "Real, Inverted, Magnified"),
    (15, "finite", "Parallel Rays / Image at Infinity"),
    (10, "finite", "Virtual, Erect, Magnified"),
    (50, "infinity", "Real, Inverted, Point-sized (Object at Infinity)"),
])
def test_six_lens_regimes(u, position, nature):
    result = evaluate_oracle(LENS, {"ctrl_u_dist": u, "ctrl_f_len": 15, "ctrl_object_at_infinity": position})
    assert result["image_nature"] == nature
    if position == "infinity":
        assert result["v_dist"] == 15 and result["magnification"] == 0
    elif u == 15:
        assert result["v_dist"] == result["magnification"] == "Infinity"
    else:
        assert result["v_dist"] == pytest.approx(u * 15 / (u - 15))
        assert result["magnification"] == pytest.approx(15 / (15 - u))


def test_lens_boundary_precedence_optional_position_and_float_inputs():
    for u in (14.9995, 15.0005):
        assert evaluate_oracle(LENS, {"ctrl_u_dist": u, "ctrl_f_len": 15})["v_dist"] == "Infinity"
    for u in (29.9995, 30.0005):
        assert evaluate_oracle(LENS, {"ctrl_u_dist": u, "ctrl_f_len": 15})["image_nature"] == "Real, Inverted, Same Size"
    result = evaluate_oracle(LENS, {"ctrl_u_dist": 25.75, "ctrl_f_len": 12.25})
    assert result["v_dist"] == pytest.approx(25.75 * 12.25 / 13.5)


def test_seed_specific_controls_probes_and_scientific_notes(seeds):
    by_id = {s.verification_oracle.trusted_oracle_id: s for s in seeds}
    assert len(by_id[FRACTION].controls_contract) == 3
    assert next(c for c in by_id[FRACTION].controls_contract if c.id == "ctrl_denominator").options == ["2", "4", "8"]
    assert by_id[QUADRATIC].controls_contract[0].options == ["-3", "-2", "-1", "1", "2", "3"]
    assert all(c.step == 1 for c in by_id[QUADRATIC].controls_contract[1:])
    assert "snapshot" in by_id[SOLUBILITY].scientific_notes.lower()
    assert "no vacuole" in by_id[OSMOSIS].scientific_notes.lower()
    assert [(p.control_inputs["ctrl_u_dist"], p.control_inputs["ctrl_f_len"], p.control_inputs["ctrl_object_at_infinity"]) for p in by_id[LENS].verification_oracle.probe_cases] == [
        (50, 15, "finite"), (30, 15, "finite"), (22, 15, "finite"),
        (15, 15, "finite"), (10, 15, "finite"), (50, 15, "infinity"),
    ]


def test_control_domains_and_html_equivalence():
    select = ControlContract(id="ctrl_choice", label="Choice", tag="select", options=["-2", "1", "3"], default_val="1")
    for accepted in (1, 1.0, "1.0", "-2", -2, "3"):
        assert select.accepts(accepted)
    for rejected in (True, "one", 2, None, float("nan"), float("inf")):
        assert not select.accepts(rejected)
    slider = ControlContract(id="ctrl_range", label="Range", tag="input_range", min_val=0, max_val=2, step=.5, default_val=1)
    assert slider.accepts(1.5) and slider.accepts("1.5")
    assert not any(slider.accepts(v) for v in (1.25, -1, 3, True, float("inf")))
    button = ControlContract(id="ctrl_button", label="State", tag="button", options=["stirred", "unstirred"], default_val="stirred")
    assert button.accepts("unstirred") and not button.accepts("other")
    for update in ({"step": 0}, {"max_val": None}, {"min_val": 2}, {"default_val": .25}, {"options": ["1"]}, {"id": "wrong"}):
        with pytest.raises(ValidationError):
            ControlContract.model_validate({**slider.model_dump(), **update})
    for update in ({"options": []}, {"options": ["1", "1.0"]}, {"default_val": "other"}, {"max_val": 2}):
        with pytest.raises(ValidationError):
            ControlContract.model_validate({**select.model_dump(), **update})


@pytest.mark.parametrize("overrides", [{}, {"allowed_values": None}])
def test_string_readout_optional_domain_accepts_only_nonblank_strings(overrides):
    readout = DOMReadoutContract(testid="readout-state", state_key="state", dtype="string_enum", **overrides)
    assert readout.allowed_values is None
    for value in ("Ready", "A new state", "1", "Infinity", "  padded state  ", "Ω"):
        assert readout.accepts(value)
    for value in ("", " \t\n", None, True, 1, 1.0, [], {}):
        assert not readout.accepts(value)
    assert DOMReadoutContract.model_validate_json(readout.model_dump_json()) == readout


def test_string_readout_declared_domain_requires_exact_membership():
    choices = ["Ready", "ready", "1", "1.0"]
    readout = DOMReadoutContract(
        testid="readout-state", state_key="state", dtype="string_enum", allowed_values=choices,
    )
    for value in choices:
        assert readout.accepts(value)
    for value in ("Unknown", "READY", " Ready ", "", " \t\n", None, True, 1, 1.0, [], {}):
        assert not readout.accepts(value)


@pytest.mark.parametrize("dtype", ["numeric", "string_enum"])
@pytest.mark.parametrize("allowed_values", [[], ["Ready", "Ready"], [""], [" \t\n"], [1]])
def test_readout_declared_domains_are_nonempty_distinct_nonblank_strings(dtype, allowed_values):
    with pytest.raises(ValidationError):
        DOMReadoutContract(testid="readout-state", state_key="state", dtype=dtype, allowed_values=allowed_values)


@pytest.mark.parametrize("model_type", [Seed, PISSchema])
@pytest.mark.parametrize("domain", ["omitted", "none", "excluded"])
def test_seed_and_task_validate_oracle_string_states_against_optional_domains(seeds, model_type, domain):
    source = seeds[0] if model_type is Seed else expand_seeds([seeds[0]])[0]
    data = source.model_dump()
    for readout in data["required_dom_readouts"]:
        if readout["dtype"] == "string_enum":
            if domain == "omitted":
                readout.pop("allowed_values")
            else:
                readout["allowed_values"] = None if domain == "none" else ["Not an oracle state"]
    if domain == "excluded":
        with pytest.raises(ValidationError, match="readout missing or incompatible"):
            model_type.model_validate(data)
    else:
        validated = model_type.model_validate(data)
        string_readouts = [readout for readout in validated.required_dom_readouts if readout.dtype == "string_enum"]
        assert string_readouts and all(readout.allowed_values is None for readout in string_readouts)
        for probe in validated.verification_oracle.probe_cases:
            state = evaluate_oracle(validated.verification_oracle.trusted_oracle_id, probe.control_inputs)
            assert all(readout.accepts(state[readout.state_key]) for readout in string_readouts)


@pytest.mark.parametrize("mutation", [
    "extra", "grade", "old_subject", "duplicate_control", "duplicate_readout", "duplicate_state",
    "duplicate_probe", "partial_probe", "probe_domain", "wrong_default", "unknown_oracle",
    "missing_readout", "no_probes", "expected_state", "same_inputs", "no_distinct_states",
    "nonfinite", "old_testid", "wrong_dtype", "too_many_controls", "wrong_provenance",
])
def test_seed_rejects_invalid_contracts(seeds, mutation):
    data = seeds[0].model_dump(mode="json")
    controls, readouts, spec = data["controls_contract"], data["required_dom_readouts"], data["verification_oracle"]
    probes = spec["probe_cases"]
    if mutation == "extra":
        data["ui_complexity_budget"] = {}
    elif mutation == "grade":
        data["ncert_alignment"]["class_grade"] = 6
    elif mutation == "old_subject":
        data["ncert_alignment"]["subject"] = "EVS"
    elif mutation == "duplicate_control":
        controls.append(controls[0].copy())
    elif mutation == "duplicate_readout":
        readouts.append(readouts[0].copy())
    elif mutation == "duplicate_state":
        readouts[1]["state_key"] = readouts[0]["state_key"]
    elif mutation == "duplicate_probe":
        probes[1]["probe_id"] = probes[0]["probe_id"]
    elif mutation == "partial_probe":
        probes[0]["control_inputs"].pop("ctrl_multiplier")
    elif mutation == "probe_domain":
        probes[1]["control_inputs"]["ctrl_multiplier"] = 99
    elif mutation == "wrong_default":
        controls[0]["default_val"] = 99
    elif mutation == "unknown_oracle":
        spec["trusted_oracle_id"] = "unknown"
    elif mutation == "missing_readout":
        readouts[0]["state_key"] = "absent"
    elif mutation == "no_probes":
        spec["probe_cases"] = []
    elif mutation == "expected_state":
        probes[0]["expected_state"] = {}
    elif mutation == "same_inputs":
        probes[1]["control_inputs"] = probes[0]["control_inputs"].copy()
    elif mutation == "no_distinct_states":
        data["required_dom_readouts"] = [readouts[-1]]
        for probe in probes:
            probe["control_inputs"]["ctrl_numerator"] = 1
            probe["control_inputs"]["ctrl_denominator"] = "8"
    elif mutation == "nonfinite":
        controls[0]["max_val"] = float("inf")
    elif mutation == "old_testid":
        readouts[0]["testid"] = "readout_wrong"
    elif mutation == "wrong_dtype":
        readouts[0].update(dtype="string_enum", allowed_values=["bad"])
    elif mutation == "too_many_controls":
        controls.append({**controls[0], "id": "ctrl_extra"})
    elif mutation == "wrong_provenance":
        data["provenance"] = "copied"
    with pytest.raises(ValidationError):
        Seed.model_validate(data)


@pytest.mark.parametrize("band,controls,touch", [("Foundational_4_5", 4, 48), ("Foundational_4_5", 3, 47), ("Secondary_9_10", 6, 36), ("Secondary_9_10", 5, 35)])
def test_invalid_band_budgets(band, controls, touch):
    with pytest.raises(ValidationError):
        UIComplexityBudget(developmental_band=band, max_controls=controls, min_touch_target_px=touch, required_views=["sim-viewport"])


def test_task_grade_band_and_actual_control_budget(seeds):
    task = next(t for t in expand_seeds(seeds) if t.verification_oracle.trusted_oracle_id == FRACTION)
    for update in ({"developmental_band": "Secondary_9_10", "max_controls": 5}, {"max_controls": 2}):
        data = task.model_dump(mode="json")
        data["ui_complexity_budget"].update(update)
        with pytest.raises(ValidationError):
            PISSchema.model_validate(data)
    with pytest.raises(ValidationError):
        DOMReadoutContract(testid="readout-value", state_key="value", dtype="numeric", tolerance=-.1)
    assert DOMReadoutContract(testid="readout-value", state_key="value", dtype="numeric").tolerance == .01


def test_oracles_reject_missing_extra_nonfinite_and_bad_domains(seeds):
    for seed in seeds:
        oracle_id = seed.verification_oracle.trusted_oracle_id
        values = {c.id: c.default_val for c in seed.controls_contract}
        for invalid in ({}, {**values, "extra": 1}, []):
            with pytest.raises((TypeError, ValueError)):
                evaluate_oracle(oracle_id, invalid)
        for key in values:
            for value in (None, True, [], float("nan"), float("inf"), 10 ** 400, "not_an_option"):
                with pytest.raises((TypeError, ValueError)):
                    evaluate_oracle(oracle_id, {**values, key: value})
    with pytest.raises(ValueError):
        evaluate_oracle(QUADRATIC, {"ctrl_a": "0", "ctrl_b": 0, "ctrl_c": 0})
    with pytest.raises(ValueError):
        evaluate_oracle(FRACTION, {"ctrl_numerator": 1.5, "ctrl_denominator": "4", "ctrl_multiplier": 2})
    with pytest.raises(ValueError):
        evaluate_oracle("unknown", {})


def test_registry_trusted_extension_and_guards():
    with pytest.raises(ValueError):
        register_oracle("../unsafe")
    with pytest.raises(ValueError):
        register_oracle(LENS)(lambda values: {})
    name = "test_trusted_extension"
    with pytest.raises(TypeError):
        register_oracle(name)(None)
    try:
        @register_oracle(name)
        def custom(values):
            return values["output"]

        assert custom({"output": {"value": 2}}) == {"value": 2}
        for output in ({}, [], {"value": []}, {"value": float("inf")}, {"bad/key": 1}):
            with pytest.raises(ValueError):
                evaluate_oracle(name, {"output": output})
        with pytest.raises(ValueError):
            evaluate_oracle(name, {1: "value"})
    finally:
        ORACLE_REGISTRY.pop(name, None)


def test_report_exact_fields_conservative_defaults_and_finite_metrics():
    report = VerificationReport(task_id="task_example", rollout_id="rollout_1")
    assert not report.passed_all and not report.exec_valid and not report.ui_budget_compliance
    assert report.scientific_oracle_acc == report.controls_found_ratio == report.interaction_coverage == 0
    assert report.console_errors == report.probe_details == []
    for field in ("scientific_oracle_acc", "controls_found_ratio", "interaction_coverage"):
        for invalid in (-.1, 1.1, True, "0.5", float("nan"), float("inf")):
            with pytest.raises(ValidationError):
                VerificationReport(task_id="task_example", rollout_id="r", **{field: invalid})
    for field in ("generation_latency_sec", "verification_latency_sec"):
        with pytest.raises(ValidationError):
            VerificationReport(task_id="task_example", rollout_id="r", **{field: -1})
    with pytest.raises(ValidationError):
        VerificationReport(task_id="task_example", rollout_id="r", passed=True)