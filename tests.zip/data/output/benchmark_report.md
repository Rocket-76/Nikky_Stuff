# NCERT interaction packaging benchmark

Local evidence inventory: deterministic smoke fixtures are not model results.

## Metrics by rollout kind

| Kind | N | Exec% | Interact% | SciAcc% | PedVis% | SpoofingCaught% | Spoof N | Gold false-positive% | Gold N | Generation sec mean | Verification sec mean |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| dead_slider | 72 | 100.000 | 0.000 | 8.126 | 100.000 | N/A | 0 | N/A | 0 | 0.001 | 5.112 |
| flawed_physics | 72 | 100.000 | 96.591 | 0.000 | 100.000 | N/A | 0 | N/A | 0 | 0.001 | 5.111 |
| gold | 72 | 100.000 | 100.000 | 100.000 | 100.000 | N/A | 0 | 0.000 | 72 | 0.001 | 5.017 |
| telemetry_spoof | 72 | 100.000 | 0.000 | 8.126 | 100.000 | 100.000 | 72 | N/A | 0 | 0.001 | 5.006 |
| Overall | 288 | 100.000 | 49.148 | 29.063 | 100.000 | 100.000 | 72 | 0.000 | 72 | 0.001 | 5.062 |

## Overall and split counts

| Scope | Seeds | Tasks | Rollouts | Passed all | SFT records | DPO pairs |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Overall | 8 | 72 | 288 | 72 | 72 | 216 |
| train | 6 | 54 | 216 | 54 | 54 | 162 |
| dev | 1 | 9 | 36 | 9 | 9 | 27 |
| test | 1 | 9 | 36 | 9 | 9 | 27 |

## Split metrics

### train

| Kind | N | Exec% | Interact% | SciAcc% | PedVis% | SpoofingCaught% | Spoof N | Gold false-positive% | Gold N | Generation sec mean | Verification sec mean |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| dead_slider | 54 | 100.000 | 0.000 | 7.700 | 100.000 | N/A | 0 | N/A | 0 | 0.001 | 5.391 |
| flawed_physics | 54 | 100.000 | 95.455 | 0.000 | 100.000 | N/A | 0 | N/A | 0 | 0.001 | 5.392 |
| gold | 54 | 100.000 | 100.000 | 100.000 | 100.000 | N/A | 0 | 0.000 | 54 | 0.001 | 5.265 |
| telemetry_spoof | 54 | 100.000 | 0.000 | 7.700 | 100.000 | 100.000 | 54 | N/A | 0 | 0.001 | 5.255 |
| Split total | 216 | 100.000 | 48.864 | 28.850 | 100.000 | 100.000 | 54 | 0.000 | 54 | 0.001 | 5.326 |

### dev

| Kind | N | Exec% | Interact% | SciAcc% | PedVis% | SpoofingCaught% | Spoof N | Gold false-positive% | Gold N | Generation sec mean | Verification sec mean |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| dead_slider | 9 | 100.000 | 0.000 | 11.111 | 100.000 | N/A | 0 | N/A | 0 | 0.001 | 3.954 |
| flawed_physics | 9 | 100.000 | 100.000 | 0.000 | 100.000 | N/A | 0 | N/A | 0 | 0.001 | 3.943 |
| gold | 9 | 100.000 | 100.000 | 100.000 | 100.000 | N/A | 0 | 0.000 | 9 | 0.001 | 3.986 |
| telemetry_spoof | 9 | 100.000 | 0.000 | 11.111 | 100.000 | 100.000 | 9 | N/A | 0 | 0.001 | 3.982 |
| Split total | 36 | 100.000 | 50.000 | 30.556 | 100.000 | 100.000 | 9 | 0.000 | 9 | 0.001 | 3.966 |

### test

| Kind | N | Exec% | Interact% | SciAcc% | PedVis% | SpoofingCaught% | Spoof N | Gold false-positive% | Gold N | Generation sec mean | Verification sec mean |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| dead_slider | 9 | 100.000 | 0.000 | 7.692 | 100.000 | N/A | 0 | N/A | 0 | 0.001 | 4.597 |
| flawed_physics | 9 | 100.000 | 100.000 | 0.000 | 100.000 | N/A | 0 | N/A | 0 | 0.001 | 4.596 |
| gold | 9 | 100.000 | 100.000 | 100.000 | 100.000 | N/A | 0 | 0.000 | 9 | 0.001 | 4.562 |
| telemetry_spoof | 9 | 100.000 | 0.000 | 7.692 | 100.000 | 100.000 | 9 | N/A | 0 | 0.001 | 4.538 |
| Split total | 36 | 100.000 | 50.000 | 28.846 | 100.000 | 100.000 | 9 | 0.000 | 9 | 0.001 | 4.573 |

## Structural diversity

Gold comparisons are within seed and pedagogical mode, across learner profiles only.

| Signature | Macro distance [0,1] | Valid comparisons |
| --- | ---: | ---: |
| ast | 0.000 | 72 |
| dom | 0.111 | 72 |
| state_graph | 0.000 | 72 |

AST parser available: True; script parse failures: 0; affected rollouts: 0; rollouts without parser: 0.

observed probe transition graph, not inferred semantic equivalence.

See diversity_report.json for per-comparison evidence, parse errors and methodological limitations.

Tasks without a passing candidate: 0.

## Definitions and limitations

- Reference labels identify deterministic smoke fixtures, not model results or evidence of research performance.
- Model-labeled candidates are reported separately by their actual kind; packaging itself does not run a model.
- Exec% = mean(exec_valid); Interact% = mean(interaction_coverage); SciAcc% = mean(scientific_oracle_acc), all over every report in the row.
- PedVis% = mean(ui_budget_compliance), a UI-budget proxy only, not a validated pedagogy or visual-quality score.
- SpoofingCaught% uses only actual telemetry_spoof labels. Gold false positives use only gold labels. Empty denominators are null/N/A.
- Generation and verification latencies are separate arithmetic means in seconds; matching generation latencies use a 1e-9 numeric tolerance.
- SFT includes exactly passed_all reports, which must have valid execution, no console errors, all three control/interaction/scientific ratios exactly 1, UI-budget compliance and no spoofing; inconsistent positive reports are rejected, not recomputed.
- DPO prefers passing gold then lexical rollout ID, and pairs every executable scientific/interaction failure with that task's chosen candidate. Candidates for the same task must have identical complete PIS JSON contracts, including prose.
- Execution failures are excluded from DPO because default zero scientific/interaction metrics cannot establish observed scientific negatives; pure UI failures are also excluded.
- Tasks without any passed_all candidate produce no DPO pairs; their count is reported separately.
- DPO per-kind counts are attributed to the rejected kind. Full PIS JSON is training output, not a public HTML-generation input.
- Every row retains seed/task/split metadata; each seed is restricted to one split. No split is reassigned during packaging.
- AST literals and local identifier names are stripped; member API names and control-flow structure remain.
- DOM is static ordered HTML tag topology with native input types/role hints; text, classes, IDs, data and geometry attribute values are ignored.
- Runtime-created SVG geometry is not included in static DOM signatures.
- Probe graph nodes use observed outputs/readouts; labels retain coarse types and changed keys, not raw numeric/text values.
- Observed state accepts actual_sim_state or the verifier's observed_state; readouts accept flat values or text/visible snapshots keyed by state_key or testid. Unknown observed keys are retained, not silently discarded.
- Repeated observed values establish graph topology; regime names are canonicalized by first occurrence, and degrees count distinct directed neighbors.
- Missing probes break transition traces. Expected states alone never establish an observed state.
- Missing evidence yields null, identical structural evidence yields zero. This is not a semantic-equivalence or learning-effectiveness claim.
