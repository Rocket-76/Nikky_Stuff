"""Expand, synthesize, independently verify, and package the complete local pilot."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import platform
import sys
import time
from importlib.metadata import version
from importlib.resources import files
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit, urlunsplit

import yaml
from pydantic import BaseModel, ConfigDict, Field
from playwright.async_api import async_playwright

from ncert_interact import __version__
from ncert_interact.generators.expand_tasks import expand_seeds
from ncert_interact.generators.package_dataset import package_dataset
from ncert_interact.generators.rollout_worker import Rollout, RolloutWorker, synthesize_reference_rollouts
from ncert_interact.schemas import PISSchema, VerificationReport
from ncert_interact.seeds import load_canonical_seeds, load_seeds_jsonl
from ncert_interact.verifier import verify_html_applet


class LLMConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    base_url: str = "http://localhost:8000/v1"
    model: str = "Qwen/Qwen2.5-Coder-32B-Instruct"
    timeout: float = Field(default=120, gt=0)
    max_retries: int = Field(default=2, ge=0)
    max_tokens: int = Field(default=12000, ge=1)


class PipelineConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    mode: Literal["reference", "llm"] = "reference"
    random_seed: int = 2027
    workers: int = Field(default=2, ge=1, le=16)
    timeout_ms: int = Field(default=15000, ge=100, le=60000)
    random_probe_count: int = Field(default=2, ge=0, le=100)
    output_dir: Path = Path("data/output")
    artifacts_dir: Path = Path("data/rollouts")
    expected_seed_count: int = Field(default=240, ge=1)
    model_candidates: int = Field(default=2, ge=1, le=16)
    llm: LLMConfig = Field(default_factory=LLMConfig)


def load_config(path: Path | None = None, overrides: dict | None = None) -> PipelineConfig:
    text = path.read_text(encoding="utf-8") if path else files("configs").joinpath("pipeline_config.yaml").read_text(encoding="utf-8")
    data = yaml.safe_load(text)
    if not isinstance(data, dict):
        raise ValueError("pipeline configuration must be a YAML mapping")
    data.update({key: value for key, value in (overrides or {}).items() if value is not None})
    return PipelineConfig.model_validate(data)


def _write_jsonl(path: Path, records: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        for record in records:
            stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")


def _sanitize_endpoint(base_url: str) -> str:
    """Retain the server and API path without URL credentials or tokens."""
    parts = urlsplit(base_url)
    return urlunsplit((parts.scheme, parts.netloc.rsplit("@", 1)[-1], parts.path, "", ""))


def _acceptance_errors(rollouts: list[Rollout], reports: list[VerificationReport]) -> list[str]:
    indexed = {report.rollout_id: report for report in reports}
    errors = []
    for rollout in rollouts:
        report = indexed[rollout.rollout_id]
        if rollout.kind == "gold" and not report.passed_all:
            errors.append(f"gold rejected: {rollout.rollout_id}")
        elif rollout.kind != "gold" and report.passed_all:
            errors.append(f"negative accepted: {rollout.rollout_id}")
        if rollout.kind in {"dead_slider", "telemetry_spoof"} and report.interaction_coverage == 1:
            errors.append(f"dead viewport missed: {rollout.rollout_id}")
        if rollout.kind == "telemetry_spoof" and not report.spoofing_detected:
            errors.append(f"telemetry spoof missed: {rollout.rollout_id}")
        if rollout.kind in {"telemetry_spoof", "flawed_physics"} and report.scientific_oracle_acc == 1:
            errors.append(f"scientific negative missed: {rollout.rollout_id}")
        if not report.exec_valid:
            errors.append(f"candidate execution failed: {rollout.rollout_id}: {report.console_errors}")
    return errors


async def run_pipeline(config: PipelineConfig, *, seed_jsonl: Path | None = None, limit: int | None = None) -> dict:
    """Run all stages. Reference mode raises if any labeled assertion fails."""
    started = time.perf_counter()
    seeds = load_seeds_jsonl(seed_jsonl, config.expected_seed_count) if seed_jsonl else load_canonical_seeds()
    tasks = expand_seeds(seeds, config.random_seed)
    if limit is not None:
        if type(limit) is not int or limit < 1:
            raise ValueError("limit must be a positive number of tasks")
        tasks = tasks[:limit]
    output, artifacts = config.output_dir.resolve(), config.artifacts_dir.resolve()
    if output == artifacts:
        raise ValueError("output_dir and artifacts_dir must be distinct")
    output.mkdir(parents=True, exist_ok=True)
    artifacts.mkdir(parents=True, exist_ok=True)
    rollouts: list[Rollout] = []
    semaphore = asyncio.Semaphore(config.workers)
    effective_llm = None
    if config.mode == "reference":
        effective_generation = {"mode": "reference", "renderer_version": __version__}
        for task in tasks:
            begin = time.perf_counter()
            generated = synthesize_reference_rollouts(task)
            # The pure reference factory is byte deterministic. Measure real
            # wall-clock synthesis here rather than reporting its sentinel zero.
            elapsed = (time.perf_counter() - begin) / len(generated)
            for candidate in generated:
                candidate.generation_latency_sec = elapsed
            rollouts.extend(generated)
    else:
        seed_by_id = {seed.seed_id: seed for seed in seeds}
        options = config.llm.model_dump()
        options["base_url"] = os.environ.get("NCERT_LLM_BASE_URL", options["base_url"])
        options["model"] = os.environ.get("NCERT_LLM_MODEL", options["model"])
        effective_llm = {"model": options["model"], "base_url": _sanitize_endpoint(options["base_url"])}
        effective_generation = {"mode": "llm", **options, **effective_llm}
        async with RolloutWorker(**options, api_key=os.environ.get("OPENAI_API_KEY", "local"), max_concurrency=config.workers) as worker:
            async def generate(scaffold: PISSchema) -> tuple[PISSchema, list[Rollout]]:
                async with semaphore:
                    begin = time.perf_counter()
                    pis = await worker.generate_pis(seed_by_id[scaffold.seed_id], scaffold)
                    schema_latency = time.perf_counter() - begin
                    results = []
                    for index in range(config.model_candidates):
                        candidate = await worker.synthesize(pis)
                        candidate.rollout_id += f"_{index + 1:02d}"
                        candidate.generation_latency_sec += schema_latency / config.model_candidates
                        results.append(candidate)
                    return pis, results
            batches = await asyncio.gather(*(generate(task) for task in tasks))
            tasks = [pis for pis, _ in batches]
            for _, batch in batches:
                rollouts.extend(batch)
    rollouts.sort(key=lambda candidate: candidate.rollout_id)
    _write_jsonl(output / "tasks.jsonl", [task.model_dump(mode="json") for task in tasks])
    manifest = []
    for candidate in rollouts:
        path = artifacts / (candidate.rollout_id + ".html")
        path.write_text(candidate.html, encoding="utf-8", newline="\n")
        manifest.append({"task_id": candidate.task_id, "rollout_id": candidate.rollout_id,
                         "kind": candidate.kind, "html_path": str(path),
                         "sha256": hashlib.sha256(candidate.html.encode()).hexdigest(),
                         "generation_latency_sec": candidate.generation_latency_sec,
                         "pis": candidate.pis.model_dump(mode="json")})
    _write_jsonl(output / "rollout_manifest.jsonl", manifest)
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True, chromium_sandbox=True)
        try:
            async def verify(candidate: Rollout) -> VerificationReport:
                async with semaphore:
                    report = await verify_html_applet(
                        artifacts / (candidate.rollout_id + ".html"), candidate.pis,
                        rollout_id=candidate.rollout_id,
                        generation_latency_sec=candidate.generation_latency_sec, browser=browser,
                        timeout_ms=config.timeout_ms, random_probe_count=config.random_probe_count,
                        random_seed=config.random_seed,
                    )
                    # Durable per-candidate evidence is written immediately; a
                    # later packaging failure cannot erase verification results.
                    (artifacts / (candidate.rollout_id + ".report.json")).write_text(report.model_dump_json(indent=2), encoding="utf-8")
                    print(json.dumps({"task_id": report.task_id, "rollout_id": report.rollout_id,
                                      **report.model_dump(include={"exec_valid", "interaction_coverage", "scientific_oracle_acc", "ui_budget_compliance", "generation_latency_sec", "verification_latency_sec", "passed_all"})}), flush=True)
                    return report
            reports = await asyncio.gather(*(verify(candidate) for candidate in rollouts))
        finally:
            await browser.close()
    _write_jsonl(output / "verification_reports.jsonl", [report.model_dump(mode="json") for report in reports])
    result = package_dataset(rollouts, reports, output)
    errors = _acceptance_errors(rollouts, reports) if config.mode == "reference" else []
    persisted_config = config.model_dump(mode="json")
    persisted_config["llm"]["base_url"] = _sanitize_endpoint(config.llm.base_url)
    result.update(mode=config.mode, task_count=len(tasks), candidate_count=len(rollouts),
                  pipeline_latency_sec=time.perf_counter() - started, acceptance_errors=errors,
                  environment={"python": platform.python_version(), "platform": platform.platform(),
                               "playwright": version("playwright"), "pydantic": version("pydantic")},
                  config=persisted_config, effective_llm=effective_llm,
                  effective_generation=effective_generation)
    (output / "run_summary.json").write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    if errors:
        raise RuntimeError(f"Reference acceptance failed ({len(errors)} checks). See verification reports: " + "; ".join(errors[:5]))
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--mode", choices=("reference", "llm"))
    parser.add_argument("--seed-jsonl", type=Path)
    parser.add_argument("--expected-seed-count", type=int)
    parser.add_argument("--workers", type=int)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--artifacts-dir", type=Path)
    parser.add_argument("--random-seed", type=int)
    args = parser.parse_args(argv)
    overrides = {name: getattr(args, name) for name in ("mode", "expected_seed_count", "workers", "output_dir", "artifacts_dir", "random_seed")}
    try:
        result = asyncio.run(run_pipeline(load_config(args.config, overrides), seed_jsonl=args.seed_jsonl, limit=args.limit))
    except (ValueError, OSError, RuntimeError) as exc:
        print(f"Pipeline failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps({key: result[key] for key in ("mode", "task_count", "candidate_count", "sft_records", "dpo_pairs", "pipeline_latency_sec", "paths")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())