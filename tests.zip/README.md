# NCERT Interact: clean-room interaction synthesis

An experimental Python pipeline for original, curriculum-oriented HTML/SVG
learning simulations, independent Python oracles, browser verification, and
evidence-based SFT/DPO packaging. This is **ACL 2027 preparation work**, not a
publication, accepted paper, official NCERT product, or validated educational
intervention. Reference fixtures are not model benchmarks. The checked local
reference run is recorded below and in the generated benchmark report.

## Verified local reference run

- **513 tests passed** in the requested Bash execution; **96.18% combined
  statement/branch coverage** (97.16% statements, 93.40% branches).
- Python 3.13.14, Playwright 1.64.1, Chromium, Windows 11.
- **72 tasks / 288 candidates**: all 72 gold candidates passed; all 216 negatives
  failed; all 72 telemetry spoofs were caught; zero gold spoofing false positives.
- **72 SFT records / 216 DPO pairs**, with 54/9/9 train/dev/test tasks.
- Gold Exec / Interact / SciAcc / PedVis: **100% / 100% / 100% / 100%**.
- Measured mean reference generation: **0.000905 sec/candidate**; browser
  verification: **5.061622 sec/candidate**; Bash pilot wall time: **749.511710 sec**.
- Structural macro distances: AST **0.000**, DOM **0.111**, observed state graph
  **0.000**. Shared executable renderer structure and state topology legitimately
  yield zero; this is not evidence of failed parsing or pedagogical equivalence.

See [data/output/benchmark_report.md](data/output/benchmark_report.md) and
[data/output/run_summary.json](data/output/run_summary.json) for the actual
decoupled metrics, denominators, split counts and execution configuration.

## Install and test

Use Python 3.11 or newer. From this repository's root, in an activated virtual
environment:

```shell
python -m pip install -e ".[dev]"
python -m playwright install chromium
python -m pytest tests/ -v
```

The fast, hermetic generation tests can run separately:

```shell
python -m pytest tests/test_generation.py -v
```

They use repository-local template fixtures and mocked asynchronous model
clients, block network connections, and do not launch Chromium, contact a model,
download weights, or need API credentials. Structural HTML assertions do **not**
replace the browser verifier. The full suite includes browser-dependent checks;
install Chromium before running those checks. Development coverage policy is at
least 80% of changed code, with an 80% repository-wide target; this is a target,
enforced by the supplied CI. The measured local result is reported above.

## Run the pilot

```shell
python -m scripts.run_pilot_pipeline
```

The default reference pilot uses eight original canonical seeds. Every seed is
expanded across three learner profiles and three pedagogical modes, producing
**8 × 9 = 72 tasks**. Each task has four deterministic executable reference
candidates: **288 documents**, not 288 independent concepts.

| Kind | Purpose |
| --- | --- |
| `gold` | Independent JavaScript conceptual implementation, synchronized controls, readouts, and SVG geometry. A label, not a bypass of verification. |
| `dead_slider` | Executable page whose interaction path is disabled. |
| `telemetry_spoof` | Computed telemetry changes while the visible readouts and drawing remain stale after initialization. This is an actual contradictory update path, not merely a misleading label. |
| `flawed_physics` | Executable interaction with deliberately incorrect scientific quantities or classifications. |

Reference acceptance must require **every gold candidate to pass, every negative
to fail, and every telemetry-spoof candidate to be detected**. A failed acceptance
condition produces exit status **1**; a report or output file alone does not mean
acceptance. The expected successful reference packaging is **72 SFT records and
216 DPO pairs**, conditional on actual passing browser evidence and executable
interaction/science failures for the three negatives. The verified local run
above achieved those counts. Missing dependencies, timeouts, execution
errors, or a failing gold candidate can reduce usable records and fail the run.

### CLI options and configuration

| Option | Meaning |
| --- | --- |
| `--config` | YAML configuration file; see [configs/pipeline_config.yaml](configs/pipeline_config.yaml). Explicit CLI values override configuration values. |
| `--mode reference` / `--mode llm` | Deterministic reference smoke run or opt-in external model generation. |
| `--seed-jsonl` | User-supplied JSONL bank of complete validated `Seed` records. Omit for the eight built-in seeds. |
| `--expected-seed-count` | Enforce the supplied bank size; the configuration expects 240 external seed records. It does not turn the canonical bank into 240 seeds. |
| `--workers` | Bound concurrent pipeline work. |
| `--limit` | Restrict expanded tasks for a smoke run; resulting counts are not full-pilot counts. |
| `--output-dir` | Directory for packaged datasets and benchmark/diversity reports. |
| `--artifacts-dir` | Directory for generated candidate HTML and verification artifacts. |
| `--random-seed` | Reproduce grouping/split assignment and randomized probes. |

The supplied configuration selects reference mode, random seed 2027, two
workers, a 15,000 ms verifier action timeout, isolated single-control probes,
an untouched initial-state check, two randomized domain probes,
`data/output` for packaged outputs, and `data/rollouts` for candidate artifacts.
`expected_seed_count: 240` applies to an external bank, not the canonical pilot.
`model_candidates: 2` configures two code candidates per task in LLM mode.
LLM configuration also includes request timeout, retries, and token limits.

A 240-record loader is provided; **a 240-seed dataset is not included or invented**.
The loader rejects malformed or blank JSONL records, duplicate seed IDs, invalid
contracts, invalid oracle inputs, and unexpected record counts. Provide your own
original/appropriately licensed bank and its provenance. No Google Drive download
is necessary; no supplied usable metadata is assumed and no records are inferred
from an unspecified link.

### Optional external LLM mode

```shell
python -m scripts.run_pilot_pipeline --mode llm
```

Start and provision an **external OpenAI-compatible server**, such as vLLM,
separately. Configure these environment variables outside source control:

| Variable | Purpose |
| --- | --- |
| `NCERT_LLM_BASE_URL` | OpenAI-compatible inference endpoint. |
| `NCERT_LLM_MODEL` | Model identifier exposed by that server. |
| `OPENAI_API_KEY` | Server credential, read from the environment, never committed or printed. |

The YAML defaults name `http://localhost:8000/v1` and
`Qwen/Qwen2.5-Coder-32B-Instruct`. The CLI **does not start vLLM, download a
32B model, or provision GPU resources**. LLM requests use the asynchronous
`AsyncOpenAI` interface with bounded concurrency, request timeouts, configured
retry/token limits, and explicit cleanup. Offline reference synthesis never
constructs a model client. An LLM run is not offline: the Python process contacts
the configured server, while the candidate Chromium context still has no network.

LLM mode first requests a **complete PIS** from a trusted scaffold. Schema
validation precedes an immutable-field comparison. Only `guided_prompts`,
`problem_description`, and `scientific_notes` are editable; task/seed/split,
profile/mode, alignment, budget, controls, readouts, and the complete oracle
contract stay protected. It then requests the configured number of code
candidates for each task. Code prompts contain the public contract and authored
equations/domain context, **not trusted probe cases or expected output tables**.
HTML is parsed/sanitized before browser execution; truncation, malformed content,
external resource references, and protected-field changes fail rather than being
silently repaired into a passing sample.

LLM packaging uses actual verifier results: passing candidates can enter SFT;
DPO requires an actual passing choice and an executable interaction/science
failure for the same task. No candidate is promoted because it is model-generated,
and a completed request is not a scientific-success claim. LLM record counts are
not fixed at the reference pilot's expected counts.

## Original scenarios and explicit scientific limits

All `LOCAL-...` learning-outcome codes are **provisional, authored, unverified local
mappings**, not official NCERT codes. Seeds declare `provenance="original"` and
`mapping_status="unverified"`. The repository does not reproduce copyrighted
textbook paragraphs or images, scrape textbook content, or claim an official
curriculum mapping review.

| Grade | Topic | Model scope / important limitation |
| --- | --- | --- |
| 4 | Fraction equivalence and comparison | Equal-share representations, including improper fractions; scaling numerator and denominator preserves value. |
| 4 | Solubility, settling, and floating | Stirring changes rate, **not equilibrium solubility**. Cloudy unstirred salt/sugar is a simplified transient snapshot, not evidence of insolubility. Saturation and realistic time evolution are omitted. |
| 5 | Angles, complements, and supplements | For obtuse angles, displayed complement is clamped to 0 as a contract convention, not a claim that a positive complement exists. |
| 5 | Buoyancy and salinity | Authored density-per-spoon constants, not a calibrated experimental dissolution/density law. |
| 9 | Central and inscribed circle angles | Both angles subtend the same minor arc; the inscribed vertex lies on the opposite arc. |
| 9 | Plant-cell and RBC osmosis | Mature RBCs have **no vacuole**: the readout is numeric **0** for every RBC state. Plant 100/70/35 vacuole percentages are illustrative proxies, not quantitative osmotic predictions. Zero net flow still permits opposing water movement. |
| 10 | Quadratic discriminant and vertex | Nonzero leading coefficient; classification uses the unrounded discriminant. UI integer steps are distinct from the independent oracle's continuous domain. |
| 10 | Convex thin lens, **six** regimes | Beyond 2f, at 2f, between f and 2f, at f, inside f, and **object at infinity**. The extra infinity select is a real control. Object at f produces literal `"Infinity"` readouts; an object at infinity instead gives image distance f and magnification 0. Signed distance/magnification and paraxial limitations apply. |

No non-finite numeric JSON values are allowed. The literal string `"Infinity"`
is a documented lens sentinel, not a numeric NaN/infinity escape hatch.

## Verification and threat model

The authoritative expected state is computed independently in Python from the
registered oracle and actual probe inputs. Candidate JavaScript is not trusted
as its own answer key. Verification cross-checks typed `window.__SIM_STATE__`,
visible DOM readouts, native controls, and concept-dependent geometry/raster
changes, including **text-masked** raster evidence so changed labels alone do not
count as a moving scientific diagram. Hidden/non-rendered output and telemetry-only
changes do not constitute visible evidence. Default-first probes are exercised
as transitions, not credited merely for matching the initial page.

Randomized domain probes supplement public probe cases without embedding those
cases in HTML/code prompts. Model-authored prose is also checked for explicit
copied probe payloads; this cannot rule out every paraphrase or covert encoding.
Each control is tested independently so one functioning listener cannot conceal
another dead control, and initial defaults are checked before events can repair
an incorrectly initialized applet. For osmosis, the public bank exhausts the finite
3-solution × 2-cell domain: additional seeded probes are explicitly labeled
**private replays**, not falsely described as unseen combinations. Other models
can draw unseen combinations within their declared domains. Finite probing is
not an exhaustive proof over continuous mathematical domains.

Failures are fail-closed. Isolated browser contexts, injected restrictive CSP,
blocked HTTP/WebSocket requests, disabled service workers/workers, no granted
permissions, and blocked remote resources keep candidate execution offline.
Generation sanitization is defense in depth, **not a JavaScript security sandbox**.

**Bounded guarantee:** candidate and instrumentation still share a JavaScript
realm. Deliberate same-realm API spoofing remains a caveat; raster, geometry,
visibility, and telemetry checks do not prove complete visual-semantic scientific
correctness or defeat every adversarial page. Human scientific/accessibility
review and stronger execution isolation remain necessary for research claims.
Run untrusted HTML under a **low-privilege container or similarly isolated
account**, with no mounted secrets, no inference tokens in its environment, and
OS-level egress restrictions. Keep model credentials solely in the trusted
generation process; browser CSP is not a replacement for host isolation.

## Outputs, splits, and interpretation

The packager writes four artifacts under the configured output directory:

| Output | Contents |
| --- | --- |
| `ncert_interact_sft.jsonl` | Exactly candidates with `passed_all`; assistant completion contains full PIS JSON followed by standalone HTML. |
| `ncert_interact_dpo.jsonl` | A verified passing choice paired with an executable interaction/science failure; same conceptual prompt and authoritative task. |
| `benchmark_report.md` | Actual aggregate/per-kind/per-split counts, separate metrics, spoof detection denominators, and latencies. |
| `diversity_report.json` | Structural signatures, distances, parser availability/failures, observed graph evidence, and limitations. |

Training completions use `<pis_json>...</pis_json>` followed by HTML; the online
code-generation response remains HTML-only. Complete PIS in the training output
is not permission to leak probe cases into executable HTML or learner guidance.
Packaging joins real rollout/report IDs, rejects missing/conflicting evidence,
and retains seed/task/split metadata. It never manufactures verification scores,
empty placeholders, or stub negatives. Execution failures and UI-only failures
are excluded from DPO: zero/default metrics after an execution failure do not
prove an observed scientific or interaction mistake. Tasks with no passing
candidate contribute no DPO pairs and are counted explicitly.

Seeds sharing a normalized grade/subject/chapter **or** a version-independent
oracle concept are grouped transitively before splitting. A seed's nine tasks
cannot cross partitions. With the canonical eight independent groups, expected
deterministic allocation is **6/1/1 seeds → 54 train / 9 dev / 9 test tasks**.
These split labels survive packaging; they are not reassigned to obtain desired
dataset sizes. Reference fixtures are smoke data, not held-out model performance.

### Four separate headline metrics

| Metric | Definition / interpretation |
| --- | --- |
| Exec% | Mean `exec_valid`: successful execution without recorded execution/console errors. |
| Interact% | Mean `interaction_coverage`: meaningful tested transitions with actual controls and visible diagram change. |
| SciAcc% | Mean `scientific_oracle_acc`: probe agreement across trusted state, visible readouts, and required visual evidence. |
| PedVis% | Mean `ui_budget_compliance`: **UI-budget proxy only**, not a validated pedagogy, learning-outcome, or complete visual-quality measure. |

Controls-found ratio is an additional diagnostic. Report generation and
verification latency **separately**, with real measured denominators and no
fabricated scores. The pure reference factory returns deterministic zero-latency
metadata; the CLI replaces it with measured batch synthesis time divided by four
candidates. This is measured renderer throughput, **not model speed**. Spoofing-caught rate uses only
telemetry-spoof candidates; gold false positives use only gold candidates.
Empty denominators are null/N/A, not invented perfect performance.

Diversity compares **AST structure, DOM structure, and observed state-transition
graphs**, within seed/mode across learner profiles. These are structural audits,
not guarantees of pedagogical diversity. Profiles implementing the same underlying
state machine may legitimately have **0 state-graph diversity**. Missing parser,
parse failures, or missing observed traces must remain visible, not be replaced
by a token/regex proxy or fake score. Different wording/colors alone do not
establish meaningful instructional diversity.

## Development and release discipline

Core modules live under [ncert_interact](ncert_interact/): strict schemas/seeds,
trusted oracles, task expansion, prompts/reference/async generation, verification,
and packaging. Packaged assets are local in
[ncert_interact/templates](ncert_interact/templates/). Existing tests cover
schemas/oracles, anti-spoofing, packaging/diversity, and generation contracts.

Use failing-first hermetic unit tests for new behavior, then run the full suite,
coverage, dependency/security checks, and controlled browser acceptance before
making release claims. These are required development/CI checks, not a claim
that a hosted CI/CD or deployment workflow has been provisioned. Do not execute
untrusted generated pages in privileged CI agents. Record actual environment,
model/server versions, configuration, seed provenance, split metadata, failures,
and latency denominators with experimental results; avoid copyrighted material
and secrets in artifacts/logs.

### Current implementation notes

- Canonical pilot: eight seeds, nine profile/mode tasks per seed, four deterministic
  rollout kinds; external-bank loading is separate.
- Optics includes the additional object-at-infinity control and sixth regime.
- Telemetry spoofing now creates an actual state-versus-visible-output
  contradiction for verifier regression checks.
- Model generation protects the scaffold, withholds evaluation payloads from code
  prompts, and performs no automatic model download.
- Expected reference counts and research aspirations remain explicitly separate
  from observed benchmark results or publication claims.