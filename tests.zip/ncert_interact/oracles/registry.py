"""Eight trusted, deterministic Python reference oracles.

HTML numeric strings are normalized deliberately. Numeric domains are continuous
unless explicitly integer-valued; UI slider steps do not restrict the physics.
Solubility light passage is a simplified transient snapshot, not an equilibrium
claim: stirring changes rate, never whether salt or sugar is soluble.
"""

from __future__ import annotations

import math
import re
from collections.abc import Callable, Mapping
from functools import wraps
from typing import TypeAlias


State: TypeAlias = dict[str, bool | int | float | str]
Oracle: TypeAlias = Callable[[Mapping[str, object]], State]
ORACLE_REGISTRY: dict[str, Oracle] = {}
_ID = re.compile(r"^[a-z][a-z0-9_]{1,95}$")


def register_oracle(oracle_id: str) -> Callable[[Oracle], Oracle]:
    """Register a trusted local function once; invalid IDs and collisions fail."""
    if type(oracle_id) is not str or not _ID.fullmatch(oracle_id):
        raise ValueError("invalid oracle ID")

    def decorate(function: Oracle) -> Oracle:
        if oracle_id in ORACLE_REGISTRY:
            raise ValueError(f"oracle already registered: {oracle_id}")
        if not callable(function):
            raise TypeError("oracle must be callable")

        @wraps(function)
        def guarded(inputs: Mapping[str, object]) -> State:
            if not isinstance(inputs, Mapping):
                raise TypeError("oracle inputs must be a mapping")
            if any(type(key) is not str for key in inputs):
                raise ValueError("input keys must be strings")
            result = function(dict(inputs))
            if type(result) is not dict or not result:
                raise ValueError("oracle output must be a nonempty dict")
            for key, value in result.items():
                if type(key) is not str or not _ID.fullmatch(key):
                    raise ValueError("oracle output keys must be valid identifiers")
                if type(value) not in (str, bool, int, float):
                    raise ValueError("oracle output must contain JSON scalar values")
                if type(value) is float and not math.isfinite(value):
                    raise ValueError("oracle output must be finite JSON")
            return result

        ORACLE_REGISTRY[oracle_id] = guarded
        return guarded

    return decorate


def evaluate_oracle(oracle_id: str, inputs: Mapping[str, object]) -> State:
    """Evaluate a registered local oracle without mutating caller inputs."""
    if type(oracle_id) is not str or oracle_id not in ORACLE_REGISTRY:
        raise ValueError(f"unknown oracle: {oracle_id!r}")
    return ORACLE_REGISTRY[oracle_id](inputs)


def _keys(inputs: Mapping[str, object], required: set[str], optional: set[str] | None = None) -> None:
    missing = required - inputs.keys()
    extra = inputs.keys() - (required | (optional or set()))
    if missing or extra:
        raise ValueError(f"invalid oracle input keys; missing={sorted(missing)}, extra={sorted(extra)}")


def _number(inputs: Mapping[str, object], key: str, lower: float, upper: float, *, integer: bool = False) -> float:
    value = inputs[key]
    if type(value) not in (int, float, str):
        raise ValueError(f"{key} must be a finite number or numeric HTML string")
    try:
        number = float(value)
    except (ValueError, OverflowError) as exc:
        raise ValueError(f"{key} must be numeric") from exc
    if not math.isfinite(number) or not lower <= number <= upper:
        raise ValueError(f"{key} must be finite and in [{lower}, {upper}]")
    if integer and not number.is_integer():
        raise ValueError(f"{key} must be an integer")
    return number


def _select(inputs: Mapping[str, object], key: str, options: tuple[str, ...]) -> str:
    value = inputs[key]
    if type(value) is not str or value not in options:
        raise ValueError(f"{key} must be one of {options}")
    return value


@register_oracle("math_c04_fraction_equivalence_v1")
def fraction_equivalence(inputs: Mapping[str, object]) -> State:
    _keys(inputs, {"ctrl_numerator", "ctrl_denominator", "ctrl_multiplier"})
    n = int(_number(inputs, "ctrl_numerator", 1, 8, integer=True))
    d = int(_number(inputs, "ctrl_denominator", 2, 8, integer=True))
    if d not in (2, 4, 8):
        raise ValueError("ctrl_denominator must be 2, 4, or 8")
    m = int(_number(inputs, "ctrl_multiplier", 1, 3, integer=True))
    comparison = "Greater than 1/2" if 2 * n > d else "Equal to 1/2" if 2 * n == d else "Less than 1/2"
    return {"fraction_decimal": round(n / d, 4), "equivalent_num": n * m,
            "equivalent_den": d * m, "comparison_to_half": comparison}


@register_oracle("evs_c04_solubility_floating_v1")
def solubility_floating(inputs: Mapping[str, object]) -> State:
    """Transient snapshot: unstirred solubles look cloudy but remain soluble.

    Sand/chalk remain cloudy/settled; oil is a transparent floating layer.
    Saturation, particle size, settling time, and emulsification are omitted.
    """
    _keys(inputs, {"ctrl_substance", "ctrl_stir_state"})
    substance = _select(inputs, "ctrl_substance", ("salt", "sugar", "sand", "chalk_powder", "cooking_oil"))
    stir = _select(inputs, "ctrl_stir_state", ("unstirred", "stirred"))
    if substance in {"salt", "sugar"}:
        state = "Soluble (Clear Solution)"
        light = "Transparent" if stir == "stirred" else "Cloudy/Opaque"
    elif substance == "cooking_oil":
        state, light = "Insoluble (Floats on Top)", "Transparent"
    else:
        state, light = "Insoluble (Settles at Bottom)", "Cloudy/Opaque"
    return {"solubility_state": state, "light_passage": light}


@register_oracle("math_c05_angle_classifier_v1")
def angle_classifier(inputs: Mapping[str, object]) -> State:
    _keys(inputs, {"ctrl_angle_deg"})
    angle = _number(inputs, "ctrl_angle_deg", 10, 170)
    category = "Acute (< 90°)" if angle < 90 else "Right (= 90°)" if angle == 90 else "Obtuse (> 90°)"
    return {"angle_deg": angle, "complement_deg": max(0, 90 - angle),
            "supplement_deg": 180 - angle, "angle_category": category}


@register_oracle("evs_c05_buoyancy_salinity_v1")
def buoyancy_salinity(inputs: Mapping[str, object]) -> State:
    _keys(inputs, {"ctrl_salt_spoons", "ctrl_object"})
    spoons = int(_number(inputs, "ctrl_salt_spoons", 0, 10, integer=True))
    obj = _select(inputs, "ctrl_object", ("raw_egg", "iron_nail", "wood_block"))
    rho = 1 + .015 * spoons
    density = {"raw_egg": 1.06, "iron_nail": 7.8, "wood_block": .6}[obj]
    state = "Suspended" if abs(rho - density) <= 1e-9 else "Floats at Surface" if rho > density else "Sinks to Bottom"
    return {"fluid_density": round(rho, 3), "buoyancy_state": state}


@register_oracle("math_c09_circle_subtended_angle_v1")
def circle_subtended_angle(inputs: Mapping[str, object]) -> State:
    _keys(inputs, {"ctrl_arc_span_deg", "ctrl_radius_cm"})
    span = _number(inputs, "ctrl_arc_span_deg", 40, 160)
    radius = _number(inputs, "ctrl_radius_cm", 5, 15)
    return {"central_angle_deg": span, "inscribed_angle_deg": .5 * span,
            "chord_length_cm": round(2 * radius * math.sin(math.radians(span / 2)), 2),
            "theorem_ratio": 2}


@register_oracle("sci_c09_bio_osmosis_v1")
def bio_osmosis(inputs: Mapping[str, object]) -> State:
    _keys(inputs, {"ctrl_solution_type", "ctrl_cell_type"})
    solution = _select(inputs, "ctrl_solution_type", ("hypotonic", "isotonic", "hypertonic"))
    cell = _select(inputs, "ctrl_cell_type", ("plant_onion_cell", "red_blood_cell"))
    flow = {"hypotonic": "Endosmosis (Inward)", "isotonic": "Dynamic Equilibrium (Zero Net)",
            "hypertonic": "Exosmosis (Outward)"}[solution]
    if solution == "hypotonic":
        state = "Turgid (Wall Pressure Balances)" if cell == "plant_onion_cell" else "Burst (Hemolysis)"
    elif solution == "isotonic":
        state = "Normal / Flaccid"
    else:
        state = "Plasmolysed / Shriveled"
    volume = {"hypotonic": 100, "isotonic": 70, "hypertonic": 35}[solution] if cell == "plant_onion_cell" else 0
    return {"net_water_flow": flow, "cell_state": state, "vacuole_volume_pct": volume}


@register_oracle("math_c10_quadratic_discriminant_v1")
def quadratic_discriminant(inputs: Mapping[str, object]) -> State:
    _keys(inputs, {"ctrl_a", "ctrl_b", "ctrl_c"})
    a = _number(inputs, "ctrl_a", -3, 3)
    if a == 0:
        raise ValueError("ctrl_a must be nonzero")
    b = _number(inputs, "ctrl_b", -6, 6)
    c = _number(inputs, "ctrl_c", -6, 6)
    d = b * b - 4 * a * c
    nature = ("Two Distinct Real Roots (D > 0)" if d > 0 else
              "Two Equal Real Roots (D = 0)" if d == 0 else "No Real Roots (D < 0)")
    return {"discriminant": round(d, 2), "vertex_x": round(-b / (2 * a), 2),
            "vertex_y": round(-d / (4 * a), 2), "root_nature": nature}


@register_oracle("sci_c10_optics_thin_lens_v1")
def optics_thin_lens(inputs: Mapping[str, object]) -> State:
    _keys(inputs, {"ctrl_u_dist", "ctrl_f_len"}, {"ctrl_object_at_infinity"})
    u = _number(inputs, "ctrl_u_dist", 5, 60)
    f = _number(inputs, "ctrl_f_len", 10, 25)
    position = _select({"ctrl_object_at_infinity": inputs.get("ctrl_object_at_infinity", "finite")}, "ctrl_object_at_infinity", ("finite", "infinity"))
    if position == "infinity":
        return {"v_dist": f, "magnification": 0, "image_nature": "Real, Inverted, Point-sized (Object at Infinity)"}
    if abs(u - f) < 1e-3:
        return {"v_dist": "Infinity", "magnification": "Infinity", "image_nature": "Parallel Rays / Image at Infinity"}
    if abs(u - 2 * f) < 1e-3:
        nature = "Real, Inverted, Same Size"
    elif u > 2 * f:
        nature = "Real, Inverted, Diminished"
    elif u > f:
        nature = "Real, Inverted, Magnified"
    else:
        nature = "Virtual, Erect, Magnified"
    return {"v_dist": u * f / (u - f), "magnification": f / (f - u), "image_nature": nature}


__all__ = ["ORACLE_REGISTRY", "evaluate_oracle", "register_oracle"]