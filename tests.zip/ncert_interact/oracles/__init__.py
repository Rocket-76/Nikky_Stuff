"""Trusted reference calculations registered under the eight specified IDs."""

from .registry import ORACLE_REGISTRY, evaluate_oracle, register_oracle

__all__ = ["ORACLE_REGISTRY", "evaluate_oracle", "register_oracle"]