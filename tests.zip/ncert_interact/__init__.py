"""Clean-room curriculum tasks and independently verified interactive visualizers."""

__version__ = "0.1.0"