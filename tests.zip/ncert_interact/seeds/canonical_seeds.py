"""Eight original scenarios with explicitly UNVERIFIED local curriculum mappings.

No textbook paragraphs or images are included. Probe records carry only full
control inputs; trusted Python oracles compute reference states at validation.
Scientific simplifications are recorded in each relevant seed's notes.
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from ncert_interact.schemas import (
    ControlContract, DOMReadoutContract, NCERTAlignment, OracleType, Seed,
    TestProbeCase, VerificationOracleSpec,
)


def _range(name: str, label: str, default: float, lower: float, upper: float,
           unit: str | None = None) -> ControlContract:
    return ControlContract(id=f"ctrl_{name}", label=label, tag="input_range",
                           min_val=lower, max_val=upper, step=1, default_val=default, unit=unit)


def _select(name: str, label: str, default: str, options: list[str]) -> ControlContract:
    return ControlContract(id=f"ctrl_{name}", label=label, tag="select", default_val=default, options=options)


def _readout(key: str, values: list[str] | None = None, unit: str | None = None) -> DOMReadoutContract:
    return DOMReadoutContract(testid=f"readout-{key.replace('_', '-')}", state_key=key,
                              dtype="numeric" if values is None else "string_enum",
                              allowed_values=values, unit=unit)


def _seed(*, oracle_id: str, grade: Literal[4, 5, 9, 10],
          subject: Literal["Mathematics", "Science_EVS", "Science"], topic: str,
          outcome: str, misconception: str, description: str,
          controls: list[ControlContract], readouts: list[DOMReadoutContract],
          probes: list[tuple[str, dict[str, float | str]]], discrete: bool = False,
          notes: str = "") -> Seed:
    code = {"Mathematics": "MATH", "Science_EVS": "EVS", "Science": "SCI"}[subject]
    return Seed(
        seed_id=f"seed_{oracle_id}",
        ncert_alignment=NCERTAlignment(
            class_grade=grade, subject=subject, chapter_topic=topic,
            learning_outcome_code=f"LOCAL-C{grade:02d}-{code}-{oracle_id.upper()}",
            learning_outcome_text=f"UNVERIFIED local mapping; original authored outcome: {outcome}",
            target_misconception=misconception,
        ),
        problem_description=description, controls_contract=controls, required_dom_readouts=readouts,
        verification_oracle=VerificationOracleSpec(
            oracle_type=OracleType.Type2_Discrete_State_Table if discrete else OracleType.Type1_Continuous_Algebraic,
            trusted_oracle_id=oracle_id,
            probe_cases=[TestProbeCase(probe_id=f"probe_{index:02d}", regime_name=regime, control_inputs=inputs)
                         for index, (regime, inputs) in enumerate(probes, start=1)],
        ),
        provenance="original", mapping_status="unverified", scientific_notes=notes,
    )


def load_canonical_seeds() -> list[Seed]:
    """Return fresh validated models for the exact eight canonical topics."""
    return [
        _seed(
            oracle_id="math_c04_fraction_equivalence_v1", grade=4, subject="Mathematics",
            topic="Fractions and Equivalent Shares",
            outcome="Scale numerator and denominator together and compare a fraction with one half.",
            misconception="Multiplying only the numerator preserves a fraction's value.",
            description="Build an original equal-share strip. Choose selected shares, the number of shares per whole, and a common multiplier; compare the original strip with its finer partition.",
            controls=[_range("numerator", "Selected shares", 2, 1, 8),
                      _select("denominator", "Shares in one whole", "4", ["2", "4", "8"]),
                      _range("multiplier", "Common scale multiplier", 2, 1, 3)],
            readouts=[_readout("fraction_decimal"), _readout("equivalent_num"), _readout("equivalent_den"),
                      _readout("comparison_to_half", ["Greater than 1/2", "Equal to 1/2", "Less than 1/2"])],
            probes=[
                ("Equal to half", {"ctrl_numerator": 2, "ctrl_denominator": "4", "ctrl_multiplier": 2}),
                ("Less than half", {"ctrl_numerator": 1, "ctrl_denominator": "4", "ctrl_multiplier": 3}),
                ("Greater than half", {"ctrl_numerator": 3, "ctrl_denominator": "4", "ctrl_multiplier": 2}),
            ],
        ),
        _seed(
            oracle_id="evs_c04_solubility_floating_v1", grade=4, subject="Science_EVS",
            topic="Solubility, Settling, and Floating", discrete=True,
            outcome="Distinguish solubility from floating and compare an unstirred snapshot with a stirred one.",
            misconception="A substance becomes soluble only when stirred, and anything that floats has dissolved.",
            description="Add one chosen material to a water jar. Compare its solubility classification with the illustrated position and light passage before or after stirring.",
            controls=[_select("substance", "Material", "salt", ["salt", "sugar", "sand", "chalk_powder", "cooking_oil"]),
                      _select("stir_state", "Stirring state", "stirred", ["unstirred", "stirred"])],
            readouts=[_readout("solubility_state", ["Soluble (Clear Solution)", "Insoluble (Settles at Bottom)", "Insoluble (Floats on Top)"]),
                      _readout("light_passage", ["Transparent", "Cloudy/Opaque"])],
            probes=[
                ("Soluble stirred", {"ctrl_substance": "salt", "ctrl_stir_state": "stirred"}),
                ("Soluble transient unstirred", {"ctrl_substance": "salt", "ctrl_stir_state": "unstirred"}),
                ("Insoluble settling", {"ctrl_substance": "sand", "ctrl_stir_state": "stirred"}),
                ("Insoluble floating", {"ctrl_substance": "cooking_oil", "ctrl_stir_state": "unstirred"}),
            ],
            notes="Simplified snapshot: salt and sugar are soluble even when unstirred; stirring changes dissolution rate, not equilibrium solubility. Cloudy/Opaque unstirred soluble material is a transient teaching simplification. Sand/chalk remain illustrated cloudy and settled in either stirring state; oil is a transparent floating layer. Saturation, settling time, particle size, and emulsification are omitted.",
        ),
        _seed(
            oracle_id="math_c05_angle_classifier_v1", grade=5, subject="Mathematics",
            topic="Angles, Complements, and Supplements",
            outcome="Classify an angle and compute its displayed nonnegative complement and its supplement.",
            misconception="A longer ray makes an angle larger even when its opening is unchanged.",
            description="Rotate a hinged pointer while its base ray stays fixed. Compare the opening with a right angle and inspect the amounts shown toward ninety and one hundred eighty degrees.",
            controls=[_range("angle_deg", "Angle opening", 60, 10, 170, "degrees")],
            readouts=[_readout("angle_deg", unit="degrees"), _readout("complement_deg", unit="degrees"),
                      _readout("supplement_deg", unit="degrees"),
                      _readout("angle_category", ["Acute (< 90°)", "Right (= 90°)", "Obtuse (> 90°)"])],
            probes=[("Acute", {"ctrl_angle_deg": 60}), ("Right", {"ctrl_angle_deg": 90}),
                    ("Obtuse", {"ctrl_angle_deg": 120})],
            notes="For angles above ninety degrees, complement_deg is clamped to 0 as specified; this does not assert that an obtuse angle has a positive complementary angle.",
        ),
        _seed(
            oracle_id="evs_c05_buoyancy_salinity_v1", grade=5, subject="Science_EVS",
            topic="Buoyancy and Salinity",
            outcome="Compare object density with an illustrative salt-water density to predict floating, suspension, or sinking.",
            misconception="Every heavy-looking object sinks regardless of the liquid's density.",
            description="Place an egg, nail, or wooden block in a transparent container. Add a counted number of salt spoons and compare the density display with the object's position.",
            controls=[_range("salt_spoons", "Salt spoons", 0, 0, 10),
                      _select("object", "Object", "raw_egg", ["raw_egg", "iron_nail", "wood_block"])],
            readouts=[_readout("fluid_density", unit="g/cm³"),
                      _readout("buoyancy_state", ["Floats at Surface", "Suspended", "Sinks to Bottom"])],
            probes=[
                ("Egg sinks in fresh water", {"ctrl_salt_spoons": 0, "ctrl_object": "raw_egg"}),
                ("Egg neutral buoyancy", {"ctrl_salt_spoons": 4, "ctrl_object": "raw_egg"}),
                ("Egg floats in denser water", {"ctrl_salt_spoons": 10, "ctrl_object": "raw_egg"}),
                ("Iron sinks", {"ctrl_salt_spoons": 10, "ctrl_object": "iron_nail"}),
                ("Wood floats", {"ctrl_salt_spoons": 0, "ctrl_object": "wood_block"}),
            ],
            notes="Illustrative model rho=1+0.015×spoons g/cm³, with egg 1.06, iron 7.8, and wood 0.6. Spoon mass, water volume, temperature, object variation, dissolution, and motion are not simulated; these are teaching constants, not measured experimental predictions.",
        ),
        _seed(
            oracle_id="math_c09_circle_subtended_angle_v1", grade=9, subject="Mathematics",
            topic="Central and Inscribed Angles on the Same Arc",
            outcome="Relate a central angle to an inscribed angle on the same arc and compute its chord length.",
            misconception="Changing a circle's radius changes the two-to-one angle theorem ratio.",
            description="Select the span of a minor arc and the radius of a circle. Draw its chord and a corresponding inscribed angle whose vertex lies on the opposite arc; compare angles as the circle grows.",
            controls=[_range("arc_span_deg", "Central arc span", 80, 40, 160, "degrees"),
                      _range("radius_cm", "Circle radius", 10, 5, 15, "cm")],
            readouts=[_readout("central_angle_deg", unit="degrees"), _readout("inscribed_angle_deg", unit="degrees"),
                      _readout("chord_length_cm", unit="cm"), _readout("theorem_ratio")],
            probes=[
                ("Default arc", {"ctrl_arc_span_deg": 80, "ctrl_radius_cm": 10}),
                ("Wider arc", {"ctrl_arc_span_deg": 120, "ctrl_radius_cm": 10}),
                ("Larger radius", {"ctrl_arc_span_deg": 80, "ctrl_radius_cm": 15}),
            ],
            notes="The inscribed vertex is on the opposite arc, so both angles subtend the same selected minor arc; chord length uses degrees converted to radians.",
        ),
        _seed(
            oracle_id="sci_c09_bio_osmosis_v1", grade=9, subject="Science",
            topic="Osmosis in Plant and Red Blood Cells", discrete=True,
            outcome="Compare net water flow and idealized plant/RBC responses in hypo-, iso-, and hypertonic solutions.",
            misconception="Plant cells and red blood cells have the same wall and vacuole structures.",
            description="Compare an onion cell and a red blood cell in three external solutions. Show net water movement, an idealized final cell state, and a plant-only vacuole percentage with an explicit absent-vacuole value for the red blood cell.",
            controls=[_select("solution_type", "External solution", "isotonic", ["hypotonic", "isotonic", "hypertonic"]),
                      _select("cell_type", "Cell type", "plant_onion_cell", ["plant_onion_cell", "red_blood_cell"])],
            readouts=[_readout("net_water_flow", ["Endosmosis (Inward)", "Dynamic Equilibrium (Zero Net)", "Exosmosis (Outward)"]),
                      _readout("cell_state", ["Turgid (Wall Pressure Balances)", "Burst (Hemolysis)", "Normal / Flaccid", "Plasmolysed / Shriveled"]),
                      _readout("vacuole_volume_pct", unit="% (plant only; RBC absent=0)")],
            probes=[
                ("Plant isotonic", {"ctrl_solution_type": "isotonic", "ctrl_cell_type": "plant_onion_cell"}),
                ("Plant hypotonic", {"ctrl_solution_type": "hypotonic", "ctrl_cell_type": "plant_onion_cell"}),
                ("Plant hypertonic", {"ctrl_solution_type": "hypertonic", "ctrl_cell_type": "plant_onion_cell"}),
                ("RBC hypotonic", {"ctrl_solution_type": "hypotonic", "ctrl_cell_type": "red_blood_cell"}),
                ("RBC isotonic", {"ctrl_solution_type": "isotonic", "ctrl_cell_type": "red_blood_cell"}),
                ("RBC hypertonic", {"ctrl_solution_type": "hypertonic", "ctrl_cell_type": "red_blood_cell"}),
            ],
            notes="A mature red blood cell has NO vacuole: vacuole_volume_pct=0 denotes absence in all solutions, never a collapsed organelle. Plant 100/70/35 percentages are illustrative proxies. Burst (Hemolysis) is an idealized hypotonic endpoint, not an instantaneous universal response. Plasmolysed refers to plant cells; Shriveled refers to RBCs in the shared label. Isotonic plant cells are flaccid while RBCs are normal.",
        ),
        _seed(
            oracle_id="math_c10_quadratic_discriminant_v1", grade=10, subject="Mathematics",
            topic="Quadratic Discriminant and Vertex",
            outcome="Compute a quadratic's discriminant and vertex and distinguish its three real-root regimes.",
            misconception="Every parabola must cross the horizontal axis twice.",
            description="Choose a nonzero leading coefficient and adjust the other two coefficients. Compare the parabola's vertex with its intersections and the sign of its discriminant.",
            controls=[_select("a", "Leading coefficient a (nonzero)", "1", ["-3", "-2", "-1", "1", "2", "3"]),
                      _range("b", "Coefficient b", 0, -6, 6), _range("c", "Constant c", -4, -6, 6)],
            readouts=[_readout("discriminant"), _readout("vertex_x"), _readout("vertex_y"),
                      _readout("root_nature", ["Two Distinct Real Roots (D > 0)", "Two Equal Real Roots (D = 0)", "No Real Roots (D < 0)"])],
            probes=[
                ("Two distinct real roots", {"ctrl_a": "1", "ctrl_b": 0, "ctrl_c": -4}),
                ("Repeated real root", {"ctrl_a": "1", "ctrl_b": 2, "ctrl_c": 1}),
                ("No real roots", {"ctrl_a": "1", "ctrl_b": 0, "ctrl_c": 1}),
            ],
            notes="UI b/c controls have integer step 1 and a is a nonzero SELECT. The mathematical oracle independently accepts finite real coefficients in its stated bounds; root classification uses the unrounded discriminant.",
        ),
        _seed(
            oracle_id="sci_c10_optics_thin_lens_v1", grade=10, subject="Science",
            topic="Convex Thin Lens: Six Image Regimes",
            outcome="Compare six convex-lens regimes, including an object at the focus and an object at infinity.",
            misconception="Every convex-lens image is real, and an object at the focus is equivalent to one at infinity.",
            description="Move an object before a convex lens and vary the focal length. Switch between a finite object and one at infinity, showing signed image distance, signed magnification, and the corresponding ray diagram.",
            controls=[_range("u_dist", "Object distance magnitude u", 50, 5, 60, "cm"),
                      _range("f_len", "Focal length f", 15, 10, 25, "cm"),
                      _select("object_at_infinity", "Object position", "finite", ["finite", "infinity"])],
            readouts=[_readout("v_dist", unit="cm"), _readout("magnification"),
                      _readout("image_nature", ["Real, Inverted, Diminished", "Real, Inverted, Same Size", "Real, Inverted, Magnified", "Parallel Rays / Image at Infinity", "Virtual, Erect, Magnified", "Real, Inverted, Point-sized (Object at Infinity)"])],
            probes=[
                ("Beyond twice focal length", {"ctrl_u_dist": 50, "ctrl_f_len": 15, "ctrl_object_at_infinity": "finite"}),
                ("At twice focal length", {"ctrl_u_dist": 30, "ctrl_f_len": 15, "ctrl_object_at_infinity": "finite"}),
                ("Between focus and twice focus", {"ctrl_u_dist": 22, "ctrl_f_len": 15, "ctrl_object_at_infinity": "finite"}),
                ("At focus", {"ctrl_u_dist": 15, "ctrl_f_len": 15, "ctrl_object_at_infinity": "finite"}),
                ("Inside focus", {"ctrl_u_dist": 10, "ctrl_f_len": 15, "ctrl_object_at_infinity": "finite"}),
                ("Object at infinity", {"ctrl_u_dist": 50, "ctrl_f_len": 15, "ctrl_object_at_infinity": "infinity"}),
            ],
            notes="Ideal paraxial thin convex lens; u is positive object-distance magnitude. v=uf/(u-f), m=f/(f-u). Within 0.001 cm of u=f the DOM uses literal Infinity for both numeric readouts; within 0.001 cm of u=2f it uses Same Size. Object at infinity is a separate limiting regime with v=f and m=0. No non-finite JSON numbers are stored.",
        ),
    ]


def load_seeds_jsonl(path: str | Path, expected_count: int | None = 240) -> list[Seed]:
    """Validate a nonempty bank, every JSONL record, duplicates, and bank size.

    Blank lines are errors, never silently skipped. Parsing failures include the
    one-based physical line number. Pass ``None`` for intentionally smaller banks.
    """
    if expected_count is not None and (type(expected_count) is not int or expected_count <= 0):
        raise ValueError("expected_count must be a positive integer or None")
    seeds: list[Seed] = []
    seen: set[str] = set()
    with Path(path).open("r", encoding="utf-8") as source:
        for line_number, line in enumerate(source, start=1):
            try:
                seed = Seed.model_validate_json(line)
            except ValueError as exc:
                raise ValueError(f"invalid seed at line {line_number}: {exc}") from exc
            if seed.seed_id in seen:
                raise ValueError(f"duplicate seed_id at line {line_number}: {seed.seed_id}")
            seeds.append(seed)
            seen.add(seed.seed_id)
    if not seeds:
        raise ValueError("seed bank must not be empty")
    if expected_count is not None and len(seeds) != expected_count:
        raise ValueError(f"expected {expected_count} seeds, found {len(seeds)}")
    return seeds


__all__ = ["load_canonical_seeds", "load_seeds_jsonl"]