"""Strict PIS contracts: probes store inputs, never expected oracle states.

Numeric DOM outputs may use literal ``Infinity`` for a focal-plane lens image;
non-finite floating-point numbers are forbidden. LOCAL mappings are unverified.
"""

from __future__ import annotations

import math
from enum import Enum
from typing import Annotated, ClassVar, Literal

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr, field_validator, model_validator


Identifier = Annotated[StrictStr, Field(pattern=r"^[a-z][a-z0-9_]*$")]
Text = Annotated[StrictStr, Field(min_length=1, pattern=r"\S")]
Ratio = Annotated[float, Field(ge=0, le=1)]


class DevelopmentalBand(str, Enum):
    Foundational_4_5 = "Foundational_4_5"
    Secondary_9_10 = "Secondary_9_10"


class LearnerProfile(str, Enum):
    Remedial_Concrete = "Remedial_Concrete"
    Standard_GradeLevel = "Standard_GradeLevel"
    Counterfactual_Challenge = "Counterfactual_Challenge"


class PedagogicalMode(str, Enum):
    Predict_Observe_Explain = "Predict_Observe_Explain"
    Exploratory_Sandbox = "Exploratory_Sandbox"
    Misconception_Debug = "Misconception_Debug"


class OracleType(str, Enum):
    Type1_Continuous_Algebraic = "Type1_Continuous_Algebraic"
    Type2_Discrete_State_Table = "Type2_Discrete_State_Table"


class ContractModel(BaseModel):
    """Forbid coercion, undeclared properties, and non-finite numbers."""

    model_config = ConfigDict(extra="forbid", strict=True, allow_inf_nan=False, validate_default=True)


class NCERTAlignment(ContractModel):
    class_grade: Literal[4, 5, 9, 10]
    subject: Literal["Mathematics", "Science_EVS", "Science"]
    chapter_topic: Text
    learning_outcome_code: Text
    learning_outcome_text: Text
    target_misconception: Text

    @model_validator(mode="after")
    def consistent_alignment(self):
        foundational = self.class_grade in {4, 5}
        if self.subject not in ({"Mathematics", "Science_EVS"} if foundational else {"Mathematics", "Science"}):
            raise ValueError("subject does not match grade")
        return self


def _enum_value(enum_type, value):
    """Accept only actual members or their exact JSON strings, never coercion."""
    if isinstance(value, enum_type):
        return value
    if type(value) is str:
        return enum_type(value)
    raise ValueError(f"expected {enum_type.__name__} member or exact value")


class UIComplexityBudget(ContractModel):
    developmental_band: DevelopmentalBand
    max_controls: Annotated[int, Field(ge=1)]
    min_touch_target_px: Annotated[int, Field(ge=1)]
    required_views: list[Text] = Field(min_length=1)

    @field_validator("developmental_band", mode="before")
    @classmethod
    def parse_band(cls, value):
        return _enum_value(DevelopmentalBand, value)

    @model_validator(mode="after")
    def band_limits(self):
        foundational = self.developmental_band == DevelopmentalBand.Foundational_4_5
        if self.max_controls > (3 if foundational else 5):
            raise ValueError("max_controls exceeds developmental-band budget")
        if self.min_touch_target_px < (48 if foundational else 36):
            raise ValueError("touch targets below developmental-band minimum")
        _unique(self.required_views, "required views")
        return self


def _finite_number(value: object) -> float | None:
    if type(value) not in (int, float, str):
        return None
    try:
        number = float(value)
    except (ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


def _equivalent(left: object, right: object) -> bool:
    if type(left) is type(right) and left == right:
        return True
    a, b = _finite_number(left), _finite_number(right)
    return a is not None and b is not None and a == b


class ControlContract(ContractModel):
    id: Annotated[StrictStr, Field(pattern=r"^ctrl_[a-z][a-z0-9_]*$")]
    label: Text
    tag: Literal["input_range", "select", "button"]
    min_val: float | None = None
    max_val: float | None = None
    step: float | None = None
    options: list[Text] | None = None
    default_val: float | str
    unit: str | None = None

    def accepts(self, value: object) -> bool:
        """Accept exact choices or equivalent finite HTML numeric values."""
        if self.tag in {"select", "button"}:
            if self.options:
                return any(_equivalent(value, option) for option in self.options)
            return _equivalent(value, self.default_val)
        number = _finite_number(value)
        if number is None or self.min_val is None or self.max_val is None or self.step is None:
            return False
        if not self.min_val <= number <= self.max_val:
            return False
        quotient = (number - self.min_val) / self.step
        return math.isfinite(quotient) and math.isclose(quotient, round(quotient), rel_tol=0, abs_tol=1e-8)

    @model_validator(mode="after")
    def valid_domain(self):
        if isinstance(self.default_val, str) and not self.default_val.strip():
            raise ValueError("default_val must not be blank")
        if self.tag == "input_range":
            if self.min_val is None or self.max_val is None or self.step is None:
                raise ValueError("input_range requires min_val, max_val, and step")
            if self.min_val >= self.max_val or not 0 < self.step <= self.max_val - self.min_val:
                raise ValueError("invalid input_range interval or step")
            if self.options is not None:
                raise ValueError("input_range cannot declare options")
        else:
            if any(value is not None for value in (self.min_val, self.max_val, self.step)):
                raise ValueError("only input_range declares bounds and step")
            if self.tag == "select" and not self.options:
                raise ValueError("select requires options")
            if self.options is not None:
                if not self.options:
                    raise ValueError("declared options cannot be empty")
                for index, option in enumerate(self.options):
                    if any(_equivalent(option, other) for other in self.options[:index]):
                        raise ValueError("duplicate or numerically equivalent options")
        if not self.accepts(self.default_val):
            raise ValueError("default_val is outside the control domain")
        return self


class DOMReadoutContract(ContractModel):
    testid: Annotated[StrictStr, Field(pattern=r"^readout-[a-z][a-z0-9_-]*$")]
    state_key: Identifier
    dtype: Literal["numeric", "string_enum"]
    tolerance: Annotated[float, Field(ge=0)] | None = .01
    allowed_values: list[Text] | None = None
    unit: str | None = None

    @model_validator(mode="after")
    def valid_readout(self):
        if self.allowed_values is not None:
            if not self.allowed_values:
                raise ValueError("declared allowed_values cannot be empty")
            _unique(self.allowed_values, "readout allowed_values")
        return self

    def accepts(self, value: object) -> bool:
        if self.dtype == "string_enum":
            return (type(value) is str and bool(value.strip())
                    and (self.allowed_values is None or value in self.allowed_values))
        return (type(value) in (int, float) and _finite_number(value) is not None) or value == "Infinity"


class TestProbeCase(ContractModel):
    __test__: ClassVar[bool] = False
    probe_id: Text
    regime_name: Text
    control_inputs: dict[str, float | str] = Field(min_length=1)


class VerificationOracleSpec(ContractModel):
    oracle_type: OracleType
    trusted_oracle_id: Identifier
    probe_cases: list[TestProbeCase] = Field(min_length=3)

    @field_validator("oracle_type", mode="before")
    @classmethod
    def parse_oracle_type(cls, value):
        return _enum_value(OracleType, value)

    @model_validator(mode="after")
    def unique_probes_and_registered_oracle(self):
        _unique([probe.probe_id for probe in self.probe_cases], "probe IDs")
        signatures = [tuple(sorted(probe.control_inputs.items())) for probe in self.probe_cases]
        _unique(signatures, "probe inputs")
        # Lazy import keeps the registry usable without a schema import cycle.
        from ncert_interact.oracles.registry import ORACLE_REGISTRY

        if self.trusted_oracle_id not in ORACLE_REGISTRY:
            raise ValueError(f"unknown oracle: {self.trusted_oracle_id}")
        return self


def _unique(values: list, description: str) -> None:
    if len(set(values)) != len(values):
        raise ValueError(f"duplicate {description}")


def _validate_contract(model) -> None:
    from ncert_interact.oracles.registry import evaluate_oracle

    _unique([control.id for control in model.controls_contract], "control IDs")
    _unique([readout.testid for readout in model.required_dom_readouts], "readout testids")
    _unique([readout.state_key for readout in model.required_dom_readouts], "readout state keys")
    controls = {control.id: control for control in model.controls_contract}
    if len(controls) > (3 if model.ncert_alignment.class_grade in (4, 5) else 5):
        raise ValueError("controls exceed grade-band budget")
    probes = model.verification_oracle.probe_cases
    first = probes[0].control_inputs
    if set(first) != set(controls) or any(not _equivalent(first[key], control.default_val) for key, control in controls.items()):
        raise ValueError("first probe must supply the complete default input state")
    states = []
    for probe in probes:
        if set(probe.control_inputs) != set(controls):
            raise ValueError("every probe must supply all controls")
        if any(not controls[key].accepts(value) for key, value in probe.control_inputs.items()):
            raise ValueError("probe input outside control domain")
        state = evaluate_oracle(model.verification_oracle.trusted_oracle_id, probe.control_inputs)
        visible = []
        for readout in model.required_dom_readouts:
            if readout.state_key not in state or not readout.accepts(state[readout.state_key]):
                raise ValueError("readout missing or incompatible with dtype/domain")
            visible.append(state[readout.state_key])
        signature = tuple(visible)
        if states and signature == states[-1]:
            raise ValueError("consecutive probes must change a visible state")
        states.append(signature)
    if len(set(states)) < 3:
        raise ValueError("probes must expose at least three distinct states")


class Seed(ContractModel):
    seed_id: Identifier
    ncert_alignment: NCERTAlignment
    problem_description: Text
    controls_contract: list[ControlContract] = Field(min_length=1, max_length=5)
    required_dom_readouts: list[DOMReadoutContract] = Field(min_length=1)
    verification_oracle: VerificationOracleSpec
    provenance: Literal["original"] = "original"
    mapping_status: Literal["unverified"] = "unverified"
    scientific_notes: str = ""

    @model_validator(mode="after")
    def cross_check(self):
        _validate_contract(self)
        return self


class PISSchema(ContractModel):
    task_id: Identifier
    seed_id: Identifier
    split: Literal["train", "dev", "test"]
    learner_profile: LearnerProfile
    pedagogical_mode: PedagogicalMode
    ncert_alignment: NCERTAlignment
    ui_complexity_budget: UIComplexityBudget
    guided_prompts: list[Text] = Field(min_length=1)
    controls_contract: list[ControlContract] = Field(min_length=1, max_length=5)
    required_dom_readouts: list[DOMReadoutContract] = Field(min_length=1)
    verification_oracle: VerificationOracleSpec
    problem_description: str | None = None
    scientific_notes: str = ""

    @field_validator("learner_profile", mode="before")
    @classmethod
    def parse_profile(cls, value):
        return _enum_value(LearnerProfile, value)

    @field_validator("pedagogical_mode", mode="before")
    @classmethod
    def parse_mode(cls, value):
        return _enum_value(PedagogicalMode, value)

    @model_validator(mode="after")
    def cross_check(self):
        _validate_contract(self)
        expected = DevelopmentalBand.Foundational_4_5 if self.ncert_alignment.class_grade in (4, 5) else DevelopmentalBand.Secondary_9_10
        if self.ui_complexity_budget.developmental_band != expected:
            raise ValueError("grade and UI developmental_band disagree")
        if len(self.controls_contract) > self.ui_complexity_budget.max_controls:
            raise ValueError("control count exceeds declared UI budget")
        return self


class VerificationReport(ContractModel):
    """Conservative defaults mean an unevaluated task cannot accidentally pass."""

    task_id: Text
    rollout_id: Text
    exec_valid: StrictBool = False
    console_errors: list[str] = Field(default_factory=list)
    controls_found_ratio: Ratio = 0.0
    interaction_coverage: Ratio = 0.0
    scientific_oracle_acc: Ratio = 0.0
    spoofing_detected: StrictBool = False
    ui_budget_compliance: StrictBool = False
    probe_details: list[dict] = Field(default_factory=list)
    generation_latency_sec: Annotated[float, Field(ge=0)] = 0.0
    verification_latency_sec: Annotated[float, Field(ge=0)] = 0.0
    passed_all: StrictBool = False


__all__ = [
    "ControlContract", "DOMReadoutContract", "DevelopmentalBand", "LearnerProfile",
    "NCERTAlignment", "OracleType", "PISSchema", "PedagogicalMode", "Seed",
    "TestProbeCase", "UIComplexityBudget", "VerificationOracleSpec", "VerificationReport",
]