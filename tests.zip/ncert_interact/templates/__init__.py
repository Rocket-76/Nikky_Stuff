"""Local, self-contained assets for the clean-room SVG simulations."""

from pathlib import Path


def load_asset(name: str) -> str:
    """Read an explicitly supported asset without permitting path traversal."""
    if name not in {"base_harness.html", "svg_primitives.js"}:
        raise ValueError(f"Unsupported template asset: {name}")
    return Path(__file__).with_name(name).read_text(encoding="utf-8")


__all__ = ["load_asset"]