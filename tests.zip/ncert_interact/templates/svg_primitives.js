/* Original SVG teaching models. No oracle results, probe tables, or remote assets. */
(function (global) {
  "use strict";
  const NS = "http://www.w3.org/2000/svg";
  const C = {ink:"#172b44", muted:"#526a80", teal:"#087f88", blue:"#2764b0", red:"#bd4055", gold:"#e1a332", pale:"#dceff5", purple:"#7751ae"};
  function node(tag, attrs, parent, content) {
    const element = document.createElementNS(NS, tag);
    Object.entries(attrs || {}).forEach(([key, value]) => {
      if (value !== undefined && value !== null) element.setAttribute(key, String(value));
    });
    if (content !== undefined) element.textContent = String(content);
    if (parent) parent.appendChild(element);
    return element;
  }
  const group = (p, attrs) => node("g", attrs, p);
  const line = (p,x1,y1,x2,y2,attrs) => node("line",Object.assign({x1,y1,x2,y2,stroke:C.ink,"stroke-width":1.8},attrs),p);
  const rect = (p,x,y,width,height,attrs) => node("rect",Object.assign({x,y,width,height,rx:4,fill:"none",stroke:C.ink},attrs),p);
  const circle = (p,cx,cy,r,attrs) => node("circle",Object.assign({cx,cy,r,fill:"none",stroke:C.ink},attrs),p);
  const text = (p,x,y,value,attrs) => node("text",Object.assign({x,y,"font-size":12},attrs),p,value);
  const path = (p,d,attrs) => node("path",Object.assign({d,fill:"none",stroke:C.ink,"stroke-width":2},attrs),p);
  const round = (n, digits) => {
    if(!Number.isFinite(n)||!Number.isInteger(digits)) throw new RangeError("Expected a finite value and integer decimal precision");
    if(n===0||digits < -324) return 0;
    if(digits > 323) return n;
    // Round the exact IEEE-754 value, not n*10**digits: multiplication can
    // manufacture false decimal ties (for example 2.675 at two places).
    const bits=new DataView(new ArrayBuffer(8));
    bits.setFloat64(0,Math.abs(n),false);
    const high=bits.getUint32(0,false),low=bits.getUint32(4,false),exponent=(high>>>20)&2047;
    const one=BigInt(1),two=BigInt(2);
    let numerator=(BigInt(high&1048575)<<BigInt(32))+BigInt(low),denominator=one;
    if(exponent!==0) numerator+=one<<BigInt(52);
    const binaryExponent=exponent===0?-1074:exponent-1075;
    if(binaryExponent>=0) numerator<<=BigInt(binaryExponent);
    else denominator<<=BigInt(-binaryExponent);
    const scale=BigInt(10)**BigInt(Math.abs(digits));
    if(digits>=0) numerator*=scale;
    else denominator*=scale;
    const quotient=numerator/denominator,remainder=numerator%denominator;
    const increment=remainder*two>denominator||(remainder*two===denominator&&quotient%two!==BigInt(0));
    const integer=quotient+(increment?one:BigInt(0));
    // Decimal parsing avoids a second rounding from Number(integer)/10**digits.
    const result=Number(integer.toString()+"e"+String(-digits))*(n<0?-1:1);
    if(!Number.isFinite(result)) throw new RangeError("Rounded value is not finite");
    return Object.is(result, -0) ? 0 : result;
  };
  function arrow(p,x1,y1,x2,y2,attrs) {
    const g=group(p,{"data-primitive":"arrow"});
    line(g,x1,y1,x2,y2,attrs);
    const a=Math.atan2(y2-y1,x2-x1), s=7;
    const color=(attrs && attrs.stroke)||C.teal;
    node("polygon",{points:`${x2},${y2} ${x2-s*Math.cos(a-.45)},${y2-s*Math.sin(a-.45)} ${x2-s*Math.cos(a+.45)},${y2-s*Math.sin(a+.45)}`,fill:color},g);
    return g;
  }
  function fractionGrid(p, numerator, denominator, multiplier, x, y, width, height) {
    const g=group(p,{"data-primitive":"fraction-grid","data-numerator":numerator,"data-denominator":denominator,"data-subdivisions":multiplier});
    const wholes=Math.max(1,Math.ceil(numerator/denominator));
    const gap=8, w=(width-gap*(wholes-1))/wholes;
    for(let whole=0;whole<wholes;whole++) {
      const start=x+whole*(w+gap), selected=Math.min(denominator,Math.max(0,numerator-whole*denominator));
      rect(g,start,y,w,height,{fill:"#fff",stroke:C.blue,rx:0});
      for(let piece=0;piece<denominator*multiplier;piece++) {
        const pw=w/(denominator*multiplier);
        rect(g,start+piece*pw,y,pw,height,{fill:piece<selected*multiplier?C.teal:"#fff",stroke:"#bed5df","stroke-width":.7,rx:0});
      }
      for(let major=1;major<denominator;major++) line(g,start+major*w/denominator,y,start+major*w/denominator,y+height,{stroke:C.blue,"stroke-width":1.3});
    }
    return g;
  }
  function protractor(p,cx,cy,r,angle) {
    const g=group(p,{"data-primitive":"protractor"});
    path(g,`M ${cx-r} ${cy} A ${r} ${r} 0 0 1 ${cx+r} ${cy} Z`,{fill:"#e8f4f7",stroke:"#80b3c5"});
    for(let a=0;a<=180;a+=10) {
      const t=a*Math.PI/180, inner=r-(a%30===0?13:7);
      line(g,cx+inner*Math.cos(t),cy-inner*Math.sin(t),cx+r*Math.cos(t),cy-r*Math.sin(t),{stroke:C.muted,"stroke-width":1});
      if(a%30===0) text(g,cx+(r-27)*Math.cos(t),cy-(r-27)*Math.sin(t)+4,a,{"text-anchor":"middle","font-size":10});
    }
    const a=angle*Math.PI/180;
    path(g,`M ${cx+43} ${cy} A 43 43 0 ${angle>180?1:0} 0 ${cx+43*Math.cos(a)} ${cy-43*Math.sin(a)}`,{stroke:C.gold,"stroke-width":4});
    arrow(g,cx,cy,cx+r+15,cy,{stroke:C.blue,"stroke-width":3});
    arrow(g,cx,cy,cx+(r+15)*Math.cos(a),cy-(r+15)*Math.sin(a),{stroke:C.teal,"stroke-width":3});
    circle(g,cx,cy,4,{fill:C.ink});
    return g;
  }
  function circuitNodes(p, positions, connections) {
    const g=group(p,{"data-primitive":"circuit-nodes"});
    connections.forEach(([a,b]) => line(g,positions[a][0],positions[a][1],positions[b][0],positions[b][1],{stroke:C.teal}));
    positions.forEach(([x,y])=>circle(g,x,y,4,{fill:C.gold}));
    return g;
  }
  function cell(p, kind, solution, volume) {
    const g=group(p,{"data-primitive":"cell","data-cell-type":kind});
    if(kind==="plant_onion_cell") {
      rect(g,185,80,230,220,{fill:"#eff5df",stroke:"#658339","stroke-width":7,rx:22});
      const factor=solution==="hypertonic"?.68:solution==="isotonic"?.89:.97;
      const w=218*factor,h=208*factor;
      rect(g,300-w/2,190-h/2,w,h,{fill:"#e0eabe",stroke:C.teal,"stroke-width":3,rx:17,"data-part":"membrane"});
      const v=Math.sqrt(Math.max(0,volume)/100);
      rect(g,300-78*v,190-78*v,156*v,156*v,{fill:"#b7dbea",stroke:C.blue,rx:22,"data-part":"vacuole"});
      circle(g,300-w/2+19,190+h/2-22,9,{fill:C.purple,stroke:"none"});
      text(g,300,194,`Vacuole ${volume}%`,{"text-anchor":"middle","font-size":11});
      text(g,300,323,"Rigid cell wall · inner membrane",{"text-anchor":"middle"});
    } else {
      if(solution==="hypotonic") {
        const points=[];
        for(let i=0;i<24;i++) {const t=i*Math.PI/12,r=i%2?70:108;points.push(`${300+r*Math.cos(t)},${185+r*Math.sin(t)}`);}
        node("polygon",{points:points.join(" "),fill:"#f9dbe0",stroke:C.red,"stroke-width":3,"data-part":"ruptured-membrane"},g);
        for(let i=0;i<6;i++) {const a=i*Math.PI/3;circle(g,300+123*Math.cos(a),185+111*Math.sin(a),5,{fill:C.red,stroke:"none"});}
      } else if(solution==="hypertonic") {
        const points=[];
        for(let i=0;i<32;i++) {const a=i*Math.PI/16,r=i%2?57:75;points.push(`${300+r*Math.cos(a)},${185+r*Math.sin(a)}`);}
        node("polygon",{points:points.join(" "),fill:"#eeb4c2",stroke:C.red,"stroke-width":3,"data-part":"shriveled-membrane"},g);
      } else {
        node("ellipse",{cx:300,cy:185,rx:93,ry:68,fill:"#f0bbc7",stroke:C.red,"stroke-width":3,"data-part":"membrane"},g);
        node("ellipse",{cx:300,cy:185,rx:48,ry:32,fill:"#f9dde4",stroke:"#dc879d"},g);
      }
      text(g,300,323,"Red blood cell · no cell wall or vacuole",{"text-anchor":"middle"});
    }
    return g;
  }
  function rayOpticsBench(p, u, f, atInfinity, v, magnification) {
    const g=group(p,{"data-primitive":"ray-optics-bench"});
    const cy=184, margin=45,finite=v!=="Infinity";
    // One isotropic scale preserves ray slopes and inversion even near the focus.
    const left=Math.max(2.4*f,atInfinity?2.4*f:u,finite&&v<0?-v:0);
    const right=Math.max(2.4*f,finite&&v>0?v:0);
    const objectHeight=8, imageHeight=finite?Math.abs(Number(magnification))*objectHeight:objectHeight;
    const scale=Math.min(510/(left+right),108/Math.max(objectHeight,imageHeight));
    const lensX=margin+left*scale, X=x=>lensX+x*scale,Y=y=>cy-y*scale;
    line(g,25,cy,575,cy,{stroke:"#829aab","stroke-dasharray":"5 4"});
    path(g,`M ${lensX} 65 Q ${lensX-17} ${cy} ${lensX} 303 Q ${lensX+17} ${cy} ${lensX} 65`,{fill:"#d2edf2",stroke:C.teal});
    [-2,-1,1,2].forEach(k=>{line(g,X(k*f),cy-5,X(k*f),cy+5,{stroke:C.ink});text(g,X(k*f),cy+21,`${k<0?"−":""}${Math.abs(k)===2?"2F":"F"}`,{"text-anchor":"middle","font-size":10});});
    text(g,lensX,55,"Convex lens",{"text-anchor":"middle"});
    function ray(x1,y1,x2,y2,color,dashed) {line(g,X(x1),Y(y1),X(x2),Y(y2),{stroke:color,"stroke-width":2,"stroke-dasharray":dashed?"5 4":null});}
    if(atInfinity) {
      [objectHeight,-objectHeight].forEach(h=>{ray(-left,h,0,h,C.gold,false);ray(0,h,right,h*(1-right/f),C.gold,false);arrow(g,X(-left*.7),Y(h),X(-left*.5),Y(h),{stroke:C.gold});});
      circle(g,X(f),cy,4,{fill:C.red,stroke:"none"});
      text(g,35,90,"Object at infinity: parallel incident rays",{"font-size":11});
      text(g,X(f),cy-12,"Point image",{"text-anchor":"middle","font-size":10});
    } else {
      const h=objectHeight;
      arrow(g,X(-u),cy,X(-u),Y(h),{stroke:C.blue,"stroke-width":3});
      text(g,X(-u),cy+40,"Object",{"text-anchor":"middle","font-size":11});
      ray(-u,h,0,h,C.gold,false);
      ray(0,h,right,h*(1-right/f),C.gold,false);
      ray(-u,h,0,0,C.purple,false);
      ray(0,0,right,-h*right/u,C.purple,false);
      if(finite) {
        const ih=Number(magnification)*h;
        arrow(g,X(v),cy,X(v),Y(ih),{stroke:C.red,"stroke-width":3,"stroke-dasharray":v<0?"5 3":null});
        text(g,X(v),Math.min(323,Math.max(76,Y(ih)+(ih<0?17:-12))),v<0?"Virtual image":"Real image",{"text-anchor":"middle","font-size":11});
        if(v<0) {ray(0,h,v,ih,C.gold,true);ray(0,0,v,ih,C.purple,true);}
      } else text(g,415,95,"Parallel emergent rays",{"font-size":11});
    }
    text(g,30,343,`Distance scale: ${round(1/scale,2)} cm per SVG unit · ray heights use the same scale`,{"font-size":10});
    return g;
  }
  const models = {
    math_c04_fraction_equivalence_v1: {
      compute(c) {
        const n=+c.ctrl_numerator,d=+c.ctrl_denominator,m=+c.ctrl_multiplier;
        return {fraction_decimal:round(n/d,4),equivalent_num:n*m,equivalent_den:d*m,comparison_to_half:n/d>.5?"Greater than 1/2":n/d===.5?"Equal to 1/2":"Less than 1/2"};
      },
      draw(p,c,s) {
        const n=+c.ctrl_numerator,d=+c.ctrl_denominator,m=+c.ctrl_multiplier;
        text(p,32,79,`Original: ${n}/${d}`,{"font-weight":650});
        fractionGrid(p,n,d,1,32,92,536,58);
        text(p,32,184,`Equivalent: ${s.equivalent_num}/${s.equivalent_den}`,{"font-weight":650});
        fractionGrid(p,s.equivalent_num,s.equivalent_den,1,32,197,536,58);
        const barWidth=125, value=s.fraction_decimal;
        line(p,32,295,32+barWidth*4,295,{stroke:"#b6cbd6","stroke-width":6});
        for(let whole=0;whole<=4;whole++) {line(p,32+whole*barWidth,289,32+whole*barWidth,301,{stroke:C.muted});text(p,32+whole*barWidth,314,whole,{"text-anchor":"middle","font-size":10});}
        line(p,32+barWidth*.5,283,32+barWidth*.5,307,{stroke:C.gold,"stroke-width":3});
        circle(p,32+value*barWidth,295,6,{fill:C.teal});
        text(p,32,340,`${n} selected parts, each split into ${m}; whole boundaries remain visible.`,{"font-size":11});
        text(p,32+barWidth*.5,278,"½",{"text-anchor":"middle"});
      }
    },
    evs_c04_solubility_floating_v1: {
      compute(c) {
        const a=c.ctrl_substance, soluble=a==="salt"||a==="sugar",oil=a==="cooking_oil";
        return {solubility_state:soluble?"Soluble (Clear Solution)":oil?"Insoluble (Floats on Top)":"Insoluble (Settles at Bottom)",light_passage:oil||(soluble&&c.ctrl_stir_state==="stirred")?"Transparent":"Cloudy/Opaque"};
      },
      draw(p,c,s) {
        const a=c.ctrl_substance,stir=c.ctrl_stir_state==="stirred",clear=s.light_passage==="Transparent";
        const g=group(p,{"data-material":a,"data-stir-state":c.ctrl_stir_state});
        rect(g,182,80,236,215,{fill:"#fff",stroke:"#86a9b9","stroke-width":4,rx:12});
        rect(g,187,115,226,175,{fill:clear?"#cbeaf3":"#afc4ce",stroke:"none",rx:0});
        const floats=s.solubility_state.includes("Floats"),settles=s.solubility_state.includes("Settles");
        if(floats) rect(g,187,115,226,31,{fill:"#ebc96f",stroke:"#bc9d46",rx:0});
        const materialColor={salt:"#fff",sugar:"#efb1d1",sand:"#b8894b",chalk_powder:"#f8f5e7",cooking_oil:"#d7ad41"}[a];
        if(!floats) for(let i=0;i<44;i++) {
          const soluble=a==="salt"||a==="sugar",dissolved=soluble&&stir;
          const x=198+((i*37)%199),y=settles?270+(i%4)*4:dissolved?130+((i*29)%139):230+((i*13)%53);
          if(a==="sugar") node("polygon",{points:`${x},${y-3} ${x+3},${y} ${x},${y+3} ${x-3},${y}`,fill:materialColor,stroke:"#8e7283","stroke-width":.6},g);
          else if(a==="salt") rect(g,x,y,dissolved?2:4,dissolved?2:4,{fill:materialColor,stroke:"#7f9eae","stroke-width":.5,rx:0});
          else circle(g,x,y,a==="sand"?2:3,{fill:materialColor,stroke:"#a1a1a1","stroke-width":.4});
        }
        if(stir) {path(g,"M 248 168 C 210 133 383 130 355 175 C 345 194 250 191 251 168",{stroke:C.teal,"stroke-dasharray":"5 4"});arrow(g,252,168,260,158,{stroke:C.teal});}
        else {line(g,375,70,347,247,{stroke:"#927154","stroke-width":7});text(g,433,88,"Resting spoon",{"font-size":11});}
        arrow(g,55,204,clear?540:237,204,{stroke:C.gold,"stroke-width":5,"stroke-opacity":clear?1:.6});
        text(g,300,317,`${a.replaceAll("_"," ")} · ${stir?"stirred":"unstirred"}`,{"text-anchor":"middle","font-weight":650});
        text(g,300,341,"Simplified transient snapshot, not a dissolution-rate law.",{"text-anchor":"middle","font-size":10});
      }
    },
    math_c05_angle_classifier_v1: {
      compute(c) {
        const a=+c.ctrl_angle_deg;
        return {angle_deg:a,complement_deg:Math.max(0,90-a),supplement_deg:180-a,angle_category:a<90?"Acute (< 90°)":a===90?"Right (= 90°)":"Obtuse (> 90°)"};
      },
      draw(p,c,s) {
        protractor(p,300,280,178,s.angle_deg);
        text(p,300,73,`${s.angle_deg}° · ${s.angle_category}`,{"text-anchor":"middle","font-weight":650});
        text(p,300,325,`Complement: ${s.complement_deg}°   |   Supplement: ${s.supplement_deg}°`,{"text-anchor":"middle"});
        if(s.angle_deg>90) text(p,300,346,"No positive complement: the displayed remainder is clamped to 0°.",{"text-anchor":"middle","font-size":10});
      }
    },
    evs_c05_buoyancy_salinity_v1: {
      compute(c) {
        const density=round(1+.015*Number(c.ctrl_salt_spoons),3),object={raw_egg:1.06,iron_nail:7.8,wood_block:.6}[c.ctrl_object];
        return {fluid_density:density,buoyancy_state:Math.abs(density-object)<1e-9?"Suspended":density>object?"Floats at Surface":"Sinks to Bottom"};
      },
      draw(p,c,s) {
        rect(p,140,79,320,226,{fill:"#fff",stroke:"#89acbb","stroke-width":4,rx:12});
        rect(p,145,112,310,188,{fill:`hsl(196 57% ${88-(s.fluid_density-1)*100}%)`,stroke:"none",rx:0});
        for(let i=0;i<Number(c.ctrl_salt_spoons)*7;i++) circle(p,155+(i*43)%288,128+(i*31)%157,1.3,{fill:C.blue,stroke:"none",opacity:.48});
        line(p,145,112,455,112,{stroke:C.blue,"stroke-width":2});
        const y=s.buoyancy_state==="Floats at Surface"?114:s.buoyancy_state==="Suspended"?201:278;
        const g=group(p,{"data-object":c.ctrl_object,"data-height":y});
        if(c.ctrl_object==="raw_egg") node("ellipse",{cx:300,cy:y,rx:20,ry:27,fill:"#f7e3c3",stroke:"#987b55","stroke-width":2},g);
        else if(c.ctrl_object==="wood_block") {rect(g,270,y-17,60,34,{fill:"#c99b65",stroke:"#815c37"});[0,1,2].forEach(i=>line(g,277,y-10+i*9,324,y-6+i*9,{stroke:"#9c7047"}));}
        else {path(g,`M 270 ${y-4} L 327 ${y-4} L 338 ${y} L 327 ${y+4} L 270 ${y+4} Z`,{fill:"#8293a5",stroke:"#4d6176"});line(g,270,y-12,270,y+12,{stroke:"#4d6176","stroke-width":5});}
        arrow(p,495,y+24,495,y-24,{stroke:C.teal,"stroke-width":3});
        text(p,300,330,`${s.buoyancy_state} · liquid density ${s.fluid_density} g/cm³`,{"text-anchor":"middle"});
        text(p,300,349,"Ideal density comparison; drag and dissolving time are omitted.",{"text-anchor":"middle","font-size":10});
      }
    },
    math_c09_circle_subtended_angle_v1: {
      compute(c) {
        const span=+c.ctrl_arc_span_deg,r=+c.ctrl_radius_cm;
        return {central_angle_deg:span,inscribed_angle_deg:span/2,chord_length_cm:round(2*r*Math.sin(span*Math.PI/360),2),theorem_ratio:2};
      },
      draw(p,c,s) {
        const r=Number(c.ctrl_radius_cm)*8,cx=300,cy=192,t=s.central_angle_deg*Math.PI/360;
        const A=[cx-r*Math.sin(t),cy-r*Math.cos(t)],B=[cx+r*Math.sin(t),cy-r*Math.cos(t)],P=[cx,cy+r];
        circle(p,cx,cy,r,{stroke:C.blue,"stroke-width":2});
        path(p,`M ${A[0]} ${A[1]} A ${r} ${r} 0 0 1 ${B[0]} ${B[1]}`,{stroke:C.gold,"stroke-width":5});
        line(p,...A,...B,{stroke:C.teal,"stroke-width":3});
        [A,B].forEach(point=>{line(p,cx,cy,...point,{stroke:C.purple});line(p,...P,...point,{stroke:C.red});circle(p,...point,4,{fill:C.ink});});
        circle(p,...P,4,{fill:C.ink});circle(p,cx,cy,3,{fill:C.ink});
        text(p,A[0]-15,A[1]-8,"A");text(p,B[0]+8,B[1]-8,"B");text(p,P[0]+8,P[1]+13,"P");text(p,cx+8,cy+16,"O");
        const arcR=Math.min(30,r*.45);
        path(p,`M ${cx-arcR*Math.sin(t)} ${cy-arcR*Math.cos(t)} A ${arcR} ${arcR} 0 0 1 ${cx+arcR*Math.sin(t)} ${cy-arcR*Math.cos(t)}`,{stroke:C.purple});
        text(p,31,86,`∠AOB = ${s.central_angle_deg}°`,{"font-size":12});
        text(p,31,108,`∠APB = ${s.inscribed_angle_deg}°`,{"font-size":12});
        text(p,300,340,`Radius ${c.ctrl_radius_cm} cm · chord ${s.chord_length_cm} cm · central / inscribed = ${s.theorem_ratio}`,{"text-anchor":"middle","font-size":11});
      }
    },
    sci_c09_bio_osmosis_v1: {
      compute(c) {
        const solution=c.ctrl_solution_type,plant=c.ctrl_cell_type==="plant_onion_cell";
        return {net_water_flow:solution==="hypotonic"?"Endosmosis (Inward)":solution==="hypertonic"?"Exosmosis (Outward)":"Dynamic Equilibrium (Zero Net)",cell_state:solution==="hypotonic"?(plant?"Turgid (Wall Pressure Balances)":"Burst (Hemolysis)"):solution==="hypertonic"?"Plasmolysed / Shriveled":"Normal / Flaccid",vacuole_volume_pct:plant?{hypotonic:100,isotonic:70,hypertonic:35}[solution]:0};
      },
      draw(p,c,s) {
        cell(p,c.ctrl_cell_type,c.ctrl_solution_type,s.vacuole_volume_pct);
        const inward=s.net_water_flow.includes("Inward"),outward=s.net_water_flow.includes("Outward");
        [[90,185,175,185],[510,185,425,185],[300,58,300,74]].forEach(([x1,y1,x2,y2])=>{
          if(inward) arrow(p,x1,y1,x2,y2,{stroke:C.blue,"stroke-width":3});
          else if(outward) arrow(p,x2,y2,x1,y1,{stroke:C.blue,"stroke-width":3});
          else {arrow(p,x1,y1-6,x2,y2-6,{stroke:C.blue});arrow(p,x2,y2+6,x1,y1+6,{stroke:C.teal});}
        });
        text(p,30,102,c.ctrl_solution_type,{"font-weight":650});
        text(p,300,346,"Water movement shown schematically; volume percentages are teaching values.",{"text-anchor":"middle","font-size":10});
      }
    },
    math_c10_quadratic_discriminant_v1: {
      compute(c) {
        const a=+c.ctrl_a,b=+c.ctrl_b,cc=+c.ctrl_c,D=b*b-4*a*cc;
        return {discriminant:round(D,2),vertex_x:round(-b/(2*a),2),vertex_y:round(-D/(4*a),2),root_nature:D>0?"Two Distinct Real Roots (D > 0)":D===0?"Two Equal Real Roots (D = 0)":"No Real Roots (D < 0)"};
      },
      draw(p,c,s) {
        const a=+c.ctrl_a,b=+c.ctrl_b,cc=+c.ctrl_c;
        const rawD=b*b-4*a*cc,delta=s.discriminant-round(rawD,2);
        // A rounded readout never shifts the gold polynomial. Only the explicit
        // negative candidate's discriminant delta changes the drawn equation.
        const shift=-delta/(4*a),drawD=rawD+delta;
        const roots=drawD>=0?[(-b-Math.sqrt(drawD))/(2*a),(-b+Math.sqrt(drawD))/(2*a)]:[];
        const vertexX=-b/(2*a),vertexY=-rawD/(4*a)+shift;
        const limit=Math.max(4,Math.abs(vertexX)+2,...roots.map(r=>Math.abs(r)+1));
        const xmin=-limit,xmax=limit,ymin=Math.min(-2,vertexY-2),ymax=Math.max(3,vertexY+2,Math.abs(vertexY)*.4+3);
        const X=x=>55+(x-xmin)/(xmax-xmin)*490,Y=y=>295-(y-ymin)/(ymax-ymin)*210;
        const defs=node("defs",{},p),clip=node("clipPath",{id:"quadratic-plot-clip"},defs);rect(clip,55,85,490,210,{rx:0});
        const plot=group(p,{"clip-path":"url(#quadratic-plot-clip)"});
        for(let i=0;i<=10;i++) {line(plot,55+i*49,85,55+i*49,295,{stroke:"#dce7ed","stroke-width":1});line(plot,55,85+i*21,545,85+i*21,{stroke:"#dce7ed","stroke-width":1});}
        line(p,55,Y(0),545,Y(0),{stroke:C.ink});line(p,X(0),85,X(0),295,{stroke:C.ink});
        let d="";
        for(let i=0;i<=300;i++) {const x=xmin+(xmax-xmin)*i/300,y=a*x*x+b*x+cc+shift;d+=`${i?"L":"M"}${X(x)} ${Y(y)} `;}
        path(plot,d,{stroke:C.teal,"stroke-width":3});
        roots.forEach(r=>circle(plot,X(r),Y(0),5,{fill:C.gold,stroke:C.ink}));
        circle(plot,X(vertexX),Y(vertexY),4,{fill:C.red});
        text(p,55,71,`y = ${a}x² ${b<0?"−":"+"} ${Math.abs(b)}x ${cc<0?"−":"+"} ${Math.abs(cc)}`,{"font-weight":650});
        [xmin,0,xmax].forEach(x=>text(p,X(x),315,round(x,2),{"text-anchor":"middle","font-size":10}));
        [ymin,ymax].forEach(y=>text(p,50,Y(y)+3,round(y,2),{"text-anchor":"end","font-size":10}));
        text(p,300,342,`D = ${s.discriminant} · vertex (${s.vertex_x}, ${s.vertex_y})`,{"text-anchor":"middle"});text(p,550,Y(0)-7,"x");text(p,X(0)+7,82,"y");
      }
    },
    sci_c10_optics_thin_lens_v1: {
      compute(c) {
        const u=+c.ctrl_u_dist,f=+c.ctrl_f_len;
        if(c.ctrl_object_at_infinity==="infinity") return {v_dist:f,magnification:0,image_nature:"Real, Inverted, Point-sized (Object at Infinity)"};
        if(Math.abs(u-f)<1e-3) return {v_dist:"Infinity",magnification:"Infinity",image_nature:"Parallel Rays / Image at Infinity"};
        return {v_dist:u*f/(u-f),magnification:f/(f-u),image_nature:Math.abs(u-2*f)<1e-3?"Real, Inverted, Same Size":u>2*f?"Real, Inverted, Diminished":u>f?"Real, Inverted, Magnified":"Virtual, Erect, Magnified"};
      },
      draw(p,c,s) {rayOpticsBench(p,+c.ctrl_u_dist,+c.ctrl_f_len,c.ctrl_object_at_infinity==="infinity",s.v_dist,s.magnification);}
    }
  };
  function scaffold(p,profile,c,s) {
    if(profile==="Remedial_Concrete") {
      const g=group(p,{"data-scaffold":"concrete-step-strip"});
      ["1 · Change","2 · Observe","3 · Compare"].forEach((label,i)=>{circle(g,32+i*185,27,13,{fill:i===1?C.teal:C.pale,stroke:"none"});text(g,53+i*185,31,label,{"font-size":11});});
    } else if(profile==="Counterfactual_Challenge") {
      const g=group(p,{"data-scaffold":"counterfactual-inset"});
      rect(g,18,8,564,39,{fill:"#f2edf9",stroke:"#c7b5df",rx:8});
      path(g,"M 34 31 L 45 18 L 56 31 Z",{fill:C.purple,stroke:"none"});
      text(g,67,25,"Boundary test",{"font-weight":650,"font-size":11});
      text(g,174,25,"Which change would reverse your prediction?",{"font-size":11});
      const branches=group(g,{"data-structure":"hypothesis-branches"});
      line(branches,67,33,152,33,{stroke:C.purple});circle(branches,162,33,3,{fill:C.purple});circle(branches,176,33,3,{fill:"#fff",stroke:C.purple});
    } else {
      const g=group(p,{"data-scaffold":"coordinate-guide"});
      for(let x=20;x<=580;x+=40) line(g,x,53,x,302,{stroke:"#e7eff4","stroke-width":.6});
      text(g,24,29,"MODEL → DIAGRAM → MEASUREMENT",{"font-size":11,"letter-spacing":1.2,fill:C.muted});
      rect(g,453,12,126,25,{fill:"#e3f2f4",stroke:"none",rx:6});text(g,466,29,`${Object.keys(c).length} linked controls`,{"font-size":10});
    }
  }
  function draw(svg,oracleId,controls,state,profile) {
    const previous=svg.querySelector("[data-simulation-scene]");
    if(previous) previous.remove();
    const model=models[oracleId];
    if(!model) throw new Error("Unsupported simulation model");
    const scene=group(svg,{"data-simulation-scene":"true","data-model":oracleId});
    scaffold(scene,profile,controls,state);
    const diagram=group(scene,{"data-diagram":"physical-model"});
    model.draw(diagram,controls,state);
    const description=svg.querySelector("desc");
    if(description) description.textContent=Object.entries(state).map(([k,v])=>`${k.replaceAll("_"," ")}: ${v}`).join(". ");
  }
  global.SimSVG=Object.freeze({node,group,line,rect,circle,text,path,arrow,fractionGrid,protractor,rayOpticsBench,circuitNodes,cell,round,models,draw});
})(window);