"""Offline, Python-oracle-backed verification of untrusted educational applets."""

from .playwright_harness import verify_html_applet

__all__ = ["verify_html_applet"]