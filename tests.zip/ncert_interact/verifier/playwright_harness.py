"""Bounded, offline DOM/geometry/raster verification, not an adversarial proof.

Only trusted Python registry functions determine expected answers. Candidate JS
assertions and update hooks are never invoked by the verifier. Native controls
drive events, while fixed evaluator strings collect untrusted observations.
Untouched defaults must already render correct science and a nonblank viewport.
Mandatory private single-control transitions restore defaults between controls;
unchanged sliders/selects receive no events that could conceal a dead listener.
Initial science counts toward accuracy, but never toward interaction coverage.

Each applet gets a fresh context, blocked resources/workers/downloads, no granted
permissions, and headless sandboxed Chromium when a browser is not supplied.
Callers reusing a browser must launch it with equivalent sandbox settings.
Playwright and Pillow are optional at import time, required for browser checks.

Limitations: DOM telemetry/getters and same-realm browser APIs can be forged;
seeded probes are reproducible, not cryptographic secrets. Raster/geometry change
is evidence of visible interaction, not proof the drawing encodes correct science.
Canvas text cannot be distinguished from geometry. This is not a hostile-code OS
sandbox: run unknown pages under a dedicated low-privilege OS/container boundary.
No remote APIs are used. Documentation lives here because file ownership excludes
the repository README and dependency manifests.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import io
import json
import math
import random
import re
import time
from collections.abc import Awaitable
from html.parser import HTMLParser
from itertools import chain
from pathlib import Path
from typing import TYPE_CHECKING, Any, TypeVar

from ncert_interact.oracles.registry import evaluate_oracle
from ncert_interact.schemas.pis_schema import DOMReadoutContract, PISSchema, VerificationReport

if TYPE_CHECKING:
    from playwright.async_api import Browser, Locator, Page

_T = TypeVar("_T")
_NUMBER = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"
_PIXEL_FRACTION = .0005
_CSP = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; worker-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'"


def _with_verifier_policy(document: str) -> str:
    """Insert policy at a real head, never a comment or script containing '<head>'."""
    class HeadParser(HTMLParser):
        def __init__(self) -> None:
            super().__init__(convert_charrefs=False)
            self.offsets = [0]
            self.offsets.extend(match.end() for match in re.finditer("\n", document))
            self.head_end: int | None = None
            self.content_start: int | None = None

        def handle_starttag(self, tag: str, attrs: list) -> None:
            if tag in {"iframe", "frame", "frameset", "object", "embed", "base"}:
                raise ValueError(f"disallowed embedded execution context: {tag}")
            line, column = self.getpos()
            start = self.offsets[line - 1] + column
            if tag == "head" and self.head_end is None:
                self.head_end = start + len(self.get_starttag_text() or "")
            elif tag not in {"html", "head"} and self.content_start is None:
                self.content_start = start

    parser = HeadParser()
    parser.feed(document)
    parser.close()
    # Malformed documents may have executable content before an explicit head.
    # Put policy before that content rather than accepting a later decoy head.
    position = parser.head_end if parser.head_end is not None else 0
    if parser.content_start is not None and parser.content_start < position:
        position = parser.content_start
    policy = '<meta http-equiv="Content-Security-Policy" content="' + _CSP + '">'
    return document[:position] + policy + document[position:]


def async_playwright():
    """Lazy import keeps pure parsing/probe tests usable without browser packages."""
    from playwright.async_api import async_playwright as factory

    return factory()


def _normalized(value: str) -> str:
    return " ".join(value.casefold().split())


def _matches(actual: Any, expected: Any, readout: DOMReadoutContract, *, visible: bool = False) -> bool:
    if readout.dtype == "string_enum":
        return type(actual) is str and type(expected) is str and _normalized(actual) == _normalized(expected)
    if visible:
        if type(actual) is not str:
            return False
        suffix = rf"(?:\s*{re.escape(readout.unit)})?" if readout.unit else ""
        match = re.fullmatch(rf"\s*({_NUMBER}|Infinity){suffix}\s*", actual)
        if match is None:
            return False
        actual = match[1]
        if actual != "Infinity":
            actual = float(actual)
    if expected == "Infinity":
        return type(actual) is str and actual == "Infinity"
    return (
        type(actual) in (int, float) and type(expected) in (int, float)
        and math.isfinite(actual) and math.isfinite(expected)
        and math.isclose(actual, expected, rel_tol=0, abs_tol=readout.tolerance or 0)
    )


def _input_equal(actual: Any, expected: Any) -> bool:
    if type(actual) is bool or type(expected) is bool or actual is None:
        return False
    if str(actual) == str(expected):
        return True
    try:
        a, b = float(actual), float(expected)
        return math.isfinite(a) and math.isfinite(b) and math.isclose(a, b, rel_tol=0, abs_tol=1e-8)
    except (TypeError, ValueError, OverflowError):
        return False


def _build_probes(pis: PISSchema, count: int, seed: int) -> list[tuple[str, dict]]:
    """Isolate each control before seeded full-input samples, using trusted domains.

    Prefer unseen combinations. An exhausted finite domain (the osmosis seed
    publishes all six settings) necessarily uses explicitly marked seeded replays.
    These are independent draws, not extra secret coverage of an exhausted domain.
    """
    probes = [(p.probe_id, dict(p.control_inputs)) for p in pis.verification_oracle.probe_cases]
    def signature(inputs: dict) -> tuple:
        return tuple(float(inputs[c.id]) if c.tag == "input_range" else str(inputs[c.id]) for c in pis.controls_contract)

    oracle_id = pis.verification_oracle.trusted_oracle_id
    baseline = {c.id: c.default_val for c in pis.controls_contract}
    baseline_state = evaluate_oracle(oracle_id, baseline)
    if probes[-1][1] != baseline:
        probes.append(("control_baseline", dict(baseline)))
    for control in pis.controls_contract:
        if control.tag == "input_range":
            low, high, step = control.min_val, control.max_val, control.step
            assert low is not None and high is not None and step is not None
            steps = math.floor((high - low) / step + 1e-8)
            # Prefer endpoints: tiny changes can be below the raster threshold.
            candidates = (round(low + index * step, 10) for index in chain((0, steps), range(1, steps)))
        else:
            candidates = iter(control.options or [control.default_val])
        for value in candidates:
            if _input_equal(value, baseline[control.id]):
                continue
            inputs = {**baseline, control.id: value}
            try:
                state = evaluate_oracle(oracle_id, inputs)
            except ValueError:
                continue
            if state != baseline_state and control.accepts(value):
                probes.append((f"control_{control.id}", inputs))
                probes.append((f"control_restore_{control.id}", dict(baseline)))
                break
        else:
            raise ValueError(f"cannot isolate an oracle-meaningful transition for control: {control.id}")
    signatures = {signature(inputs) for _, inputs in probes}
    domain_size = math.prod(
        math.floor((c.max_val - c.min_val) / c.step + 1e-8) + 1
        if c.tag == "input_range" and c.max_val is not None and c.min_val is not None and c.step is not None
        else len(c.options or [c.default_val]) for c in pis.controls_contract
    )
    rng = random.Random(seed)
    previous = evaluate_oracle(oracle_id, probes[-1][1])
    for index in range(count):
        replay = len(signatures) >= domain_size
        for _ in range(10000):
            inputs: dict[str, float | str] = {}
            for control in pis.controls_contract:
                if control.tag == "input_range":
                    low, high, step = control.min_val, control.max_val, control.step
                    assert low is not None and high is not None and step is not None
                    steps = math.floor((high - low) / step + 1e-8)
                    inputs[control.id] = round(low + rng.randint(0, steps) * step, 10)
                else:
                    inputs[control.id] = rng.choice(control.options or [control.default_val])
            key = signature(inputs)
            if not replay and key in signatures:
                continue
            try:
                state = evaluate_oracle(oracle_id, inputs)
            except ValueError:
                continue
            if state == previous or not all(c.accepts(inputs[c.id]) for c in pis.controls_contract):
                continue
            signatures.add(key)
            probes.append((f"private_{'replay_' if replay else ''}{index + 1:02d}", inputs))
            previous = state
            break
        else:
            raise ValueError("cannot sample distinct oracle-valid private transitions from the declared domain")
    return probes


# These are fixed collectors, not assertions supplied by an applet or an LLM.
_ELEMENT = r"""e => {
  const r=e.getBoundingClientRect(); let opacity=1;
  for(let n=e;n instanceof Element;n=n.parentElement){
    const s=getComputedStyle(n);opacity*=Number(s.opacity);
    if(n.hidden||s.display==='none'||s.visibility!=='visible'||s.contentVisibility==='hidden')return {ok:false};
    if(n!==e&&/(hidden|clip|scroll|auto)/.test(s.overflow+s.overflowX+s.overflowY)){
            const b=n.getBoundingClientRect();if(r.right<=b.left||r.left>=b.right||r.bottom<=b.top||r.top>=b.bottom)return {ok:false,width:r.width,height:r.height};
    }
  }
    // Inline badges can wrap: the union-box midpoint may be empty whitespace.
    // Hit-test actual line fragments, not that potentially empty midpoint.
    const exposed=[...e.getClientRects()].some(b=>{
        const x=b.left+b.width/2,y=b.top+b.height/2,hit=document.elementFromPoint(x,y);
        return b.width>0&&b.height>0&&x>=0&&y>=0&&x<innerWidth&&y<innerHeight&&!!hit&&(hit===e||e.contains(hit));
    });
    return {ok:opacity>=.9&&r.width>0&&r.height>0&&exposed,
    width:r.width,height:r.height,disabled:e.matches(':disabled,[aria-disabled="true"]')||!!e.closest('[inert]')};
}"""

_AUDIT = r"""args => {
  const ids=new Map();for(const e of document.querySelectorAll('[id]'))ids.set(e.id,(ids.get(e.id)||0)+1);
  const native=[...document.querySelectorAll('input,select,button,textarea,[role="button"],[role="slider"],[contenteditable="true"]')];
  return {duplicates:[...ids].filter(([,n])=>n>1).map(([id])=>id),
    controls:native.map(e=>({id:e.id,tag:e.localName,type:e.getAttribute('type'),min:e.getAttribute('min'),max:e.getAttribute('max'),step:e.getAttribute('step'),
      options:e.localName==='select'?[...e.options].map(o=>o.value):null,
      labelled:!!(e.getAttribute('aria-label')||'').trim()||!!(e.getAttribute('aria-labelledby')||'').split(/\s+/).some(id=>(document.getElementById(id)?.innerText||'').trim())||
        [...(e.labels||[])].some(l=>l.innerText.trim())||(e.localName==='button'&&!!e.innerText.trim())})),
    views:args.views.map(id=>({id,count:[...document.querySelectorAll('[id]')].filter(e=>e.id===id).length})),
    readouts:args.readouts.map(id=>({id,count:[...document.querySelectorAll('[data-testid]')].filter(e=>e.dataset.testid===id).length}))};
}"""

_VALUES = r"""defs => Object.fromEntries(defs.map(d=>{
  const e=document.getElementById(d.id);let v=e?.value;
  if(d.tag==='button'){
    v=e?.value||e?.dataset.value;
    if(v===undefined&&d.options?.length===2&&e?.hasAttribute('aria-pressed')){
      v=e.getAttribute('aria-pressed')==='true'?d.options.find(x=>String(x)!==String(d.default_val)):d.default_val;
    }
  }
  return [d.id,v??null];
}))"""

_STATE = "() => JSON.parse(JSON.stringify(window.__SIM_STATE__ ?? null))"

_VISUAL = r"""root => {
  const rb=root.getBoundingClientRect();
  function visible(e){
    let opacity=1;const b=e.getBoundingClientRect();
    if(b.right<rb.left||b.left>rb.right||b.bottom<rb.top||b.top>rb.bottom)return false;
    for(let n=e;n instanceof Element;n=n.parentElement){
      const s=getComputedStyle(n);opacity*=Number(s.opacity);
      if(n.hidden||s.display==='none'||s.visibility!=='visible'||s.contentVisibility==='hidden'||opacity<=.01)return false;
      if(n!==e&&(n.localName==='svg'||/(hidden|clip|scroll|auto)/.test(s.overflow+s.overflowX+s.overflowY))){
        const c=n.getBoundingClientRect();if(b.right<c.left||b.left>c.right||b.bottom<c.top||b.top>c.bottom)return false;
      }
    }
    return (b.width>0||b.height>0)&&b.right>=0&&b.bottom>=0&&b.left<innerWidth&&b.top<innerHeight;
  }
  const surfaces=[...(root.matches('svg,canvas')?[root]:[]),...root.querySelectorAll('svg,canvas')].filter(visible);
  return surfaces.map(s=>{
    const b=s.getBoundingClientRect();
    if(s.localName==='canvas')return {kind:'canvas',width:b.width,height:b.height,data:s.toDataURL('image/png')};
    const attrs=['x','y','x1','y1','x2','y2','cx','cy','r','rx','ry','width','height','d','points','transform','viewBox'];
    const shapes=[...s.querySelectorAll('circle,ellipse,rect,line,path,polygon,polyline,image')].filter(e=>{
      if(e.closest('defs,clipPath,mask,pattern,marker,symbol'))return false;
      const c=getComputedStyle(e);return visible(e)&&(c.fill!=='none'||(c.stroke!=='none'&&Number.parseFloat(c.strokeWidth)>0));
    });
    function box(e){const r=e.getBoundingClientRect();return [r.x-rb.x,r.y-rb.y,r.width,r.height].map(v=>Math.round(v*100)/100);}
    const geometry=shapes.map(e=>[e.localName,attrs.filter(a=>e.hasAttribute(a)).map(a=>[a,e.getAttribute(a)]),box(e)]);
    // Groups include transforms and graphical-child bounds, never text/metadata boxes.
    const groups=[...s.querySelectorAll('g')].filter(g=>shapes.some(e=>g.contains(e))).map(g=>{
      const bs=shapes.filter(e=>g.contains(e)).map(box);return [g.getAttribute('transform')||'',
        Math.min(...bs.map(b=>b[0])),Math.min(...bs.map(b=>b[1])),Math.max(...bs.map(b=>b[0]+b[2])),Math.max(...bs.map(b=>b[1]+b[3]))];
    });
    return {kind:'svg',width:b.width,height:b.height,serialized:s.innerHTML,geometry,groups};
  });
}"""


async def _bounded(awaitable: Awaitable[_T], timeout_ms: int) -> _T:
    return await asyncio.wait_for(awaitable, timeout_ms / 1000)


def _digest(value: Any) -> str:
    payload = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, ensure_ascii=False).encode()
    return hashlib.sha256(payload).hexdigest()


def _image(png: bytes):
    from PIL import Image

    with Image.open(io.BytesIO(png)) as image:
        # Composite alpha onto white: transparent RGB noise is not visible evidence.
        rgba = image.convert("RGBA")
        result = Image.new("RGBA", rgba.size, "white")
        result.alpha_composite(rgba)
        return result.convert("RGB")


def _nonblank(png: bytes) -> bool:
    from PIL import ImageChops, ImageStat

    image = _image(png)
    background = image.copy()
    background.paste(image.getpixel((0, 0)), (0, 0, image.width, image.height))
    difference = ImageChops.difference(image, background)
    return max(ImageStat.Stat(difference).stddev) > 2 and sum(difference.convert("L").point(lambda p: 255 if p > 8 else 0).histogram()[1:]) / (image.width * image.height) > _PIXEL_FRACTION


def _pixel_change(before: bytes, after: bytes) -> float:
    from PIL import ImageChops

    a, b = _image(before), _image(after)
    if a.size != b.size:
        return 0.0  # Resizing the viewport alone is not model interaction.
    channels = ImageChops.difference(a, b).split()
    difference = ImageChops.lighter(ImageChops.lighter(channels[0], channels[1]), channels[2])
    histogram = difference.histogram()
    return sum(histogram[9:]) / (a.width * a.height)


async def _element_ok(locator: Locator, timeout_ms: int, *, touch: int = 0) -> bool:
    if await _bounded(locator.count(), timeout_ms) != 1:
        return False
    info = await _bounded(locator.evaluate(_ELEMENT, timeout=timeout_ms), timeout_ms)
    # Hidden/disabled/undersized elements cannot be repaired by scrolling. Avoid
    # paying a full Playwright visibility timeout for every negative probe.
    if info.get("disabled") or info.get("width", 0) <= 0 or info.get("height", 0) <= 0 or info["width"] < touch or info["height"] < touch:
        return False
    if not info["ok"]:
        await _bounded(locator.scroll_into_view_if_needed(timeout=timeout_ms), timeout_ms)
        info = await _bounded(locator.evaluate(_ELEMENT, timeout=timeout_ms), timeout_ms)
    return bool(info["ok"] and not info.get("disabled") and info.get("width", 0) >= touch and info.get("height", 0) >= touch)


def _readout_locator(page: Page, testid: str) -> Locator:
    return page.locator(f'[data-testid="{testid}"]')


async def _audit(page: Page, pis: PISSchema, timeout_ms: int) -> tuple[float, bool, list[str]]:
    data = await _bounded(page.evaluate(_AUDIT, {"views": pis.ui_complexity_budget.required_views, "readouts": [r.testid for r in pis.required_dom_readouts]}), timeout_ms)
    errors = []
    if data["duplicates"]:
        errors.append("duplicate DOM IDs: " + ", ".join(data["duplicates"]))
    expected_ids = {c.id for c in pis.controls_contract}
    actual_ids = [c["id"] for c in data["controls"]]
    compliant = len(actual_ids) <= pis.ui_complexity_budget.max_controls and len(actual_ids) == len(expected_ids) and set(actual_ids) == expected_ids and not data["duplicates"]
    found = 0
    for control in pis.controls_contract:
        candidates = [c for c in data["controls"] if c["id"] == control.id]
        if len(candidates) != 1:
            errors.append(f"missing or duplicate control: {control.id}")
            compliant = False
            continue
        dom = candidates[0]
        valid = dom["tag"] == ("input" if control.tag == "input_range" else control.tag)
        if control.tag == "input_range":
            valid = valid and dom["type"] == "range" and all(_input_equal(dom[key], value) for key, value in (("min", control.min_val), ("max", control.max_val), ("step", control.step)))
        elif control.tag == "select":
            valid = valid and dom["options"] == [str(v) for v in control.options or []]
        else:
            valid = valid and dom["type"] in (None, "button")
        try:
            actionable = await _element_ok(page.locator(f'[id="{control.id}"]'), timeout_ms, touch=pis.ui_complexity_budget.min_touch_target_px)
        except Exception:
            actionable = False
        found += int(valid and actionable)
        compliant = compliant and valid and dom["labelled"] and actionable
        if not (valid and dom["labelled"] and actionable):
            errors.append(f"invalid, unlabelled, hidden, disabled, covered, or undersized control: {control.id}")
    for view in data["views"]:
        try:
            locator = page.locator(f'[id="{view["id"]}"]')
            valid = view["count"] == 1 and await _element_ok(locator, timeout_ms)
            if valid:
                bounds = await _bounded(locator.bounding_box(timeout=timeout_ms), timeout_ms)
                valid = bounds is not None and bounds["width"] >= 200 and bounds["height"] >= 150
        except Exception:
            valid = False
        compliant = compliant and valid
        if not valid:
            errors.append(f"missing, hidden, or undersized required view: {view['id']}")
    for readout in data["readouts"]:
        if readout["count"] != 1:
            errors.append(f"missing or duplicate readout: {readout['id']}")
    return found / len(pis.controls_contract), bool(compliant), errors


async def _apply(page: Page, pis: PISSchema, inputs: dict, timeout_ms: int) -> None:
    definitions = [c.model_dump(mode="json") for c in pis.controls_contract]
    initial_values = await _bounded(page.evaluate(_VALUES, definitions), timeout_ms)
    for control in pis.controls_contract:
        target = inputs[control.id]
        if control.tag != "button" and _input_equal(initial_values.get(control.id), target):
            continue
        element = page.locator(f'[id="{control.id}"]')
        if not await _element_ok(element, timeout_ms, touch=pis.ui_complexity_budget.min_touch_target_px):
            raise ValueError(f"control is not actionable: {control.id}")
        if control.tag == "input_range":
            # Playwright fill rejects range inputs in Chromium. Set the native
            # DOM property, then drive the actual registered event listeners.
            await _bounded(element.evaluate("(element, value) => { element.value = String(value); }", target, timeout=timeout_ms), timeout_ms)
            await _bounded(element.dispatch_event("input", timeout=timeout_ms), timeout_ms)
            await _bounded(element.dispatch_event("change", timeout=timeout_ms), timeout_ms)
        elif control.tag == "select":
            await _bounded(element.select_option(value=str(target), timeout=timeout_ms), timeout_ms)
        else:
            for _ in range(len(control.options or []) + 1):
                values = await _bounded(page.evaluate(_VALUES, definitions), timeout_ms)
                if _input_equal(values.get(control.id), target):
                    break
                await _bounded(element.click(timeout=timeout_ms), timeout_ms)
            else:
                raise ValueError(f"button did not cycle to requested option: {control.id}")
    values = await _bounded(page.evaluate(_VALUES, definitions), timeout_ms)
    if not all(_input_equal(values.get(c.id), inputs[c.id]) for c in pis.controls_contract):
        raise ValueError("native control values do not match complete requested inputs")


async def _snapshot(page: Page, pis: PISSchema, timeout_ms: int) -> dict:
    state = await _bounded(page.evaluate(_STATE), timeout_ms)
    readouts: dict[str, dict] = {}
    for contract in pis.required_dom_readouts:
        locator = _readout_locator(page, contract.testid)
        try:
            visible = await _element_ok(locator, timeout_ms)
            text = await _bounded(locator.inner_text(timeout=timeout_ms), timeout_ms) if visible else ""
            readouts[contract.state_key] = {"visible": visible and bool(text.strip()), "text": text}
        except Exception:
            readouts[contract.state_key] = {"visible": False, "text": ""}
    view = page.locator('[id="sim-viewport"]')
    if await _bounded(view.count(), timeout_ms) == 0:
        view = page.locator('canvas[id="sim-canvas"]')
    result = {"state": state, "readouts": readouts, "visual_valid": False, "geometry_signature": "", "svg_signature": "", "canvas_signature": "", "raster": b""}
    if not await _element_ok(view, timeout_ms):
        return result
    bounds = await _bounded(view.bounding_box(timeout=timeout_ms), timeout_ms)
    if bounds is None or bounds["width"] < 200 or bounds["height"] < 150:
        return result
    surfaces = await _bounded(view.evaluate(_VISUAL, timeout=timeout_ms), timeout_ms)
    signatures, serialized, canvases = [], [], []
    valid = bool(surfaces)
    for surface in surfaces:
        valid = valid and surface["width"] > 0 and surface["height"] > 0
        if surface["kind"] == "svg":
            serialized.append(surface["serialized"])
            signatures.append([surface["geometry"], surface["groups"]])
            valid = valid and bool(surface["geometry"])
        else:
            png = base64.b64decode(surface["data"].split(",", 1)[1], validate=True)
            canvases.append(_digest(png))
            signatures.append(["canvas", _digest(png)])
            valid = valid and _nonblank(png)
    # Text masks cannot vary with text length: hide text through a fixed stylesheet
    # rather than Playwright mask rectangles whose changing bounds can spoof pixels.
    png = await _bounded(view.screenshot(type="png", timeout=timeout_ms, animations="disabled", style="svg text,svg foreignObject{visibility:hidden!important}"), timeout_ms)
    result.update(visual_valid=bool(valid and _nonblank(png)), geometry_signature=_digest(signatures), svg_signature=_digest(serialized), canvas_signature=_digest(canvases), raster=png)
    return result


def _visual_transition(before: dict, after: dict) -> tuple[bool, float]:
    fraction = _pixel_change(before["raster"], after["raster"]) if before["raster"] and after["raster"] else 0.0
    return bool(before["visual_valid"] and after["visual_valid"] and before["geometry_signature"] != after["geometry_signature"] and fraction > _PIXEL_FRACTION), fraction


def _scientific_channels(snapshot: dict, expected: dict, pis: PISSchema) -> tuple[bool, bool]:
    state = snapshot["state"]
    state_ok = type(state) is dict and all(_matches(state.get(r.state_key), expected[r.state_key], r) for r in pis.required_dom_readouts)
    readouts_ok = all(snapshot["readouts"][r.state_key]["visible"] and _matches(snapshot["readouts"][r.state_key]["text"], expected[r.state_key], r, visible=True) for r in pis.required_dom_readouts)
    return state_ok, readouts_ok


async def _exercise(page: Page, pis: PISSchema, probes: list[tuple[str, dict]], report: VerificationReport, timeout_ms: int) -> None:
    # Inspect untouched defaults before any control events can repair a bad page.
    defaults = {c.id: c.default_val for c in pis.controls_contract}
    definitions = [c.model_dump(mode="json") for c in pis.controls_contract]
    initial_values = await _bounded(page.evaluate(_VALUES, definitions), timeout_ms)
    initial = await _snapshot(page, pis, timeout_ms)
    initial_expected = evaluate_oracle(pis.verification_oracle.trusted_oracle_id, defaults)
    native_ok = all(_input_equal(initial_values.get(key), value) for key, value in defaults.items())
    state_ok, readouts_ok = _scientific_channels(initial, initial_expected, pis)
    initial_correct = native_ok and state_ok and readouts_ok and initial["visual_valid"]
    initial_spoof = state_ok and (not readouts_ok or not initial["visual_valid"])
    report.spoofing_detected = initial_spoof
    report.probe_details.append({
        "probe_id": "initial", "private": False, "private_replay": False, "control_check": False,
        "control_inputs": defaults, "observed_inputs": initial_values, "expected_state": initial_expected,
        "observed_state": initial["state"], "readouts": initial["readouts"], "controls_set": native_ok,
        "expected_changed": False, "state_correct": state_ok, "readouts_correct": readouts_ok,
        "visual_valid": initial["visual_valid"], "visual_changed": False,
        "geometry_signature": initial["geometry_signature"], "svg_signature": initial["svg_signature"],
        "canvas_signature": initial["canvas_signature"], "viewport_png_sha256": _digest(initial["raster"]),
        "changed_pixel_fraction": 0.0, "interaction_correct": False, "scientific_correct": initial_correct,
        "spoofing_detected": initial_spoof, "errors": [] if initial_correct else ["initial defaults, science, readouts, or viewport invalid"],
    })
    found, compliant, audit_errors = await _audit(page, pis, timeout_ms)
    report.controls_found_ratio = found
    report.ui_budget_compliance = compliant
    # A default-first probe must observe a real transition rather than compare an
    # applet's untouched default to itself. Initialize using the last PUBLIC probe.
    previous_inputs = dict(pis.verification_oracle.probe_cases[-1].control_inputs)
    previous_expected = evaluate_oracle(pis.verification_oracle.trusted_oracle_id, previous_inputs)
    try:
        await _apply(page, pis, previous_inputs, timeout_ms)
    except Exception as exc:
        audit_errors.append(f"initialization failed: {type(exc).__name__}: {exc}")
    before = await _snapshot(page, pis, timeout_ms)
    meaningful = interactions = 0
    correct = int(initial_correct)
    for probe_id, inputs in probes:
        expected = evaluate_oracle(pis.verification_oracle.trusted_oracle_id, inputs)
        transition = expected != previous_expected and inputs != previous_inputs
        meaningful += int(transition)
        errors = list(audit_errors)
        controls_set = False
        try:
            await _apply(page, pis, inputs, timeout_ms)
            controls_set = True
        except Exception as exc:
            errors.append(f"interaction failed: {type(exc).__name__}: {exc}")
        after = await _snapshot(page, pis, timeout_ms)
        state = after["state"]
        state_ok, readouts_ok = _scientific_channels(after, expected, pis)
        changed, pixels = _visual_transition(before, after)
        claimed_changed = before["state"] != after["state"]
        spoof = ((state_ok or claimed_changed) and not readouts_ok) or (transition and (state_ok or claimed_changed) and not changed)
        report.spoofing_detected = report.spoofing_detected or spoof
        interaction_ok = controls_set and changed and all(item["visible"] for item in after["readouts"].values())
        interactions += int(transition and interaction_ok)
        science_ok = controls_set and state_ok and readouts_ok and after["visual_valid"] and (not transition or changed)
        correct += int(science_ok)
        control_id = next((c.id for c in pis.controls_contract if probe_id == f"control_{c.id}"), None)
        report.probe_details.append({
            "probe_id": probe_id, "private": probe_id.startswith(("private_", "control_")), "private_replay": probe_id.startswith("private_replay_"), "control_inputs": inputs,
            "control_check": control_id is not None, "control_id": control_id,
            "changed_controls": [c.id for c in pis.controls_contract if not _input_equal(previous_inputs[c.id], inputs[c.id])],
            "expected_state": expected, "observed_state": state, "readouts": after["readouts"],
            "controls_set": controls_set, "expected_changed": transition, "state_correct": state_ok,
            "readouts_correct": readouts_ok, "visual_valid": after["visual_valid"], "visual_changed": changed,
            "geometry_signature": after["geometry_signature"], "svg_signature": after["svg_signature"],
            "canvas_signature": after["canvas_signature"], "viewport_png_sha256": _digest(after["raster"]),
            "changed_pixel_fraction": pixels, "interaction_correct": bool(transition and interaction_ok),
            "scientific_correct": science_ok, "spoofing_detected": spoof, "errors": errors,
        })
        previous_inputs, previous_expected, before = inputs, expected, after
    report.interaction_coverage = interactions / meaningful if meaningful else 0.0
    report.scientific_oracle_acc = correct / (len(probes) + 1)
    # Catch controls/views inserted or invalidated during an interaction as well.
    final_found, final_compliant, _ = await _audit(page, pis, timeout_ms)
    report.controls_found_ratio = min(report.controls_found_ratio, final_found)
    report.ui_budget_compliance = report.ui_budget_compliance and final_compliant


async def verify_html_applet(
    html_path: Path, pis: PISSchema, *, rollout_id: str | None = None,
    generation_latency_sec: float = 0, browser: Browser | None = None,
    timeout_ms: int = 5000, random_probe_count: int = 2, random_seed: int = 2027,
) -> VerificationReport:
    """Verify a local applet, always closing its private context, never a caller's browser.

    Invalid API arguments raise; missing files, browser installs, page errors and
    timeouts return a fail-closed report with diagnostic ``console_errors``.
    ``timeout_ms`` bounds each action/evaluation and a finite derived total budget.
    There are no implicit retries, network clients, installs, or shared page state.
    """
    for name, value, minimum in (("timeout_ms", timeout_ms, 1), ("random_probe_count", random_probe_count, 0)):
        if type(value) is not int or value < minimum:
            raise ValueError(f"{name} must be an integer >= {minimum}")
    if type(random_seed) is not int:
        raise TypeError("random_seed must be an integer")
    if type(generation_latency_sec) not in (int, float) or not math.isfinite(generation_latency_sec) or generation_latency_sec < 0:
        raise ValueError("generation_latency_sec must be nonnegative and finite")
    started = time.perf_counter()
    report = VerificationReport(task_id=pis.task_id, rollout_id=rollout_id or Path(html_path).stem or pis.task_id, generation_latency_sec=generation_latency_sec)
    manager = owned_browser = context = None
    try:
        html = Path(html_path).read_text(encoding="utf-8")
        probes = _build_probes(pis, random_probe_count, random_seed)
        if browser is None:
            manager = await _bounded(async_playwright().start(), timeout_ms)
            owned_browser = await _bounded(manager.chromium.launch(headless=True, chromium_sandbox=True), timeout_ms)
            browser = owned_browser
        context = await _bounded(browser.new_context(
            viewport={"width": 1100, "height": 1200}, device_scale_factor=1,
            accept_downloads=False, service_workers="block", permissions=[],
            java_script_enabled=True, bypass_csp=False,
        ), timeout_ms)
        await _bounded(context.route("**/*", lambda route: route.abort()), timeout_ms)
        # HTTP routing does not intercept WebSockets in recent Chromium versions.
        if hasattr(context, "route_web_socket"):
            await _bounded(context.route_web_socket("**/*", lambda socket: socket.close()), timeout_ms)
        await _bounded(context.add_init_script("""(() => {
          for(const name of ['Worker','SharedWorker','WebSocket','RTCPeerConnection','webkitRTCPeerConnection'])
            Object.defineProperty(globalThis,name,{value:undefined,writable:false,configurable:false});
        })();"""), timeout_ms)
        page = await _bounded(context.new_page(), timeout_ms)
        page.set_default_timeout(timeout_ms)
        page.set_default_navigation_timeout(timeout_ms)
        page.on("pageerror", lambda error: report.console_errors.append(f"pageerror: {error}"))
        page.on("console", lambda message: report.console_errors.append(f"console: {message.text}") if message.type == "error" else None)
        page.on("dialog", lambda dialog: dialog.dismiss())
        # set_content avoids file:// access and navigation to a candidate-controlled
        # origin. Put our policy first; subsequent candidate CSP can only restrict.
        html = _with_verifier_policy(html)
        await _bounded(page.set_content(html, wait_until="load", timeout=timeout_ms), timeout_ms)
        report.exec_valid = True
        total_seconds = timeout_ms / 1000 * (10 + len(probes) * (len(pis.controls_contract) + len(pis.required_dom_readouts) + 8))
        await asyncio.wait_for(_exercise(page, pis, probes, report, timeout_ms), total_seconds)
    except Exception as exc:
        report.exec_valid = False
        report.console_errors.append(f"verification failed: {type(exc).__name__}: {exc}")
    finally:
        for resource, method in ((context, "close"), (owned_browser, "close"), (manager, "stop")):
            if resource is not None:
                try:
                    await _bounded(getattr(resource, method)(), timeout_ms)
                except Exception as exc:
                    report.console_errors.append(f"cleanup failed: {type(exc).__name__}: {exc}")
        report.verification_latency_sec = time.perf_counter() - started
    report.exec_valid = report.exec_valid and not report.console_errors
    report.passed_all = bool(report.exec_valid and report.controls_found_ratio == 1 and report.ui_budget_compliance and report.interaction_coverage == 1 and report.scientific_oracle_acc == 1 and not report.spoofing_detected)
    return report


__all__ = ["verify_html_applet"]