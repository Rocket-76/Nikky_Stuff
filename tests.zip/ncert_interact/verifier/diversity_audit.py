"""Pure structural audit of gold references across profiles of one seed/mode.

JavaScript is parsed, never executed. Install ``esprima`` in the application
environment to enable the AST metric; missing/failed parsing yields null, not a
regex surrogate or fabricated zero. DOM topology describes supplied HTML, not
the live SVG created by JavaScript. Probe graphs describe only observed traces.
All distances are normalized multiset symmetric differences, in [0, 1]. Scores
are averaged within profile pairs, then seed/mode groups, then across groups.
No filesystem or network access is performed by this module.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from hashlib import sha256
from html.parser import HTMLParser
import importlib
from itertools import combinations
import json
from statistics import mean
from typing import Any

from ncert_interact.generators.rollout_worker import Rollout
from ncert_interact.schemas.pis_schema import VerificationReport


_VOID = frozenset({
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
    "meta", "param", "source", "track", "wbr",
})
_JS_TYPES = frozenset({
    "", "module", "text/javascript", "application/javascript",
    "text/ecmascript", "application/ecmascript", "application/x-javascript",
})
_ROLES = frozenset({
    "application", "article", "button", "checkbox", "dialog", "document",
    "figure", "form", "group", "heading", "img", "list", "listitem", "main",
    "navigation", "none", "note", "presentation", "region", "slider", "status",
    "table", "tab", "tabpanel", "textbox",
})
_SYNTAX = frozenset({
    "operator", "kind", "computed", "prefix", "async", "generator", "method",
    "shorthand", "delegate", "static", "sourceType",
})
_GRAPH_LABEL = "observed probe transition graph, not inferred semantic equivalence"


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass
class _Node:
    label: str
    children: list[tuple[str, _Node]] = field(default_factory=list)


class _Document(HTMLParser):
    """Ordered tag tree; prose, class names and dynamic attributes are ignored."""

    def __init__(self, html: str) -> None:
        super().__init__(convert_charrefs=True)
        self.root = _Node("document")
        self.stack: list[tuple[str, _Node]] = [("document", self.root)]
        self.scripts: list[dict[str, Any]] = []
        self.active_script: dict[str, Any] | None = None
        self.feed(html)
        self.close()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        hints: dict[str, str] = {"tag": tag}
        role = (attributes.get("role") or "").lower()
        if role in _ROLES:
            hints["role"] = role
        if tag == "input":
            hints["type"] = (attributes.get("type") or "text").lower()
        node = _Node(_json(hints))
        self.stack[-1][1].children.append(("child", node))
        if tag not in _VOID:
            self.stack.append((tag, node))
        if tag == "script":
            mime = (attributes.get("type") or "").split(";", 1)[0].strip().lower()
            if mime in _JS_TYPES:
                self.active_script = {"source": "", "external": "src" in attributes}
                self.scripts.append(self.active_script)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if tag not in _VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag: str) -> None:
        if tag == "script":
            self.active_script = None
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break

    def handle_data(self, data: str) -> None:
        if self.active_script is not None:
            self.active_script["source"] += data


def _tree_multiset(root: _Node) -> Counter[str]:
    """Hash every ordered subtree, retaining multiplicity without quadratic JSON."""
    signatures: Counter[str] = Counter()
    stack: list[tuple[_Node, bool]] = [(root, False)]
    digests: dict[int, str] = {}
    while stack:
        node, visited = stack.pop()
        if not visited:
            stack.append((node, True))
            stack.extend((child, False) for _, child in reversed(node.children))
            continue
        shape = [node.label, [(edge, digests[id(child)]) for edge, child in node.children]]
        digest = sha256(_json(shape).encode("utf-8")).hexdigest()
        signatures[digest] += 1
        digests[id(node)] = digest
    return signatures


def _ast_node(value: Mapping[str, Any], *, member_name: bool = False) -> _Node:
    node_type = str(value["type"])
    label: dict[str, Any] = {"type": node_type}
    if node_type == "Literal":
        literal = value.get("value")
        label["literal_type"] = "regexp" if "regex" in value else "string" if isinstance(literal, str) else _value_type(literal)
    elif node_type == "Identifier" and member_name:
        # Member API names distinguish circle/path/line calls without preserving
        # arbitrary local variable or function names.
        label["member"] = value.get("name")
    for key in sorted(_SYNTAX.intersection(value)):
        label[key] = value[key]
    result = _Node(_json(label))
    for key in sorted(value):
        if key in {"loc", "range", "tokens", "comments", "errors"}:
            continue
        item = value[key]
        preserve = node_type in {"MemberExpression", "OptionalMemberExpression"} and key == "property" and not value.get("computed")
        if isinstance(item, Mapping) and "type" in item:
            result.children.append((key, _ast_node(item, member_name=preserve)))
        elif isinstance(item, list):
            # Array holes are structural, unlike literal values.
            for child in item:
                if isinstance(child, Mapping) and "type" in child:
                    result.children.append((key, _ast_node(child)))
                elif child is None:
                    result.children.append((key, _Node("array-hole")))
    return result


def _ast_signature(document: _Document, parser: Any, rollout_id: str) -> tuple[Counter[str] | None, list[dict[str, Any]]]:
    root = _Node("executable-inline-scripts")
    errors: list[dict[str, Any]] = []
    for index, script in enumerate(document.scripts):
        try:
            if script["external"]:
                raise ValueError("External script source is unavailable; no resource was fetched")
            parsed = parser.parseScript(script["source"], tolerant=False)
            tree = parsed.toDict()
            root.children.append(("script", _ast_node(tree)))
        except Exception as error:
            # Third-party parser exceptions (including unsupported syntax) must
            # be visible; partial ASTs must never count as a successful parse.
            errors.append({"rollout_id": rollout_id, "script_index": index,
                           "error": f"{type(error).__name__}: {error}"})
    return (None if errors else _tree_multiset(root)), errors


def _value_type(value: Any, *, readout: bool = False) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float)):
        return "number"
    if isinstance(value, str):
        if value == "Infinity":
            return "infinity-text"
        if readout and value.strip():
            try:
                float(value)
            except ValueError:
                return "text"
            return "numeric-text"
        return "text"
    if isinstance(value, Mapping):
        return "mapping"
    if isinstance(value, (list, tuple)):
        return "sequence"
    return type(value).__name__


def _output_shape(values: Mapping[str, Any], *, readout: bool = False) -> list[tuple[str, Any]]:
    shape: list[tuple[str, Any]] = []
    for key, value in sorted(values.items(), key=lambda item: str(item[0])):
        if readout and isinstance(value, Mapping) and "text" in value:
            visibility = value.get("visible")
            shape.append((str(key), {"text_type": _value_type(value["text"], readout=True),
                                     "visible": visibility if type(visibility) is bool else None}))
        else:
            shape.append((str(key), _value_type(value, readout=readout)))
    return shape


def _changed(previous: Mapping[str, Any], current: Mapping[str, Any]) -> list[str]:
    return sorted(str(key) for key in previous.keys() | current.keys()
                  if key not in previous or key not in current or _json(previous[key]) != _json(current[key]))


def _graph_signature(report: VerificationReport | None, rollout: Rollout) -> Counter[str] | None:
    if report is None:
        return None
    probe_regimes = {probe.probe_id: probe.regime_name for probe in rollout.pis.verification_oracle.probe_cases}
    regimes: dict[str, int] = {}
    identities: dict[str, int] = {}
    nodes: list[dict[str, Any]] = []
    trace: list[dict[str, Any] | None] = []
    readout_keys = {readout.testid: readout.state_key for readout in rollout.pis.required_dom_readouts}
    for detail in report.probe_details:
        # The verifier's current API calls this observed_state; accept the
        # planned actual_sim_state spelling without substituting expected_state.
        state = detail.get("actual_sim_state", detail.get("observed_state"))
        readouts = detail.get("readouts")
        has_state, has_readouts = isinstance(state, Mapping), isinstance(readouts, Mapping)
        if not ((has_state and state) or (has_readouts and readouts)):
            # Missing observations break the trace; do not invent an edge over
            # an unknown probe or substitute trusted expected answers.
            trace.append(None)
            continue
        state = dict(state) if has_state else {}
        readouts = {readout_keys.get(str(key), str(key)): value for key, value in readouts.items()} if has_readouts else {}
        identity = _json([state, readouts])
        if identity not in identities:
            identities[identity] = len(nodes)
            nodes.append({"state": state, "readouts": readouts})
        regime = str(detail.get("regime_name", probe_regimes.get(detail.get("probe_id"), "unknown")))
        regime_index = regimes.setdefault(regime, len(regimes))
        trace.append({"node": identities[identity], "regime": regime_index,
                      "visual_changed": detail.get("visual_changed") if type(detail.get("visual_changed")) is bool else None,
                      "passed": detail.get("passed") if type(detail.get("passed")) is bool else None})
    if not nodes:
        return None
    incoming: dict[int, set[int]] = defaultdict(set)
    outgoing: dict[int, set[int]] = defaultdict(set)
    edges: list[tuple[int, int]] = []
    transitions: list[_Node] = []
    for previous, current in zip(trace, trace[1:]):
        if previous is None or current is None:
            continue
        source, target = previous["node"], current["node"]
        outgoing[source].add(target)
        incoming[target].add(source)
        edges.append((source, target))
        label = {
            "source": source, "target": target,
            "regimes": [previous["regime"], current["regime"]],
            "changed_state_keys": _changed(nodes[source]["state"], nodes[target]["state"]),
            "changed_readout_keys": _changed(nodes[source]["readouts"], nodes[target]["readouts"]),
            "visual_changed": current["visual_changed"], "passed": current["passed"],
        }
        transitions.append(_Node(_json(label)))
    root = _Node("observed-probe-graph")
    for index, node in enumerate(nodes):
        label = {"outputs": _output_shape(node["state"]),
                 "readouts": _output_shape(node["readouts"], readout=True),
                 "in_degree": len(incoming[index]), "out_degree": len(outgoing[index])}
        root.children.append(("state", _Node(_json(label))))
        root.children.append(("degree", _Node(_json([len(incoming[index]), len(outgoing[index])]))))
    root.children.extend(("transition", transition) for transition in transitions)
    root.children.append(("topology", _Node(_json({
        "edges": edges, "trace": [item["node"] if item is not None else None for item in trace],
    }))))
    return _tree_multiset(root)


def _distance(left: Counter[str], right: Counter[str]) -> float:
    total = sum(left.values()) + sum(right.values())
    return sum(abs(left[key] - right[key]) for key in left.keys() | right.keys()) / total if total else 0.0


def _profile(rollout: Rollout) -> str:
    return str(getattr(rollout.pis.learner_profile, "value", rollout.pis.learner_profile))


def _mode(rollout: Rollout) -> str:
    return str(getattr(rollout.pis.pedagogical_mode, "value", rollout.pis.pedagogical_mode))


def _report_index(rollouts: Sequence[Rollout], reports: Sequence[VerificationReport] | None) -> dict[str, VerificationReport]:
    candidates: dict[str, Rollout] = {}
    for rollout in rollouts:
        if rollout.rollout_id in candidates:
            raise ValueError(f"duplicate rollout_id: {rollout.rollout_id}")
        candidates[rollout.rollout_id] = rollout
    index: dict[str, VerificationReport] = {}
    for report in reports if reports is not None else ():
        if report.rollout_id in index:
            raise ValueError(f"duplicate report rollout_id: {report.rollout_id}")
        if report.rollout_id not in candidates:
            raise ValueError(f"orphan report: {report.rollout_id}")
        if report.task_id != candidates[report.rollout_id].task_id:
            raise ValueError(f"report task_id mismatch: {report.rollout_id}")
        index[report.rollout_id] = report
    return index


def audit_diversity(rollouts: Sequence[Rollout], reports: Sequence[VerificationReport] | None = None) -> dict:
    """Compare only cross-profile golds within the same seed and pedagogical mode.

    Optional reports may be partial, but duplicates, orphans and mismatched task
    IDs are rejected. No observations means null state-graph diversity. AST
    failure counts are per executable script, and affected rollouts are excluded
    from AST comparisons while remaining eligible for DOM/graph comparisons.
    """
    report_index = _report_index(rollouts, reports)
    golds = sorted((rollout for rollout in rollouts if rollout.kind == "gold"), key=lambda r: (r.task_id, r.rollout_id))
    try:
        parser = importlib.import_module("esprima")
    except ImportError:
        parser = None
    groups: dict[tuple[str, str], list[Rollout]] = defaultdict(list)
    signatures: dict[str, dict[str, Counter[str] | None]] = {}
    errors: list[dict[str, Any]] = []
    for rollout in golds:
        document = _Document(rollout.html)
        ast, failures = _ast_signature(document, parser, rollout.rollout_id) if parser is not None else (None, [])
        errors.extend(failures)
        signatures[rollout.rollout_id] = {
            "ast": ast, "dom": _tree_multiset(document.root),
            "state_graph": _graph_signature(report_index.get(rollout.rollout_id), rollout),
        }
        groups[(rollout.pis.seed_id, _mode(rollout))].append(rollout)
    metrics = ("ast", "dom", "state_graph")
    totals: dict[str, list[float]] = {metric: [] for metric in metrics}
    comparison_counts = {metric: 0 for metric in metrics}
    comparisons: list[dict[str, Any]] = []
    group_results: list[dict[str, Any]] = []
    for (seed_id, mode), candidates in sorted(groups.items()):
        profile_pairs: dict[tuple[str, str], dict[str, list[float]]] = {}
        for left, right in combinations(candidates, 2):
            if _profile(left) == _profile(right):
                continue
            pair = tuple(sorted((_profile(left), _profile(right))))
            pair_scores = profile_pairs.setdefault(pair, {metric: [] for metric in metrics})
            detail: dict[str, Any] = {
                "seed_id": seed_id, "pedagogical_mode": mode,
                "left_rollout_id": left.rollout_id, "right_rollout_id": right.rollout_id,
                "profiles": list(pair),
            }
            for metric in metrics:
                a, b = signatures[left.rollout_id][metric], signatures[right.rollout_id][metric]
                score = _distance(a, b) if a is not None and b is not None else None
                detail[metric + "_diversity"] = score
                if score is not None:
                    pair_scores[metric].append(score)
                    comparison_counts[metric] += 1
            comparisons.append(detail)
        group_result: dict[str, Any] = {"seed_id": seed_id, "pedagogical_mode": mode,
                                        "profile_pairs": len(profile_pairs)}
        for metric in metrics:
            scores = [mean(values[metric]) for values in profile_pairs.values() if values[metric]]
            group_result[metric + "_diversity"] = mean(scores) if scores else None
            if scores:
                totals[metric].append(mean(scores))
        group_results.append(group_result)
    return {
        **{metric + "_diversity": mean(totals[metric]) if totals[metric] else None for metric in metrics},
        **{metric + "_comparisons": comparison_counts[metric] for metric in metrics},
        "ast_parse_failures": len(errors),
        "ast_failed_rollouts": len({error["rollout_id"] for error in errors}),
        "ast_parser": "esprima.parseScript(tolerant=False)",
        "ast_parser_available": parser is not None,
        "ast_unavailable_rollouts": len(golds) if parser is None else 0,
        "ast_errors": errors,
        "state_graph_missing_rollouts": sum(signatures[r.rollout_id]["state_graph"] is None for r in golds),
        "state_graph_label": _GRAPH_LABEL,
        "gold_rollouts": len(golds), "profiles": sorted({_profile(rollout) for rollout in golds}),
        "comparisons": len(comparisons), "comparison_details": comparisons, "groups": group_results,
        "distance": "normalized ordered-subtree multiset symmetric difference: sum(abs(a-b))/sum(a+b)",
        "aggregation": "macro mean over seed/mode groups; each group averages profile-pair means",
        "notes": [
            "AST literals and local identifier names are stripped; member API names and control-flow structure remain.",
            "DOM is static ordered HTML tag topology with native input types/role hints; text, classes, IDs, data and geometry attribute values are ignored.",
            "Runtime-created SVG geometry is not included in static DOM signatures.",
            "Probe graph nodes use observed outputs/readouts; labels retain coarse types and changed keys, not raw numeric/text values.",
            "Observed state accepts actual_sim_state or the verifier's observed_state; readouts accept flat values or text/visible snapshots keyed by state_key or testid. Unknown observed keys are retained, not silently discarded.",
            "Repeated observed values establish graph topology; regime names are canonicalized by first occurrence, and degrees count distinct directed neighbors.",
            "Missing probes break transition traces. Expected states alone never establish an observed state.",
            "Missing evidence yields null, identical structural evidence yields zero. This is not a semantic-equivalence or learning-effectiveness claim.",
        ],
    }


__all__ = ["audit_diversity"]