"""Deterministic clean-room references and an explicitly opt-in async LLM client.

The reference renderer ships equations, not Python oracle evaluations or probes.
Only the designated negative examples deliberately break the update contract.
Importing this module and rendering references never creates a network client.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import math
import re
import time
from dataclasses import dataclass
from html import escape
from html.parser import HTMLParser
from typing import Any, Literal

from ncert_interact.schemas.pis_schema import PISSchema, Seed
from ncert_interact.templates import load_asset

from .prompts import (
    SYSTEM_CODE_PROMPT,
    SYSTEM_PIS_PROMPT,
    build_code_prompt,
    build_pis_prompt,
    validate_pis_prose,
)


RolloutKind = Literal["gold", "dead_slider", "telemetry_spoof", "flawed_physics", "llm"]
_REFERENCE_KINDS = ("gold", "dead_slider", "telemetry_spoof", "flawed_physics")
_MODEL_IDS = frozenset({
    "math_c04_fraction_equivalence_v1", "evs_c04_solubility_floating_v1",
    "math_c05_angle_classifier_v1", "evs_c05_buoyancy_salinity_v1",
    "math_c09_circle_subtended_angle_v1", "sci_c09_bio_osmosis_v1",
    "math_c10_quadratic_discriminant_v1", "sci_c10_optics_thin_lens_v1",
})
_CSP = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'"


@dataclass
class Rollout:
    """One executable candidate and the authoritative task it was built for."""

    task_id: str
    rollout_id: str
    kind: str
    html: str
    generation_latency_sec: float
    pis: PISSchema


def _json_script(value: Any) -> str:
    """JSON that cannot terminate a script tag or create an HTML comment."""
    return (
        json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        .replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
        .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    )


def _attr(value: object) -> str:
    return escape(str(value), quote=True)


def _equivalent_option(option: str, value: object) -> bool:
    """Match schema-approved numeric defaults without changing option strings."""
    if type(value) not in (str, int, float):
        return False
    if option == value:
        return True
    try:
        left, right = float(option), float(value)
    except (ValueError, OverflowError):
        return False
    return math.isfinite(left) and math.isfinite(right) and left == right


def _controls_markup(controls: list[dict[str, Any]]) -> str:
    pieces: list[str] = []
    for control in controls:
        cid, label = _attr(control["id"]), _attr(control["label"])
        value, tag = control["default_val"], control["tag"]
        common = f'id="{cid}" aria-label="{label}"'
        unit = control.get("unit") or ""
        display = f'<span class="control-value" id="value_{cid}" aria-hidden="true">{_attr(value)} {_attr(unit)}</span>'
        if tag == "input_range":
            element = (
                f'<input type="range" {common} min="{_attr(control["min_val"])}" '
                f'max="{_attr(control["max_val"])}" step="{_attr(control["step"])}" value="{_attr(value)}">'
            )
        elif tag == "select":
            options = "".join(
                f'<option value="{_attr(option)}"{" selected" if _equivalent_option(option, value) else ""}>{_attr(option).replace("_", " ")}</option>'
                for option in control.get("options") or []
            )
            element = f'<select {common}>{options}</select>'
        elif tag == "button":
            element = f'<button type="button" {common} aria-pressed="false" data-value="{_attr(value)}">{label}</button>'
        else:
            raise ValueError(f"Unsupported control tag: {tag}")
        pieces.append(f'<div class="control"><label for="{cid}">{label}{display}</label>{element}</div>')
    return "\n".join(pieces)


def _readout_markup(readouts: list[dict[str, Any]]) -> str:
    return "\n".join(
        '<div class="readout"><dt>' + _attr(readout["state_key"].replace("_", " ").capitalize())
        + '</dt><dd><span data-testid="' + _attr(readout["testid"])
        + '"></span><span class="unit">' + _attr(readout.get("unit") or "") + '</span></dd></div>'
        for readout in readouts
    )


def _guidance(data: dict[str, Any]) -> tuple[str, str, str]:
    profile, mode = data["learner_profile"], data["pedagogical_mode"]
    if profile == "Remedial_Concrete":
        banner = '<div class="profile-banner"><span class="step-pill">Concrete steps</span><p class="note">Change one thing. Point to what moves. Say what you notice.</p></div>'
    elif profile == "Counterfactual_Challenge":
        banner = '<aside class="challenge-box"><strong>Challenge a prediction</strong><p class="note">Find a boundary case and use the diagram to test whether your rule still holds.</p></aside>'
    else:
        banner = '<div class="equation-key"><span>Control values</span><span aria-hidden="true">→</span><span>Geometric model</span><span aria-hidden="true">→</span><span>Measurements</span></div>'
    if mode == "Predict_Observe_Explain":
        title = "Predict · Observe · Explain"
        steps = [
            ("Predict", "Before moving a control, predict which feature and measurement will change."),
            ("Observe", "Change one control and compare the geometry with its numerical or categorical readout."),
            ("Explain", "Use evidence from both representations to explain the result."),
        ]
    elif mode == "Misconception_Debug":
        title = "Investigate a claim"
        misconception = data["ncert_alignment"].get("target_misconception", "One example is enough to establish a rule.")
        steps = [
            ("Claim to test, not a fact", misconception),
            ("Collect evidence", "Seek a contrasting or boundary setting that could disprove the claim."),
            ("Revise", "Write a corrected rule using the diagram and measurements as evidence."),
        ]
    else:
        title = "Explore · Compare · Connect"
        steps = [
            ("Explore", "Change one control at a time; keep the others fixed."),
            ("Compare", "Find two settings with different outcomes and two with the same classification."),
            ("Connect", "Describe the relationship between the control, the diagram, and the measurements."),
        ]
    content = '<ol>' + ''.join(f'<li><strong>{_attr(label)}.</strong> {_attr(body)}</li>' for label, body in steps) + '</ol>'
    prompts = data.get("guided_prompts") or []
    if prompts:
        content += '<ul>' + ''.join(f'<li>{_attr(prompt)}</li>' for prompt in prompts) + '</ul>'
    return banner, title, content


_BRIDGE = r'''(function () {
  "use strict";
  const config=JSON.parse(document.getElementById("simulation-config").textContent);
  const svg=document.getElementById("sim-viewport");
  const controls=Object.create(null), definitions=new Map(config.controls.map(c=>[c.id,c]));
  const model=SimSVG.models[config.oracleId];
  if(!model) throw new Error("Unsupported simulation model");
  const readouts=new Map(Array.from(document.querySelectorAll("#readout-panel [data-testid]")).map(e=>[e.dataset.testid,e]));
    function equivalentOption(option,raw) {
        if(typeof raw!=="number"&&typeof raw!=="string") return false;
        if(option===raw) return true;
        if(!String(option).trim()||(typeof raw==="string"&&!raw.trim())) return false;
        const left=Number(option),right=Number(raw);
        return Number.isFinite(left)&&Number.isFinite(right)&&left===right;
    }
  function parse(def,raw) {
    if(def.tag==="input_range") {
      if((typeof raw!=="number"&&typeof raw!=="string")||(typeof raw==="string"&&!raw.trim())) throw new TypeError("Expected numeric slider value");
      const value=Number(raw),step=Number(def.step),low=Number(def.min_val),high=Number(def.max_val);
      if(!Number.isFinite(value)||value<low||value>high||Math.abs((value-low)/step-Math.round((value-low)/step))>1e-7) throw new RangeError("Slider value is outside its domain");
      return value;
    }
    const options=def.options||[];
    if(options.length) {
        const option=options.find(v=>equivalentOption(v,raw));
      if(option===undefined) throw new RangeError("Invalid option");
      return option;
    }
    if(def.tag==="button") {
      if(typeof def.default_val==="number") {
        const n=Number(raw);
        if(!Number.isFinite(n)) throw new TypeError("Button value must be finite");
        return n;
      }
      if(typeof raw!=="string") throw new TypeError("Button value must be text");
      return raw;
    }
    throw new TypeError("Control has no valid domain");
  }
  config.controls.forEach(def=>{controls[def.id]=parse(def,def.default_val);});
  function compute() {
    const state=model.compute(controls);
    if(config.kind==="flawed_physics") {
      // An explicit negative candidate: a consistent but scientifically wrong model.
      switch(config.oracleId) {
        case "math_c04_fraction_equivalence_v1": state.fraction_decimal+=.125;state.equivalent_num+=1;break;
        case "evs_c04_solubility_floating_v1": state.solubility_state=state.solubility_state.includes("Floats")?"Insoluble (Settles at Bottom)":"Insoluble (Floats on Top)";state.light_passage="Cloudy/Opaque";break;
        case "math_c05_angle_classifier_v1": state.angle_deg+=7;state.complement_deg=Math.max(0,90-state.angle_deg);state.supplement_deg=180-state.angle_deg;state.angle_category=state.angle_deg<90?"Acute (< 90°)":state.angle_deg===90?"Right (= 90°)":"Obtuse (> 90°)";break;
        case "evs_c05_buoyancy_salinity_v1": state.fluid_density+=.2;state.buoyancy_state=state.buoyancy_state==="Floats at Surface"?"Sinks to Bottom":"Floats at Surface";break;
        case "math_c09_circle_subtended_angle_v1": state.central_angle_deg+=10;state.inscribed_angle_deg=state.central_angle_deg/3;state.theorem_ratio=3;state.chord_length_cm=SimSVG.round(2*Number(controls.ctrl_radius_cm)*Math.sin(state.central_angle_deg*Math.PI/360),2);break;
        case "sci_c09_bio_osmosis_v1": state.net_water_flow=state.net_water_flow==="Endosmosis (Inward)"?"Exosmosis (Outward)":"Endosmosis (Inward)";if(controls.ctrl_cell_type==="plant_onion_cell") state.vacuole_volume_pct=Math.max(10,state.vacuole_volume_pct-15);state.cell_state="Normal / Flaccid";break;
        case "math_c10_quadratic_discriminant_v1": state.discriminant+=4;state.vertex_y=SimSVG.round(-state.discriminant/(4*Number(controls.ctrl_a)),2);state.root_nature=state.discriminant>0?"Two Distinct Real Roots (D > 0)":state.discriminant===0?"Two Equal Real Roots (D = 0)":"No Real Roots (D < 0)";break;
        case "sci_c10_optics_thin_lens_v1": if(state.v_dist!=="Infinity") state.v_dist+=3;if(state.magnification!=="Infinity") state.magnification+=.25;state.image_nature=state.image_nature==="Virtual, Erect, Magnified"?"Real, Inverted, Magnified":"Virtual, Erect, Magnified";break;
        default: throw new Error("Unsupported negative model");
      }
    }
    Object.values(state).forEach(value=>{if(typeof value==="number"&&!Number.isFinite(value)) throw new Error("Non-finite simulation output");});
    return state;
  }
  function paint(state) {
    config.readouts.forEach(def=>{
      if(!Object.prototype.hasOwnProperty.call(state,def.state_key)) throw new Error("Missing required readout");
      readouts.get(def.testid).textContent=String(state[def.state_key]);
    });
    SimSVG.draw(svg,config.oracleId,controls,state,config.profile);
  }
  function syncControl(def,value) {
    const element=document.getElementById(def.id);
    if(def.tag==="button") {element.dataset.value=String(value);element.setAttribute("aria-pressed",String(value!==def.default_val));}
    else element.value=String(value);
    document.getElementById("value_"+def.id).textContent=String(value)+(def.unit?" "+def.unit:"");
  }
  window.__UPDATE_SIM__=function(controlId,rawValue) {
    if(!definitions.has(controlId)) throw new RangeError("Unknown control ID");
    if(config.kind==="dead_slider") return window.__SIM_STATE__;
    const def=definitions.get(controlId),value=parse(def,rawValue);
    controls[controlId]=value;
    syncControl(def,value);
    const state=compute();
    window.__SIM_STATE__=state;
    if(config.kind!=="telemetry_spoof") paint(state);
    return state;
  };
  config.controls.forEach(def=>{
    syncControl(def,controls[def.id]);
    if(config.kind!=="dead_slider") {
      const element=document.getElementById(def.id);
      const update=()=>window.__UPDATE_SIM__(def.id,def.tag==="button"?element.dataset.value:element.value);
      element.addEventListener("input",update);
      element.addEventListener("change",update);
      if(def.tag==="button") element.addEventListener("click",()=>{
        const options=def.options||[];
        const current=controls[def.id],index=options.findIndex(v=>String(v)===String(current));
        const next=options.length?options[(index+1)%options.length]:typeof current==="number"?current+Number(def.step||1):current===def.default_val?"active":def.default_val;
        window.__UPDATE_SIM__(def.id,next);
      });
    }
  });
  window.__SIM_STATE__=compute();
  paint(window.__SIM_STATE__);
})();'''


def _render_reference(pis: PISSchema, kind: str) -> str:
    data = pis.model_dump(mode="json")
    oracle_id = data["verification_oracle"]["trusted_oracle_id"]
    if oracle_id not in _MODEL_IDS:
        raise ValueError(f"Unsupported reference oracle: {oracle_id}")
    budget, alignment = data["ui_complexity_budget"], data["ncert_alignment"]
    controls, readouts = data["controls_contract"], data["required_dom_readouts"]
    if len(controls) > budget["max_controls"]:
        raise ValueError("Controls exceed the UI complexity budget")
    if any(view != "sim-viewport" for view in budget["required_views"]):
        raise ValueError("Reference renderer supports only the sim-viewport required view")
    touch = budget["min_touch_target_px"]
    if isinstance(touch, bool) or not isinstance(touch, (int, float)) or not math.isfinite(touch) or touch <= 0:
        raise ValueError("Touch target must be a positive finite number")
    banner, guidance_title, guidance = _guidance(data)
    config = {
        "oracleId": oracle_id, "controls": controls, "readouts": readouts,
        "profile": data["learner_profile"], "mode": data["pedagogical_mode"], "kind": kind,
    }
    title = alignment["chapter_topic"]
    replacements = {
        "SIM_TITLE": _attr(title), "SIM_TOUCH": str(touch),
        "SIM_PROFILE": _attr(data["learner_profile"]), "SIM_MODE": _attr(data["pedagogical_mode"]),
        "SIM_DESCRIPTION": _attr(data.get("problem_description") or alignment["learning_outcome_text"]),
        "SIM_PROFILE_GUIDANCE": banner, "SIM_CONTROLS": _controls_markup(controls),
        "SIM_READOUTS": _readout_markup(readouts), "SIM_GUIDANCE_TITLE": _attr(guidance_title),
        "SIM_GUIDANCE": guidance,
        "SIM_NOTES": _attr(data.get("scientific_notes") or "Idealized teaching diagram; not an experimental measurement."),
        "SIM_CONFIG": _json_script(config), "SIM_PRIMITIVES": load_asset("svg_primitives.js"),
        "SIM_BRIDGE": _BRIDGE,
    }
    # One substitution pass prevents user text from becoming replacement syntax.
    template = load_asset("base_harness.html")
    markers = set(re.findall(r"@@([A-Z_]+)@@", template))
    if markers != replacements.keys():
        raise ValueError("Harness replacement markers disagree with renderer")
    return re.sub(r"@@([A-Z_]+)@@", lambda match: replacements[match[1]], template)


def synthesize_reference_rollouts(pis: PISSchema) -> list[Rollout]:
    """Return four byte-deterministic offline candidates in the documented order."""
    return [
        Rollout(
            task_id=pis.task_id, rollout_id=f"{pis.task_id}__{kind}", kind=kind,
            html=_render_reference(pis, kind), generation_latency_sec=0.0, pis=pis,
        )
        for kind in _REFERENCE_KINDS
    ]


def _unfence(content: str, language: str) -> str:
    if not isinstance(content, str) or not content.strip():
        raise ValueError("Model returned empty content")
    result = content.strip().lstrip("\ufeff").strip()
    if result.startswith("```"):
        match = re.fullmatch(r"```(?:" + language + r")?[^\S\n]*\r?\n([\s\S]*?)\r?\n?```", result, re.IGNORECASE)
        if match is None:
            raise ValueError("Expected exactly one fenced document with no extra content")
        result = match[1].strip()
    return result


def _validate_css(css: str) -> None:
    """Inspect CSS tokens after escapes, without modifying JavaScript strings."""
    def unescape(match: re.Match[str]) -> str:
        if match[1] is None:
            return match[2]
        codepoint = int(match[1], 16)
        return chr(codepoint) if 0 < codepoint <= 0x10FFFF and not 0xD800 <= codepoint <= 0xDFFF else "\ufffd"

    normalized = re.sub(r"\\(?:\r\n|[\r\n\f])", "", css)
    normalized = re.sub(r"/\*[\s\S]*?\*/", "", normalized)
    normalized = re.sub(r"\\(?:([0-9a-fA-F]{1,6})(?:\r\n|[ \t\r\n\f])?|([^\r\n\f0-9a-fA-F]))", unescape, normalized)
    if re.search(r"@import\b", normalized, re.IGNORECASE):
        raise ValueError("Generated HTML cannot contain CSS imports")
    for reference in re.finditer(r"\burl\s*\(\s*([^)]*?)\s*\)", normalized, re.IGNORECASE):
        target = reference[1].strip().strip("\"'")
        if not re.fullmatch(r"#[a-zA-Z_][\w:.-]*", target):
            raise ValueError("CSS resources must reference a local SVG definition")


class _HTMLContractParser(HTMLParser):
    """Structural/resource checks only: generated scripts are never executed here."""

    def __init__(self, document: str) -> None:
        super().__init__(convert_charrefs=True)
        self.counts = {"html": 0, "head": 0, "body": 0}
        self._inside_html = False
        self._closed_html = False
        self._inside_style = False
        self._line_offsets = [0, *(match.end() for match in re.finditer("\n", document))]
        self.head_end: int | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if self._closed_html:
            raise ValueError("Extra content after the HTML document")
        if tag == "html":
            self._inside_html = True
        elif not self._inside_html:
            raise ValueError("HTML elements must be inside the document root")
        if tag in self.counts:
            self.counts[tag] += 1
        if tag == "head":
            line, column = self.getpos()
            self.head_end = self._line_offsets[line - 1] + column + len(self.get_starttag_text() or "")
        if tag == "script" and self.head_end is None:
            raise ValueError("Generated scripts must follow the document head")
        if tag == "style":
            self._inside_style = True
        values = dict(attrs)
        if tag in {"iframe", "frame", "frameset", "object", "embed", "base", "form", "link"}:
            raise ValueError(f"Disallowed generated HTML element: {tag}")
        if tag == "meta" and (values.get("http-equiv") or "").lower() == "refresh":
            raise ValueError("Generated HTML cannot redirect")
        for key, value in attrs:
            if value and key in {"style", "fill", "stroke", "clip-path", "filter", "mask", "cursor", "marker", "marker-start", "marker-mid", "marker-end"}:
                _validate_css(value)
            if key.lower() in {"src", "href", "xlink:href", "srcset", "action", "formaction", "poster", "data", "ping", "background"} and value:
                if not value.startswith("#") and not (tag == "img" and key == "src" and value.startswith("data:image/")):
                    raise ValueError("Generated HTML must not reference external resources")
        if tag == "script" and "src" in values:
            raise ValueError("Generated scripts must be inline")

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag: str) -> None:
        if self._closed_html:
            raise ValueError("Extra closing tags after the HTML document")
        if tag == "style":
            self._inside_style = False
        if tag == "html":
            self._inside_html = False
            self._closed_html = True

    def handle_data(self, data: str) -> None:
        if self._inside_style:
            _validate_css(data)
        if data.strip() and not self._inside_html:
            raise ValueError("Unexpected text outside the HTML document")


def sanitize_html_output(content: str) -> str:
    """Accept only one standalone document; reject prose, extra code, and resources.

    This is not a JavaScript security sandbox. The injected CSP blocks resource
    loads; consumers must still run generated pages only in an isolated browser.
    """
    document = _unfence(content, "html")
    if not re.match(r"<!doctype\s+html\s*>", document, re.IGNORECASE):
        raise ValueError("Generated document is missing the HTML doctype")
    if len(re.findall(r"<!doctype\b", document, re.IGNORECASE)) != 1:
        raise ValueError("Expected exactly one HTML document")
    if not re.search(r"</html\s*>\s*$", document, re.IGNORECASE):
        raise ValueError("Generated output must end with the HTML document")
    if "```" in document:
        raise ValueError("Unexpected code fences")
    parser = _HTMLContractParser(document)
    parser.feed(document)
    parser.close()
    if any(count != 1 for count in parser.counts.values()) or parser.head_end is None:
        raise ValueError("Generated document must contain one html, head, and body")
    # Use the actual parsed start tag, never a lookalike in comments or scripts.
    policy = '<meta http-equiv="Content-Security-Policy" content="' + escape(_CSP, quote=True) + '">'
    return document[:parser.head_end] + policy + document[parser.head_end:]


class RolloutWorker:
    """Bounded OpenAI-compatible requests; client construction is deferred to use."""

    def __init__(
        self,
        base_url: str = "http://localhost:8000/v1",
        api_key: str = "local",
        model: str = "Qwen/Qwen2.5-Coder-32B-Instruct",
        timeout: float = 120,
        max_retries: int = 2,
        max_tokens: int = 12000,
        max_concurrency: int = 4,
        *,
        client: Any = None,
    ) -> None:
        if isinstance(timeout, bool) or not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be positive and finite")
        for label, value, minimum in (("max_retries", max_retries, 0), ("max_tokens", max_tokens, 1), ("max_concurrency", max_concurrency, 1)):
            if type(value) is not int or value < minimum:
                raise ValueError(f"{label} must be an integer >= {minimum}")
        self.base_url, self.api_key, self.model = base_url, api_key, model
        self.timeout, self.max_retries, self.max_tokens = timeout, max_retries, max_tokens
        self._semaphore = asyncio.Semaphore(max_concurrency)
        self._client = client
        self._closed = False

    def _get_client(self) -> Any:
        if self._closed:
            raise RuntimeError("RolloutWorker is closed")
        if self._client is None:
            # Optional dependency: offline references do not require openai.
            from openai import AsyncOpenAI

            self._client = AsyncOpenAI(base_url=self.base_url, api_key=self.api_key, timeout=self.timeout, max_retries=self.max_retries)
        return self._client

    async def _complete(self, system: str, prompt: str) -> str:
        async with self._semaphore:
            client = self._get_client()
            response = await client.chat.completions.create(
                model=self.model,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                max_tokens=self.max_tokens,
                temperature=0,
            )
            if not response.choices:
                raise ValueError("Model returned no choices")
            choice = response.choices[0]
            if getattr(choice, "finish_reason", None) == "length":
                raise ValueError("Model output was truncated by the token limit")
            content = choice.message.content
            if not isinstance(content, str) or not content.strip():
                raise ValueError("Model returned no textual content")
            return content

    async def synthesize(self, pis: PISSchema) -> Rollout:
        """Generate and validate an HTML candidate without executing its scripts."""
        started = time.perf_counter()
        html = sanitize_html_output(await self._complete(SYSTEM_CODE_PROMPT, build_code_prompt(pis)))
        return Rollout(
            task_id=pis.task_id, rollout_id=f"{pis.task_id}__llm", kind="llm", html=html,
            generation_latency_sec=time.perf_counter() - started, pis=pis,
        )

    async def generate_pis(self, seed: Seed, scaffold: PISSchema) -> PISSchema:
        """Validate complete model JSON first, then reject authoritative mutations."""
        content = _unfence(await self._complete(SYSTEM_PIS_PROMPT, build_pis_prompt(seed, scaffold)), "json")
        candidate = PISSchema.model_validate_json(content)
        authoritative, proposed = scaffold.model_dump(mode="json"), candidate.model_dump(mode="json")
        editable = {"guided_prompts", "problem_description", "scientific_notes"}
        if {key: value for key, value in authoritative.items() if key not in editable} != {key: value for key, value in proposed.items() if key not in editable}:
            raise ValueError("Generated PIS attempted to modify the authoritative scaffold")
        validate_pis_prose(candidate, scaffold)
        return candidate

    async def aclose(self) -> None:
        if not self._closed:
            self._closed = True
            if self._client is not None:
                closer = getattr(self._client, "aclose", None) or getattr(self._client, "close", None)
                if closer is not None:
                    result = closer()
                    if inspect.isawaitable(result):
                        await result

    async def close(self) -> None:
        await self.aclose()

    async def __aenter__(self) -> RolloutWorker:
        if self._closed:
            raise RuntimeError("RolloutWorker is closed")
        return self

    async def __aexit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        await self.aclose()


__all__ = ["Rollout", "RolloutKind", "RolloutWorker", "sanitize_html_output", "synthesize_reference_rollouts"]