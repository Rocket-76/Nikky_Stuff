"""Deterministic 3×3 expansion with leakage-resistant train/dev/test splits.

Seeds are connected if they share either a normalized grade/subject/chapter or
a trusted oracle concept. Transitive components stay together; all nine tasks
from any seed inherit that seed's split. Eight canonical components give 6/1/1.
"""

from __future__ import annotations

import random
from collections import defaultdict
from collections.abc import Sequence
from unicodedata import normalize

from ncert_interact.schemas import (
    DevelopmentalBand, LearnerProfile, PISSchema, PedagogicalMode, Seed,
    UIComplexityBudget,
)


def _validated(seeds: Sequence[Seed], random_seed: int) -> list[Seed]:
    if type(random_seed) is not int:
        raise TypeError("random_seed must be an integer")
    if isinstance(seeds, (str, bytes)) or not isinstance(seeds, Sequence):
        raise TypeError("seeds must be a sequence of Seed models")
    checked: list[Seed] = []
    seen: set[str] = set()
    for seed in seeds:
        if not isinstance(seed, Seed):
            raise TypeError("all inputs must be Seed models")
        validated = Seed.model_validate(seed.model_dump())
        if validated.seed_id in seen:
            raise ValueError(f"duplicate seed_id: {validated.seed_id}")
        seen.add(validated.seed_id)
        checked.append(validated)
    return sorted(checked, key=lambda seed: seed.seed_id)


def _canonical(text: str) -> str:
    return " ".join(normalize("NFKC", text).casefold().split())


def _concept_key(seed: Seed) -> str:
    # Versions of one trusted concept must not leak into different partitions.
    name = seed.verification_oracle.trusted_oracle_id
    stem, marker, version = name.rpartition("_v")
    return stem if marker and version.isdigit() else name


def _split_validated(seeds: list[Seed], random_seed: int) -> dict[str, list[Seed]]:
    parent = list(range(len(seeds)))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    def merge(first: int, second: int) -> None:
        parent[root(second)] = root(first)

    chapters: dict[tuple[int, str, str], int] = {}
    concepts: dict[str, int] = {}
    for index, seed in enumerate(seeds):
        alignment = seed.ncert_alignment
        chapter = (alignment.class_grade, _canonical(alignment.subject), _canonical(alignment.chapter_topic))
        concept = _concept_key(seed)
        if chapter in chapters:
            merge(index, chapters[chapter])
        if concept in concepts:
            merge(index, concepts[concept])
        chapters[chapter] = index
        concepts[concept] = index
    components: dict[int, list[Seed]] = defaultdict(list)
    for index, seed in enumerate(seeds):
        components[root(index)].append(seed)
    groups = sorted(components.values(), key=lambda group: group[0].seed_id)
    random.Random(random_seed).shuffle(groups)
    holdout = max(1, round(len(groups) * .1)) if len(groups) >= 3 else 0
    train_end = len(groups) - 2 * holdout
    partitions = {"train": groups[:train_end], "dev": groups[train_end:train_end + holdout],
                  "test": groups[train_end + holdout:]}
    return {name: sorted((seed for group in batches for seed in group), key=lambda seed: seed.seed_id)
            for name, batches in partitions.items()}


def split_seeds(seeds: Sequence[Seed], random_seed: int = 2027) -> dict[str, list[Seed]]:
    """Split connected concepts approximately 80/10/10; tiny banks stay in train."""
    return _split_validated(_validated(seeds, random_seed), random_seed)


def _prompts(seed: Seed, profile: LearnerProfile, mode: PedagogicalMode) -> list[str]:
    support = {
        LearnerProfile.Remedial_Concrete: "Use the concrete picture; change one control at a time and describe what you can see.",
        LearnerProfile.Standard_GradeLevel: "Connect the diagram and readouts to the rule; explain the relationship with grade-level vocabulary.",
        LearnerProfile.Counterfactual_Challenge: "Test a boundary or counterexample; justify which relationship remains invariant and which changes.",
    }[profile]
    approach = {
        PedagogicalMode.Predict_Observe_Explain: "Predict the next state, observe the result after changing a control, then explain any difference.",
        PedagogicalMode.Exploratory_Sandbox: "Choose contrasting settings, record a pattern, and test it with a new setting of your choice.",
        PedagogicalMode.Misconception_Debug: f"Find evidence that challenges this misconception: {seed.ncert_alignment.target_misconception}",
    }[mode]
    return [support, approach, f"Investigate {seed.ncert_alignment.chapter_topic}; use the visible readouts as evidence."]


def expand_seeds(seeds: Sequence[Seed], random_seed: int = 2027) -> list[PISSchema]:
    """Return independent PIS models for every seed/profile/mode combination."""
    validated = _validated(seeds, random_seed)
    membership = {seed.seed_id: name for name, group in _split_validated(validated, random_seed).items()
                  for seed in group}
    tasks: list[PISSchema] = []
    for seed in validated:
        foundational = seed.ncert_alignment.class_grade in (4, 5)
        for profile in LearnerProfile:
            for mode in PedagogicalMode:
                remedial = profile == LearnerProfile.Remedial_Concrete
                budget = UIComplexityBudget(
                    developmental_band=DevelopmentalBand.Foundational_4_5 if foundational else DevelopmentalBand.Secondary_9_10,
                    max_controls=3 if foundational else 5,
                    min_touch_target_px=(56 if foundational else 48) if remedial else (48 if foundational else 36),
                    required_views=["sim-viewport"],
                )
                data = seed.model_dump(exclude={"provenance", "mapping_status"})
                data.update(
                    task_id=f"task_{seed.seed_id}_{profile.value}_{mode.value}".lower(),
                    split=membership[seed.seed_id], learner_profile=profile, pedagogical_mode=mode,
                    ui_complexity_budget=budget, guided_prompts=_prompts(seed, profile, mode),
                )
                tasks.append(PISSchema.model_validate(data))
    random.Random(random_seed).shuffle(tasks)
    return tasks


__all__ = ["expand_seeds", "split_seeds"]