"""Join authoritative verification evidence and write reproducible SFT/DPO data.

The combined training contract intentionally differs from the HTML-only online
generation prompt: completions contain full PIS JSON followed by one standalone
HTML document. Concept-only user prompts are identical in SFT and DPO. Packaging
does not run candidates, evaluate scientific models, or manufacture verification
results. It writes only the four documented artifacts under ``output_dir``.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Sequence
import json
import math
from pathlib import Path
from statistics import mean
from typing import Any

from ncert_interact.schemas.pis_schema import PISSchema, VerificationReport
from ncert_interact.verifier.diversity_audit import audit_diversity

from .prompts import SYSTEM_CODE_PROMPT, concept_context
from .rollout_worker import Rollout


DATASET_SYSTEM_PROMPT = SYSTEM_CODE_PROMPT + "\n\n" + """COMBINED DATASET GENERATION CONTRACT:
For this combined PIS-and-code task only, the HTML-only response-format rule
above is superseded. Author one complete original pedagogical interaction
specification and its corresponding simulation. Return exactly
<pis_json> followed by the complete PIS JSON object followed by </pis_json>, a
newline, and the standalone <!doctype html> document. Do not wrap the document
in another HTML element or use Markdown fences. All scientific, accessibility,
security and synchronization requirements above still apply to the simulation.
The conceptual user context describes the domain, not hidden expected answers.
Preserve task, seed and split metadata in the full PIS for reproducibility;
do not leak evaluation probes into executable HTML or visible learner guidance.
""".strip()

_SPLITS = ("train", "dev", "test")
_FILES = {
    "sft": "ncert_interact_sft.jsonl", "dpo": "ncert_interact_dpo.jsonl",
    "benchmark": "benchmark_report.md", "diversity": "diversity_report.json",
}


def _validate_join(rollouts: Sequence[Rollout], reports: Sequence[VerificationReport]) -> list[tuple[Rollout, VerificationReport]]:
    indexed: dict[str, Rollout] = {}
    task_contracts: dict[str, dict[str, Any]] = {}
    seed_splits: dict[str, str] = {}
    for rollout in rollouts:
        if not isinstance(rollout, Rollout) or not isinstance(rollout.pis, PISSchema):
            raise TypeError("rollouts must contain Rollout instances with PISSchema specifications")
        if not rollout.rollout_id or not isinstance(rollout.rollout_id, str):
            raise ValueError("rollout_id must be a nonempty string")
        if rollout.rollout_id in indexed:
            raise ValueError(f"duplicate rollout_id: {rollout.rollout_id}")
        if rollout.task_id != rollout.pis.task_id:
            raise ValueError(f"PIS task_id mismatch: {rollout.rollout_id}")
        if not isinstance(rollout.html, str) or not rollout.html.strip():
            raise ValueError(f"empty or invalid HTML: {rollout.rollout_id}")
        if not isinstance(rollout.kind, str) or not rollout.kind.strip():
            raise ValueError("rollout kind must be nonempty")
        latency = rollout.generation_latency_sec
        if isinstance(latency, bool) or not isinstance(latency, (int, float)) or not math.isfinite(latency) or latency < 0:
            raise ValueError(f"invalid generation latency: {rollout.rollout_id}")
        pis = rollout.pis
        if pis.split not in _SPLITS:
            raise ValueError(f"invalid split: {pis.split}")
        contract = pis.model_dump(mode="json")
        if pis.task_id in task_contracts and task_contracts[pis.task_id] != contract:
            raise ValueError(f"conflicting task contract: {pis.task_id}")
        if pis.seed_id in seed_splits and seed_splits[pis.seed_id] != pis.split:
            raise ValueError(f"seed split leakage: {pis.seed_id}")
        task_contracts[pis.task_id] = contract
        seed_splits[pis.seed_id] = pis.split
        indexed[rollout.rollout_id] = rollout
    report_index: dict[str, VerificationReport] = {}
    for report in reports:
        if not isinstance(report, VerificationReport):
            raise TypeError("reports must contain VerificationReport instances")
        # Models are mutable; revalidate to catch post-construction bad metrics.
        VerificationReport.model_validate(report.model_dump())
        if report.passed_all and not (
            report.exec_valid and not report.console_errors
            and report.controls_found_ratio == 1.0
            and report.interaction_coverage == 1.0
            and report.scientific_oracle_acc == 1.0
            and report.ui_budget_compliance and not report.spoofing_detected
        ):
            raise ValueError(f"inconsistent passed_all report: {report.rollout_id}")
        if report.rollout_id in report_index:
            raise ValueError(f"duplicate report rollout_id: {report.rollout_id}")
        if report.rollout_id not in indexed:
            raise ValueError(f"orphan report: {report.rollout_id}")
        rollout = indexed[report.rollout_id]
        if report.task_id != rollout.task_id:
            raise ValueError(f"report task_id mismatch: {report.rollout_id}")
        if not math.isclose(report.generation_latency_sec, rollout.generation_latency_sec, rel_tol=1e-9, abs_tol=1e-9):
            raise ValueError(f"generation latency mismatch: {report.rollout_id}")
        report_index[report.rollout_id] = report
    missing = sorted(indexed.keys() - report_index.keys())
    if missing:
        raise ValueError(f"missing verification reports: {', '.join(missing)}")
    return [(rollout, report_index[rollout.rollout_id])
            for rollout in sorted(indexed.values(), key=lambda r: (r.task_id, r.rollout_id))]


def _prompt(rollout: Rollout) -> list[dict[str, str]]:
    return [{"role": "system", "content": DATASET_SYSTEM_PROMPT},
            {"role": "user", "content": concept_context(rollout.pis)}]


def _completion(rollout: Rollout) -> dict[str, str]:
    return {"role": "assistant", "content":
            "<pis_json>" + rollout.pis.model_dump_json() + "</pis_json>\n" + rollout.html}


def _metadata(rollout: Rollout) -> dict[str, Any]:
    return {"task_id": rollout.task_id, "seed_id": rollout.pis.seed_id,
            "split": rollout.pis.split, "rollout_id": rollout.rollout_id,
            "kind": rollout.kind,
            "learner_profile": rollout.pis.learner_profile.value,
            "pedagogical_mode": rollout.pis.pedagogical_mode.value}


def _failure_metrics(report: VerificationReport) -> dict[str, Any]:
    return report.model_dump(mode="json", include={
        "exec_valid", "controls_found_ratio", "interaction_coverage", "scientific_oracle_acc",
        "spoofing_detected", "ui_budget_compliance", "passed_all", "console_errors",
    })


def _records(joined: list[tuple[Rollout, VerificationReport]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    sft: list[dict[str, Any]] = []
    by_task: dict[str, list[tuple[Rollout, VerificationReport]]] = defaultdict(list)
    for rollout, report in joined:
        by_task[rollout.task_id].append((rollout, report))
        if report.passed_all:
            sft.append({"messages": _prompt(rollout) + [_completion(rollout)], "metadata": _metadata(rollout)})
    dpo: list[dict[str, Any]] = []
    for candidates in by_task.values():
        passing = [rollout for rollout, report in candidates if report.passed_all]
        if not passing:
            continue
        # Prefer the labeled deterministic reference, then lexical ID. No
        # scientific-score ranking or unstable input order enters selection.
        chosen = min(passing, key=lambda rollout: (rollout.kind != "gold", rollout.rollout_id))
        for rejected, report in candidates:
            if report.passed_all or not report.exec_valid:
                continue
            if not (report.scientific_oracle_acc < 1.0 or report.interaction_coverage < 1.0
                    or report.controls_found_ratio < 1.0):
                continue
            if _prompt(rejected) != _prompt(chosen):
                raise ValueError(f"chosen/rejected prompt mismatch: {chosen.task_id}")
            metadata = _metadata(chosen)
            metadata.pop("rollout_id")
            metadata.pop("kind")
            metadata.update({
                "chosen_rollout_id": chosen.rollout_id, "rejected_rollout_id": rejected.rollout_id,
                "chosen_kind": chosen.kind, "rejected_kind": rejected.kind,
                "failure_metrics": _failure_metrics(report),
            })
            dpo.append({"prompt": _prompt(chosen), "chosen": [_completion(chosen)],
                        "rejected": [_completion(rejected)], "metadata": metadata})
    return sft, dpo


def _metrics(joined: list[tuple[Rollout, VerificationReport]], sft: int, dpo: int) -> dict[str, Any]:
    reports = [report for _, report in joined]
    spoof = [report for rollout, report in joined if rollout.kind == "telemetry_spoof"]
    gold = [report for rollout, report in joined if rollout.kind == "gold"]

    def percentage(values: list[float | bool]) -> float | None:
        return 100.0 * mean(values) if values else None

    return {
        "rollouts": len(joined), "tasks": len({rollout.task_id for rollout, _ in joined}),
        "seeds": len({rollout.pis.seed_id for rollout, _ in joined}),
        "tasks_without_passing_candidate": len({rollout.task_id for rollout, _ in joined}
            - {rollout.task_id for rollout, report in joined if report.passed_all}),
        "passed_all": sum(report.passed_all for report in reports),
        "sft_records": sft, "dpo_pairs": dpo,
        "exec_pct": percentage([report.exec_valid for report in reports]),
        "controls_found_pct": percentage([report.controls_found_ratio for report in reports]),
        "interact_pct": percentage([report.interaction_coverage for report in reports]),
        "sci_acc_pct": percentage([report.scientific_oracle_acc for report in reports]),
        "ped_vis_pct": percentage([report.ui_budget_compliance for report in reports]),
        "spoofing_caught_pct": percentage([report.spoofing_detected for report in spoof]),
        "spoofing_caught": sum(report.spoofing_detected for report in spoof),
        "spoofing_denominator": len(spoof),
        "gold_false_positive_pct": percentage([report.spoofing_detected for report in gold]),
        "gold_false_positives": sum(report.spoofing_detected for report in gold),
        "gold_denominator": len(gold),
        "generation_latency_sec_mean": mean([rollout.generation_latency_sec for rollout, _ in joined]) if joined else None,
        "verification_latency_sec_mean": mean([report.verification_latency_sec for report in reports]) if reports else None,
    }


def _summary(joined: list[tuple[Rollout, VerificationReport]], sft: list[dict[str, Any]], dpo: list[dict[str, Any]]) -> dict[str, Any]:
    kinds = sorted({rollout.kind for rollout, _ in joined})

    def subset(rows: list[tuple[Rollout, VerificationReport]]) -> dict[str, Any]:
        ids = {rollout.rollout_id for rollout, _ in rows}
        return _metrics(rows,
                        sum(record["metadata"]["rollout_id"] in ids for record in sft),
                        sum(record["metadata"]["rejected_rollout_id"] in ids for record in dpo))

    return {
        "overall": subset(joined),
        "by_kind": {kind: subset([(r, v) for r, v in joined if r.kind == kind]) for kind in kinds},
        "by_split": {
            split: {**subset([(r, v) for r, v in joined if r.pis.split == split]),
                    "by_kind": {kind: subset([(r, v) for r, v in joined if r.pis.split == split and r.kind == kind])
                                for kind in kinds}}
            for split in _SPLITS
        },
        "notes": [
            "Reference labels identify deterministic smoke fixtures, not model results or evidence of research performance.",
            "Model-labeled candidates are reported separately by their actual kind; packaging itself does not run a model.",
            "Exec% = mean(exec_valid); Interact% = mean(interaction_coverage); SciAcc% = mean(scientific_oracle_acc), all over every report in the row.",
            "PedVis% = mean(ui_budget_compliance), a UI-budget proxy only, not a validated pedagogy or visual-quality score.",
            "SpoofingCaught% uses only actual telemetry_spoof labels. Gold false positives use only gold labels. Empty denominators are null/N/A.",
            "Generation and verification latencies are separate arithmetic means in seconds; matching generation latencies use a 1e-9 numeric tolerance.",
            "SFT includes exactly passed_all reports, which must have valid execution, no console errors, all three control/interaction/scientific ratios exactly 1, UI-budget compliance and no spoofing; inconsistent positive reports are rejected, not recomputed.",
            "DPO prefers passing gold then lexical rollout ID, and pairs every executable scientific/interaction failure with that task's chosen candidate. Candidates for the same task must have identical complete PIS JSON contracts, including prose.",
            "Execution failures are excluded from DPO because default zero scientific/interaction metrics cannot establish observed scientific negatives; pure UI failures are also excluded.",
            "Tasks without any passed_all candidate produce no DPO pairs; their count is reported separately.",
            "DPO per-kind counts are attributed to the rejected kind. Full PIS JSON is training output, not a public HTML-generation input.",
            "Every row retains seed/task/split metadata; each seed is restricted to one split. No split is reassigned during packaging.",
        ],
    }


def _cell(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\r", " ").replace("\n", " ")


def _number(value: float | None) -> str:
    return "N/A" if value is None else f"{value:.3f}"


def _benchmark(summary: dict[str, Any], diversity: dict[str, Any]) -> str:
    lines = ["# NCERT interaction packaging benchmark", "",
             "Local evidence inventory: deterministic smoke fixtures are not model results.", "",
             "## Metrics by rollout kind", "",
             "| Kind | N | Exec% | Interact% | SciAcc% | PedVis% | SpoofingCaught% | Spoof N | Gold false-positive% | Gold N | Generation sec mean | Verification sec mean |",
             "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"]

    def metric_row(label: str, values: dict[str, Any]) -> str:
        cells = [_cell(label), str(values["rollouts"])]
        cells.extend(_number(values[key]) for key in ("exec_pct", "interact_pct", "sci_acc_pct", "ped_vis_pct", "spoofing_caught_pct"))
        cells.extend([str(values["spoofing_denominator"]), _number(values["gold_false_positive_pct"]),
                      str(values["gold_denominator"]), _number(values["generation_latency_sec_mean"]),
                      _number(values["verification_latency_sec_mean"])])
        return "| " + " | ".join(cells) + " |"

    lines.extend(metric_row(kind, row) for kind, row in summary["by_kind"].items())
    lines.append(metric_row("Overall", summary["overall"]))
    lines.extend(["", "## Overall and split counts", "",
                  "| Scope | Seeds | Tasks | Rollouts | Passed all | SFT records | DPO pairs |",
                  "| --- | ---: | ---: | ---: | ---: | ---: | ---: |"])
    for scope, row in [("Overall", summary["overall"]), *summary["by_split"].items()]:
        lines.append("| " + " | ".join([scope] + [str(row[key]) for key in
            ("seeds", "tasks", "rollouts", "passed_all", "sft_records", "dpo_pairs")]) + " |")
    lines.extend(["", "## Split metrics", ""])
    for split, row in summary["by_split"].items():
        lines.extend([f"### {split}", "",
            "| Kind | N | Exec% | Interact% | SciAcc% | PedVis% | SpoofingCaught% | Spoof N | Gold false-positive% | Gold N | Generation sec mean | Verification sec mean |",
            "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"])
        lines.extend(metric_row(kind, values) for kind, values in row["by_kind"].items() if values["rollouts"])
        lines.extend([metric_row("Split total", row), ""])
    lines.extend(["## Structural diversity", "",
                  "Gold comparisons are within seed and pedagogical mode, across learner profiles only.", "",
                  "| Signature | Macro distance [0,1] | Valid comparisons |",
                  "| --- | ---: | ---: |"])
    for metric in ("ast", "dom", "state_graph"):
        lines.append(f"| {metric} | {_number(diversity[metric + '_diversity'])} | {diversity[metric + '_comparisons']} |")
    lines.extend(["", f"AST parser available: {diversity['ast_parser_available']}; "
                  f"script parse failures: {diversity['ast_parse_failures']}; "
                  f"affected rollouts: {diversity['ast_failed_rollouts']}; "
                  f"rollouts without parser: {diversity['ast_unavailable_rollouts']}.", "",
                  diversity["state_graph_label"] + ".", "",
                  "See diversity_report.json for per-comparison evidence, parse errors and methodological limitations.",
                  "", f"Tasks without a passing candidate: {summary['overall']['tasks_without_passing_candidate']}.",
                  "", "## Definitions and limitations", ""])
    lines.extend("- " + note for note in summary["notes"] + diversity["notes"])
    return "\n".join(lines) + "\n"


def _json(value: Any, *, indent: int | None = None) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False, indent=indent)


def package_dataset(rollouts: Sequence[Rollout], reports: Sequence[VerificationReport], output_dir: Path) -> dict:
    """Validate a bijective rollout/report join and write four UTF-8 artifacts.

    IDs are globally unique per rollout/report, multiple rollouts per task are
    expected. The complete PIS JSON must agree for each task, including prose;
    generation timing must match each report. Positive reports must have fully
    passing metrics and are rejected rather than silently recomputed otherwise.
    All joins, records and serialization are checked before creating the output
    directory. Output order is independent of input order.
    Existing named artifacts are replaced; unrelated files are not touched.
    The result contains JSON-safe string paths, counts, and the full summary.
    """
    if not isinstance(output_dir, Path):
        raise TypeError("output_dir must be a pathlib.Path")
    joined = _validate_join(rollouts, reports)
    sft, dpo = _records(joined)
    summary = _summary(joined, sft, dpo)
    diversity = audit_diversity([rollout for rollout, _ in joined], [report for _, report in joined])
    payloads = {
        "sft": "".join(_json(record) + "\n" for record in sft),
        "dpo": "".join(_json(record) + "\n" for record in dpo),
        "benchmark": _benchmark(summary, diversity),
        "diversity": _json(diversity, indent=2) + "\n",
    }
    _json(summary)
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: dict[str, str] = {}
    for name, filename in _FILES.items():
        path = output_dir / filename
        with path.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(payloads[name])
        paths[name] = str(path)
    return {"sft_records": len(sft), "dpo_pairs": len(dpo), "paths": paths, "summary": summary}


__all__ = ["DATASET_SYSTEM_PROMPT", "package_dataset"]