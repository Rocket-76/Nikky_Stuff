"""Specification prompts and offline/opt-in LLM rollout generation."""

from .rollout_worker import Rollout, RolloutWorker, synthesize_reference_rollouts

__all__ = ["Rollout", "RolloutWorker", "synthesize_reference_rollouts"]